# -*- coding: utf-8 -*-
"""Datos externos (miedo/codicia, VIX, COT, financiación, MVRV, flujos ETF, liquidez) -> tabla diaria con retraso de publicación."""
import pandas as pd, numpy as np, json, io, warnings
warnings.filterwarnings('ignore')
from lib import *

RB = f'{W}/data/raw_browser'
BR = f'{BASE}/RENTA_FIJA/brutos'


def dec(name):
    meta = json.load(open(f'{RB}/{name}.meta.json'))
    s = open(f'{RB}/{name}.txt').read().strip()
    d = pd.Timestamp(meta['start']); g0 = int(meta['defGap'])
    dates, vals = [], []
    for i, tok in enumerate(s.split(',')):
        if tok.startswith('+'):
            gap, rest = tok[1:].split(':'); d = d + pd.Timedelta(days=int(gap))
        else:
            rest = tok
            if i > 0: d = d + pd.Timedelta(days=g0)
        dates.append(d); vals.append([float(x) for x in rest.split('/')])
    df = pd.DataFrame(vals, index=pd.DatetimeIndex(dates))
    assert str(df.index[-1].date()) == meta['end'], (name, df.index[-1], meta['end'])
    return df, meta


def fred(series):
    for fn in ('bonos_fred_macro.json', 'bonos_fred_extra.json'):
        j = json.load(open(f'{BR}/{fn}'))
        if series in j:
            s = pd.read_csv(io.StringIO(j[series]), parse_dates=[0], index_col=0).iloc[:, 0]
            return pd.to_numeric(s, errors='coerce').dropna()
    raise KeyError(series)


def yahoo(sym, col='cierre'):
    y = pd.read_csv(f'{BR}/bonos_yahoo_precios.csv', low_memory=False)
    y = y[y.simbolo == sym]
    s = pd.Series(pd.to_numeric(y[col], errors='coerce').values, index=pd.to_datetime(y.fecha)).dropna()
    return s[~s.index.duplicated()].sort_index()


def lagged(s, days, idx):
    s = s.copy(); s.index = s.index + pd.Timedelta(days=days)
    s = s[~s.index.duplicated(keep='last')]
    return s.reindex(idx.union(s.index)).ffill().reindex(idx)


def build():
    idx = pd.date_range('1960-01-01', '2026-10-02', freq='D')
    E = pd.DataFrame(index=idx)
    # --- miedo y codicia ---
    fc, _ = dec('fng_crypto'); E['fng_crypto'] = lagged(fc[0], 0, idx).where(idx >= fc.index[0])
    E.loc[E.index > fc.index[-1], 'fng_crypto'] = np.nan
    old = pd.read_csv('https://raw.githubusercontent.com/hackingthemarkets/sentiment-fear-and-greed/master/datasets/fear-greed.csv', parse_dates=['Date']).set_index('Date')['Fear Greed'].dropna()
    cn, _ = dec('fng_cnn'); cn = cn[0][cn.index >= '2021-02-10']
    cnn = pd.concat([old[old.index < '2020-09-19'], cn]).sort_index()
    cnn = cnn[~cnn.index.duplicated()]
    E['fng_cnn'] = cnn.reindex(idx).ffill(limit=4)
    # --- VIX y MOVE ---
    vix = pd.concat([fred('VIXCLS'), yahoo('^VIX')]); vix = vix[~vix.index.duplicated(keep='last')].sort_index()
    E['vix'] = vix.reindex(idx).ffill(limit=4)
    E['move'] = yahoo('^MOVE').reindex(idx).ffill(limit=4)
    # --- COT (dato del martes, publicado el viernes: usable desde el sábado) ---
    for a, nm in (('oro', 'gold'), ('plata', 'silver'), ('sp500', 'sp500'), ('nasdaq100', 'nasdaq'), ('BTC', 'btc')):
        c, _ = dec('cot_' + nm)
        oi, net = c[0], c[1]
        netp = 100 * net / oi
        E[f'cot_net_{a}'] = lagged(netp, 4, idx)
        lo = netp.rolling(156, min_periods=52).min(); hi = netp.rolling(156, min_periods=52).max()
        E[f'cot_idx_{a}'] = lagged(100 * (netp - lo) / (hi - lo), 4, idx)
        E[f'oi_13w_{a}'] = lagged(100 * (oi / oi.shift(13) - 1), 4, idx)
        E[f'oi_pct3y_{a}'] = lagged(oi.rolling(156, min_periods=52).rank(pct=True) * 100, 4, idx)
        E[f'oi_{a}'] = lagged(oi, 4, idx)
    for a, nm in (('sp500', 'sp500'), ('nasdaq100', 'nasdaq'), ('BTC', 'btc')):
        t, _ = dec('tff_' + nm)
        am = 100 * t[1] / t[0]; lv = 100 * t[2] / t[0]
        E[f'tff_am_{a}'] = lagged(am, 4, idx); E[f'tff_lev_{a}'] = lagged(lv, 4, idx)
        E[f'tff_am_13w_{a}'] = lagged(am - am.shift(13), 4, idx)
    # --- Bitcoin: financiación, MVRV, flujos de casas de cambio, ETF, monedas estables ---
    fo, _ = dec('funding_binance'); fo = fo[0] / 1e6
    fn = pd.read_parquet(f'{BASE}/CRIPTO_PERPETUOS/BTC/financiacion.parquet')
    fn = fn.set_index(fn['fecha'].dt.floor('D'))['tasa'].groupby(level=0).sum()
    fund = pd.concat([fo[fo.index < fn.index[0]], fn]).sort_index()
    E['fund_d'] = fund.reindex(idx)
    E['fund_7d'] = E['fund_d'].rolling(7, min_periods=5).mean() * 365 * 100   # % anualizado
    E['fund_30d'] = E['fund_d'].rolling(30, min_periods=20).mean() * 365 * 100
    cm = pd.read_csv(f'{W}/data/btc_coinmetrics.csv', parse_dates=['time']).set_index('time')
    mv2, _ = dec('mvrv_recent')
    mv = pd.concat([cm['CapMVRVCur'].dropna(), (mv2[0] / 1000)]); mv = mv[~mv.index.duplicated(keep='first')].sort_index()
    E['mvrv'] = lagged(mv, 1, idx)
    cap = cm['CapMrktCurUSD']
    nf = (cm['FlowInExUSD'] - cm['FlowOutExUSD'])
    E['exflow_30d'] = lagged(100 * nf.rolling(30).sum() / cap, 1, idx)   # entradas netas a casas de cambio, % de la capitalización
    E['exsply_90d'] = lagged(100 * (cm['SplyExNtv'] / cm['SplyExNtv'].shift(90) - 1), 1, idx)
    last_cm = cm['FlowInExUSD'].dropna().index[-1]
    E.loc[E.index > last_cm + pd.Timedelta(days=5), ['exflow_30d', 'exsply_90d']] = np.nan
    et, _ = dec('etf_btc_flows'); et = et[0]
    etd = et.reindex(pd.date_range(et.index[0], et.index[-1], freq='D')).fillna(0)
    E['etf_20d'] = lagged(etd.rolling(28).sum() / 1000, 1, idx)   # miles de millones $, 4 semanas
    E['etf_5d'] = lagged(etd.rolling(7).sum() / 1000, 1, idx)
    st, _ = dec('stablecoins'); st = st[0] / 10  # miles de millones $
    E['stable'] = lagged(st, 0, idx)
    E['stable_4w'] = lagged(100 * (st / st.shift(4) - 1), 0, idx)
    E['stable_13w'] = lagged(100 * (st / st.shift(13) - 1), 0, idx)
    E.loc[E.index < '2019-01-01', ['stable', 'stable_4w', 'stable_13w']] = np.nan
    # --- liquidez ---
    wal, _ = dec('fred_WALCL'); tga, _ = dec('fred_WTREGEN'); rrp, _ = dec('fred_RRPONTSYD'); res, _ = dec('fred_WRESBAL')
    wal, tga, res = wal[0], tga[0], res[0]
    rrpw = rrp[0].reindex(wal.index.union(rrp.index)).ffill().reindex(wal.index).fillna(0)
    netliq = wal - tga - rrpw
    E['netliq'] = lagged(netliq, 2, idx)
    E['netliq_13w'] = lagged(100 * (netliq / netliq.shift(13) - 1), 2, idx)
    E['netliq_26w'] = lagged(100 * (netliq / netliq.shift(26) - 1), 2, idx)
    E['fedbs_13w'] = lagged(100 * (wal / wal.shift(13) - 1), 2, idx)
    E['res_13w'] = lagged(100 * (res / res.shift(13) - 1), 2, idx)
    ecb, _ = dec('fred_ECBASSETSW'); boj, _ = dec('fred_JPNASSETS')
    eur = fred('DEXUSEU'); jpy = fred('DEXJPUS')
    wk = pd.date_range('1999-01-08', '2026-10-02', freq='W-FRI')
    def onwk(s, lag):
        return lagged(s, lag, wk)
    fed_long = pd.concat([pd.Series(dtype=float), wal])
    g = pd.DataFrame({'fed': onwk(wal, 2), 'ecb': onwk(ecb[0], 5) * onwk(eur, 1), 'boj': onwk(boj[0], 45) * 100 / onwk(jpy, 1)})
    gcb = g.sum(axis=1, min_count=3)
    E['gcb'] = lagged(gcb, 0, idx)
    E['gcb_13w'] = lagged(100 * (gcb / gcb.shift(13) - 1), 0, idx)
    E['gcb_26w'] = lagged(100 * (gcb / gcb.shift(26) - 1), 0, idx)
    E['gcb_52w'] = lagged(100 * (gcb / gcb.shift(52) - 1), 0, idx)
    m2 = fred('M2SL')
    E['m2_yoy'] = lagged(100 * (m2 / m2.shift(12) - 1), 60, idx)
    E['m2_6m'] = lagged(100 * ((m2 / m2.shift(6)) ** 2 - 1), 60, idx)
    cpi = fred('CPIAUCSL')
    E['m2real_yoy'] = lagged(100 * ((m2 / cpi).dropna() / (m2 / cpi).dropna().shift(12) - 1), 60, idx)
    nf_ = fred('NFCI')
    E['nfci'] = lagged(nf_, 5, idx); E['nfci_13w'] = lagged(nf_ - nf_.shift(13), 5, idx)
    dxy = yahoo('DX-Y.NYB')
    E['dxy'] = dxy.reindex(idx).ffill(limit=4)
    E['dxy_13w'] = 100 * (E['dxy'] / E['dxy'].shift(91) - 1)
    E['dxy_d200'] = 100 * (E['dxy'] / E['dxy'].rolling(280, min_periods=200).mean() - 1)
    baa = fred('BAA10Y')
    E['baa'] = lagged(baa, 1, idx); E['baa_13w'] = E['baa'] - E['baa'].shift(91)
    ry = fred('DFII10')
    E['ry10'] = lagged(ry, 1, idx); E['ry10_13w'] = E['ry10'] - E['ry10'].shift(91)
    ff = fred('DFF')
    E['ff'] = lagged(ff, 1, idx); E['ff_26w'] = E['ff'] - E['ff'].shift(182)
    t10 = fred('DGS10'); E['t10'] = lagged(t10, 1, idx); E['t10_13w'] = E['t10'] - E['t10'].shift(91)
    E['curve'] = lagged(fred('T10Y3M'), 1, idx)
    return E


if __name__ == '__main__':
    E = build()
    E.to_parquet(f'{W}/ext_daily.parquet')
    pd.set_option('display.width', 250)
    info = pd.DataFrame({'desde': E.apply(lambda s: s.first_valid_index()), 'hasta': E.apply(lambda s: s.last_valid_index()), 'ultimo': E.apply(lambda s: s.dropna().iloc[-1] if s.notna().any() else np.nan).round(2), 'min': E.min().round(2), 'max': E.max().round(2)})
    print(info.to_string())
