# -*- coding: utf-8 -*-
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, sys
from lib import *
from events import episodes, units_fixed, units_limit, XLIM
E = pd.read_parquet(f'{W}/ext_daily.parquet')

def g(f, col):
    return f[col] if col in f else pd.Series(np.nan, index=f.index)

def conds(a, f):
    X = E.reindex(f.index)
    ci = X.get(f'cot_idx_{a}'); oi = X.get(f'oi_pct3y_{a}'); oi13 = X.get(f'oi_13w_{a}')
    fng = g(f, 'fng_crypto') if a == 'BTC' else g(f, 'fng_cnn')
    S = {
        'div RSI diaria bajista': f.div_bear_rsi, 'div MACD diaria bajista': f.div_bear_macd, 'div delta diaria bajista': f.div_bear_delta,
        'div RSI semanal bajista': f.divw_bear_rsi, 'div MACD semanal bajista': f.divw_bear_macd,
        'div RSI sem + RSI mens>70': f.divw_bear_rsi & (f.rsi14m > 70), 'div RSI diaria + z200>1': f.div_bear_rsi & (f.z200 > 1),
        'div RSI sem + cerca max (pos52>.9)': f.divw_bear_rsi & (f.pos52w > 0.9),
        'liquidez <=33': f.liq <= 33, 'liquidez <=20': f.liq <= 20, 'liq3 = 0 (3 rojas)': f.liq3 == 0,
        'bajo sma200 + liquidez<=33': (f.d_sma200 < 0) & (f.liq <= 33), 'bajo sma50w + liquidez<=33': (f.d_sma50w < 0) & (f.liq <= 33),
        'cmf20<0 cerca de max': (f.cmf20 < 0) & (f.pos52w > 0.9), 'cmf20<-0.1': f.cmf20 < -0.1,
        'z200>=1.7': f.z200 >= 1.7, 'z200>=1.3': f.z200 >= 1.3,
        'codicia >=80': fng >= 80, 'codicia >=90': fng >= 90,
        'COT especuladores muy largos (>=95)': ci >= 95 if ci is not None else None, 'interés abierto en máx 3a (>=97)': oi >= 97 if oi is not None else None,
        'OI +25% en 13s': oi13 >= 25 if oi13 is not None else None,
    }
    B = {
        'div RSI diaria alcista': f.div_bull_rsi, 'div MACD diaria alcista': f.div_bull_macd, 'div delta diaria alcista': f.div_bull_delta,
        'div RSI semanal alcista': f.divw_bull_rsi, 'div MACD semanal alcista': f.divw_bull_macd,
        'div RSI diaria alc + RSI sem<45': f.div_bull_rsi & (f.rsi14w < 45),
        'liquidez >=67': f.liq >= 67, 'liquidez >=80': f.liq >= 80, 'liq3 = 100 (3 verdes)': f.liq3 == 100,
        'sobre sma200 + liquidez>=67': (f.d_sma200 > 0) & (f.liq >= 67),
        'cmf20>0.15': f.cmf20 > 0.15, 'cmf20>0 cerca de min (pos52<.2)': (f.cmf20 > 0) & (f.pos52w < 0.2),
        'miedo <=25': fng <= 25, 'miedo <=15': fng <= 15, 'miedo<=25 + liquidez>=50': (fng <= 25) & (f.liq >= 50),
        'COT especuladores muy cortos (<=5)': ci <= 5 if ci is not None else None, 'interés abierto en mín 3a (<=5)': oi <= 5 if oi is not None else None,
        'OI -20% en 13s': oi13 <= -20 if oi13 is not None else None,
        'caída >=10% desde max 52s': f.dd_52w <= -0.10, 'caída >=20% desde max 52s': f.dd_52w <= -0.20,
        'volat. percentil>=95': pct_expanding(f.rv20, 750) >= 95, 'RSI diario<30': f.rsi14 < 30, 'RSI semanal<35': f.rsi14w < 35,
    }
    if a in ('sp500', 'nasdaq100'):
        S.update({'VIX <=12': g(f, 'vix') <= 12, 'gestores muy largos (TFF>=p95)': pct_rolling(X[f'tff_am_{a}'], 1095, 365) >= 95})
        B.update({'VIX >=30': g(f, 'vix') >= 30, 'VIX >=40': g(f, 'vix') >= 40, 'VIX>=30 + liquidez>=50': (g(f, 'vix') >= 30) & (f.liq >= 50),
                  'gestores muy cortos (TFF<=p5)': pct_rolling(X[f'tff_am_{a}'], 1095, 365) <= 5})
    if a == 'BTC':
        S.update({'financiación 30d >=40% anual': g(f, 'fund_30d') >= 40, 'MVRV >=3': g(f, 'mvrv') >= 3, 'MVRV perc4a >=95': pct_rolling(g(f, 'mvrv'), 1460, 730) >= 95,
                  'delta30 perc<=10': f.delta30_p <= 10, 'delta30 perc<=10 cerca max': (f.delta30_p <= 10) & (f.pos52w > 0.8),
                  'ETF salidas 4s <= -2 mM$': g(f, 'etf_20d') <= -2, 'pierde sma50w': f.d_sma50w < 0, 'estables 13s <0': g(f, 'stable_13w') < 0})
        B.update({'financiación 7d <0': g(f, 'fund_7d') < 0, 'MVRV <=1': g(f, 'mvrv') <= 1.0, 'MVRV <=1.2': g(f, 'mvrv') <= 1.2, 'precio <= media 200 sem': f.d_sma200w <= 0,
                  'precio <= 1.1x media 200 sem': f.d_sma200w <= 0.10, 'caída >=60% desde ATH': f.dd_ath <= -0.60, 'delta30 perc>=90': f.delta30_p >= 90,
                  'ETF entradas 4s >= 3 mM$': g(f, 'etf_20d') >= 3, 'estables 13s >=8%': g(f, 'stable_13w') >= 8, 'miedo <=10': fng <= 10})
    if a in ('oro', 'plata'):
        S.update({'tipos reales +0.5 en 13s': g(f, 'ry10_13w') >= 0.5, 'dólar +5% en 13s': g(f, 'dxy_13w') >= 5})
        B.update({'tipos reales -0.5 en 13s': g(f, 'ry10_13w') <= -0.5, 'dólar -5% en 13s': g(f, 'dxy_13w') <= -5})
    return {k: v for k, v in S.items() if v is not None}, {k: v for k, v in B.items() if v is not None}

def test(a):
    f = pd.read_parquet(f'{W}/feat3_{a}.parquet'); bpy = BPY[a]; x = XLIM[a]; sp = pd.Timestamp(SPLIT[a])
    S, B = conds(a, f); rows = []
    for kind, D in (('V', S), ('C', B)):
        for name, cond in D.items():
            r = {'activo': a, 'tipo': kind, 'cond': name}
            cond = cond.reindex(f.index).fillna(False).astype(bool)
            for nm, mask in (('D', f.index < sp), ('V', f.index >= sp)):
                gdf = f[mask]; cg = cond[mask]
                valid = gdf['fr_3m'].notna()
                ep = episodes(cg, bpy // 12) & valid; e = gdf[ep]
                r[f'{nm}_ep'] = int(ep.sum())
                if kind == 'V':
                    ul_all, hit_all = units_limit(gdf, x, '6m'); ul_e, hit_e = units_limit(e, x, '6m')
                    r[f'{nm}_x'] = 100 * ul_e.mean(); r[f'{nm}_base'] = 100 * ul_all.mean(); r[f'{nm}_x2'] = 100 * units_fixed(e, '3m').mean(); r[f'{nm}_ac'] = 100 * hit_e.mean()
                else:
                    r[f'{nm}_x'] = 100 * e['fr_3m'].mean(); r[f'{nm}_base'] = 100 * gdf['fr_3m'].mean(); r[f'{nm}_x2'] = 100 * e['fr_12m'].mean(); r[f'{nm}_ac'] = 100 * (e['fr_3m'] > 0).mean()
            rows.append(r)
    return pd.DataFrame(rows)

if __name__ == '__main__':
    R = pd.concat([test(a) for a in ASSETS]); R.to_csv(f'{W}/res_cond.csv', index=False)
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 40)
    print("VENTAS (V): x = unidades ganadas (%) vendiendo y recomprando con límite X o a los 6 meses; base = lo mismo un día cualquiera; x2 = recompra fija a 3 meses; ac = % veces que se ejecuta el límite")
    print("COMPRAS (C): x = rentabilidad media a 3 meses (%); base = día cualquiera; x2 = a 12 meses; ac = % positivos a 3 meses")
    for a in ASSETS:
        t = R[R.activo == a].drop(columns='activo').round(1)
        print(f'\n=== {a} (D antes de {SPLIT[a][:4]}, V después) ==='); print(t.to_string(index=False))
