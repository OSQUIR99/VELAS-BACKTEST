import json, re, math, sys, warnings; warnings.filterwarnings('ignore')
R = json.load(open('report_data.json')); V = json.load(open('sell_summary.json'))
def es(s):
    def sw(m):
        t = m.group(0); return t.replace(',', '§').replace('.', ',').replace('§', '.')
    return re.sub(r'\d[\d,]*(?:\.\d+)?', sw, s)
L = R['lectura']
for a, d in L['activos'].items():
    d['condicion'] = es(d['condicion']); d['recompra'] = es(d['recompra'])
simple = lambda x: None if x is None else round(100 * (math.exp(x / 100) - 1), 1)
for a, d in V.items(): d['D_med'] = simple(d['D_med']); d['V_med'] = simple(d['V_med'])
b = R['BTC']
D = {'lectura': L, 'ventas': V,
     'btc': {k: b[k] for k in ('serie', 'sub', 'D', 'V', 'total', 'ops', 'D_ops', 'V_ops', 'golpe', 'solo_tendencia', 'pares')},
     'plata_sem': R['plata_sem']['pares'], 'sp500': R['sp500']['pares'], 'compras': R['compras']}
html = open('report/template.html').read().replace('__DATA__', json.dumps(D, ensure_ascii=False, separators=(',', ':')))
open('report/termometro-acumulacion.html', 'w').write(html)
print('bytes', len(html)); print({a: (v['D_med'], v['V_med']) for a, v in V.items()})
print(L['activos']['BTC']['condicion']); print(L['activos']['oro']['condicion']); print(L['activos']['sp500']['condicion'])
