import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from strat import sim, perf, COST; from ext import fred, lagged
idx = pd.date_range('1960-01-01', '2026-10-02', freq='D')
ic = fred('ICSA'); ic4 = ic.rolling(4).mean()
def claims_flag(thr): return lagged((ic4 > ic4.rolling(52).min() * (1 + thr)).astype(float), 6, idx)
sahm_s = fred('SAHMREALTIME')
res = []
for a in ('sp500', 'nasdaq100'):
    df = pd.read_parquet(f'{W}/px_{a}.parquet'); c = df['c']; sp = pd.Timestamp(SPLIT[a]); start = max(c.index[0] + pd.Timedelta(days=400), pd.Timestamp('1968-06-01'))
    for thr in (0.10, 0.15, 0.20, 0.25, 0.30):
        fl = claims_flag(thr).reindex(c.index).ffill()
        for n in (150, 200, 250):
            for buf in (0.0, 0.03):
                s = sma(c, n); dist = c / s - 1
                out = (fl == 1) & (dist < -buf); back = (fl == 0) | (dist > buf)
                w = pd.Series(np.where(back, 1.0, np.where(out, 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
                d = perf(c, w, a, start, sp); v = perf(c, w, a, sp, None)
                res.append((a, 'paro', thr, n, buf, d['mult'], v['mult'], d['ops'] + v['ops'], v['peor']))
    for th in (0.3, 0.4, 0.5):
        fl = lagged((sahm_s >= th).astype(float), 38, idx).reindex(c.index).ffill()
        for n in (150, 200, 250):
            for buf in (0.0, 0.03):
                s = sma(c, n); dist = c / s - 1
                out = (fl == 1) & (dist < -buf); back = (fl == 0) | (dist > buf)
                w = pd.Series(np.where(back, 1.0, np.where(out, 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
                d = perf(c, w, a, start, sp); v = perf(c, w, a, sp, None)
                res.append((a, 'sahm', th, n, buf, d['mult'], v['mult'], d['ops'] + v['ops'], v['peor']))
G = pd.DataFrame(res, columns=['activo', 'tipo', 'thr', 'media', 'buf', 'D', 'V', 'ops', 'Vpeor'])
pd.set_option('display.width', 200)
for (a, t), g in G.groupby(['activo', 'tipo']):
    print(f"{a} {t}: configs {len(g)} | D min {g.D.min():.2f} med {g.D.median():.2f} max {g.D.max():.2f} | V min {g.V.min():.2f} med {g.V.median():.2f} max {g.V.max():.2f} | ambos>1: {100*((g.D>1)&(g.V>1)).mean():.0f}% | ops med {g.ops.median():.0f}")
print(G[(G.tipo == 'paro') & (G.media == 200)].round(2).to_string(index=False))
# operaciones de la regla base en sp500: paro +20%, sma200, banda 3%
a = 'sp500'; df = pd.read_parquet(f'{W}/px_{a}.parquet'); c = df['c']
fl = claims_flag(0.20).reindex(c.index).ffill(); s = sma(c, 200); dist = c / s - 1
w = pd.Series(np.where((fl == 0) | (dist > 0.03), 1.0, np.where((fl == 1) & (dist < -0.03), 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
wx = w.shift(1).fillna(1.0); ch = wx.diff().fillna(0); sells = list(ch[ch < 0].index); buys = list(ch[ch > 0].index)
for s_ in sells:
    if s_ < pd.Timestamp('1968-06-01'): continue
    b = next((x for x in buys if x > s_), None); ps = c[s_]; pb = c[b] if b is not None else c.iloc[-1]
    print(f"  venta {s_.date()} {ps:>8.1f} -> recompra {(b.date() if b is not None else 'abierta')} {pb:>8.1f}  x{ps/pb*(1-0.001)**2:.2f}")
print('hoy: peticiones media 4s', round(ic4.iloc[-1]), 'mín 52s', round(ic4.rolling(52).min().iloc[-1]), 'ratio', round(ic4.iloc[-1] / ic4.rolling(52).min().iloc[-1], 3), '| Sahm', sahm_s.iloc[-1], sahm_s.index[-1].date())
