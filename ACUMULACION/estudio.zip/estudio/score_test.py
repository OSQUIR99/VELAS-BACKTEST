import warnings; warnings.filterwarnings('ignore')
import sys; sys.path.insert(0, '/home/claude/work/tool')
import pandas as pd, numpy as np, json
import termometro as T
from lib import W, SPLIT
P = T.leer_precios(); hasta = max(s.index[-1] for s in P.values()); L, V, info = T.luces_liquidez(hasta)
paro = T.bandera_paro(pd.date_range('1967-01-01', hasta, freq='D'))[0]
SC = {}
for a in T.ACTIVOS:
    pts, mx, sc = T.puntuacion(a, P, L, V, paro); SC[a] = sc; c = P[a]; bpy = T.BPY[a]; sp = pd.Timestamp(SPLIT[a])
    fr3 = c.shift(-(bpy // 4)) / c - 1; fr12 = c.shift(-bpy) / c - 1
    step = 7 if a == 'BTC' else 5
    S = pd.DataFrame({'s': sc, 'fr3': fr3, 'fr12': fr12}).dropna(subset=['s']).iloc[::step]
    print(f"\n=== {a}: puntuación desde {sc.first_valid_index().date()} | hoy {sc.iloc[-1]:.0f} | percentiles 10/25/50/75/90: {[int(sc.quantile(q)) for q in (.1,.25,.5,.75,.9)]}")
    print('   hoy:', {k: f"{pts[k].iloc[-1]:.1f}/{mx[k]}" for k in pts})
    S['b'] = pd.cut(S.s, [-1, 25, 40, 60, 75, 101], labels=['0-25', '25-40', '40-60', '60-75', '75-100'])
    for nm, g in (('1ª mitad', S[S.index < sp]), ('2ª mitad', S[S.index >= sp])):
        if len(g) < 60: continue
        t = g.groupby('b').agg(n=('s', 'size'), m3=('fr3', 'mean'), p3=('fr3', lambda x: (x > 0).mean()), m12=('fr12', 'mean'), p12=('fr12', lambda x: (x > 0).mean()))
        ic3 = g[['s', 'fr3']].corr(method='spearman').iloc[0, 1]; ic12 = g[['s', 'fr12']].corr(method='spearman').iloc[0, 1]
        print(f"   {nm} (correlación de rangos con lo que vino después: 3m {ic3:+.2f}, 12m {ic12:+.2f}): " + ' | '.join(f"{i}: n={int(r.n)} 3m {100*r.m3:+.0f}% ({100*r.p3:.0f}%+) 12m {100*r.m12:+.0f}% ({100*r.p12:.0f}%+)" for i, r in t.iterrows() if r.n > 0))
pd.DataFrame(SC).to_parquet(f'{W}/scores.parquet')
