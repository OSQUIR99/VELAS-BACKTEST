# -*- coding: utf-8 -*-
"""Estudio de sucesos: qué pasó después de cada lectura extrema de cada indicador.
Métrica clave para VENTAS: 'unidades ganadas' = log(precio venta / precio recompra).
  fijo(H): vender y recomprar pase lo que pase a los H meses.
  limite(X,H): vender, dejar orden de recompra un X % más abajo durante H; si no se ejecuta, recomprar a mercado al final.
Para COMPRAS: rentabilidad posterior frente a comprar un día cualquiera.
Se miden sobre el PRIMER día de cada episodio (para no contar 30 veces el mismo suceso)."""
import pandas as pd, numpy as np, sys, warnings
warnings.filterwarnings('ignore')
from lib import *

XLIM = {'BTC': 0.20, 'sp500': 0.07, 'nasdaq100': 0.10, 'oro': 0.07, 'plata': 0.12}


def episodes(cond, gap):
    """Primer día de cada episodio: señal activa hoy y ningún día con señal en las 'gap' barras previas."""
    c = cond.fillna(False).astype(bool)
    prev = c.shift(1).rolling(gap, min_periods=1).max().fillna(0).astype(bool)
    return c & ~prev


def units_fixed(f, h):
    return -np.log1p(f[f'fr_{h}'])


def units_limit(f, x, h):
    hit = f[f'fmin_{h}'] <= -x
    u = np.where(hit, -np.log(1 - x), -np.log1p(f[f'fr_{h}']))
    return pd.Series(u, index=f.index).where(f[f'fr_{h}'].notna()), hit.where(f[f'fr_{h}'].notna())


def row(f, cond, asset, kind):
    bpy = BPY[asset]; x = XLIM[asset]
    out = []
    split = pd.Timestamp(SPLIT[asset])
    for nm, mask in (('D', f.index < split), ('V', f.index >= split)):
        g = f[mask]; cg = cond.reindex(g.index).fillna(False)
        ep = episodes(cg, bpy // 12)
        e = g[ep]; n_ep = int(ep.sum()); share = 100 * cg.mean()
        if kind == 'sell':
            uf_b = units_fixed(g, '3m').mean(); uf = units_fixed(e, '3m').mean()
            ul_all, hit_all = units_limit(g, x, '6m'); ul_e, hit_e = units_limit(e, x, '6m')
            out.append(f"{nm}: {share:4.1f}% ep={n_ep:3d} | fijo3m {100*uf:+5.1f} (base {100*uf_b:+5.1f}) | lim6m {100*ul_e.mean():+5.1f} (base {100*ul_all.mean():+5.1f}) acierto {100*hit_e.mean():3.0f}% (base {100*hit_all.mean():3.0f}%) | 12m med {100*e['fr_12m'].median():+6.1f} (base {100*g['fr_12m'].median():+6.1f})")
        else:
            out.append(f"{nm}: {share:4.1f}% ep={n_ep:3d} | 3m med {100*e['fr_3m'].median():+5.1f} (base {100*g['fr_3m'].median():+5.1f}) %pos {100*(e['fr_3m']>0).mean():3.0f} | 12m med {100*e['fr_12m'].median():+6.1f} (base {100*g['fr_12m'].median():+6.1f}) %pos {100*(e['fr_12m']>0).mean():3.0f} (base {100*(g['fr_12m']>0).mean():3.0f}) | peor suelo 3m med {100*e['fmin_3m'].median():+5.1f}")
    return '  ||  '.join(out)


def run(asset, conds):
    f = pd.read_parquet(f'{W}/feat_{asset}.parquet')
    print(f"\n===== {asset}  (D = diseño hasta {SPLIT[asset]}, V = validación después; X límite = {XLIM[asset]:.0%}) =====")
    for name, kind, fn in conds:
        try:
            cond = fn(f)
            print(f"{kind[0].upper()} {name:<22} {row(f, cond, asset, kind)}")
        except Exception as ex:
            print(name, 'ERROR', ex)


def pe(f, col, minp=750):
    return pct_expanding(f[col], minp)


SELL = [
    ('rsi14>70', 'sell', lambda f: f.rsi14 > 70), ('rsi14>80', 'sell', lambda f: f.rsi14 > 80),
    ('rsi14w>70', 'sell', lambda f: f.rsi14w > 70), ('rsi14w>80', 'sell', lambda f: f.rsi14w > 80),
    ('rsi14w>85', 'sell', lambda f: f.rsi14w > 85),
    ('rsi14m>70', 'sell', lambda f: f.rsi14m > 70), ('rsi14m>80', 'sell', lambda f: f.rsi14m > 80),
    ('bbp20>1', 'sell', lambda f: f.bbp20 > 1), ('bbp20w>1', 'sell', lambda f: f.bbp20w > 1),
    ('stoch14w>90', 'sell', lambda f: f.stoch14w > 90),
    ('d_sma200 p>=90', 'sell', lambda f: pe(f, 'd_sma200') >= 90), ('d_sma200 p>=97', 'sell', lambda f: pe(f, 'd_sma200') >= 97),
    ('d_ema200 p>=97', 'sell', lambda f: pe(f, 'd_ema200') >= 97),
    ('d_sma50w p>=90', 'sell', lambda f: pe(f, 'd_sma50w') >= 90), ('d_sma50w p>=97', 'sell', lambda f: pe(f, 'd_sma50w') >= 97),
    ('d_sma200w p>=90', 'sell', lambda f: pe(f, 'd_sma200w') >= 90), ('d_sma200w p>=97', 'sell', lambda f: pe(f, 'd_sma200w') >= 97),
    ('d_ema200w p>=97', 'sell', lambda f: pe(f, 'd_ema200w') >= 97),
    ('roc3m p>=97', 'sell', lambda f: pe(f, 'roc_3m') >= 97), ('roc12m p>=97', 'sell', lambda f: pe(f, 'roc_12m') >= 97),
    ('max52s (pos>=.99)', 'sell', lambda f: f.pos52w >= 0.99),
    ('vol x2 y dia +', 'sell', lambda f: (f.vr50 > 2) & (f.ret1 > 0)),
    ('pierde sma200', 'sell', lambda f: f.d_sma200 < 0), ('pierde sma50w', 'sell', lambda f: f.d_sma50w < 0),
    ('pierde sma10m', 'sell', lambda f: f.d_sma10m < 0), ('cruce muerte', 'sell', lambda f: f.gc == 0),
    ('macd sem <0', 'sell', lambda f: f.macdhw < 0),
]
BUY = [
    ('rsi14<30', 'buy', lambda f: f.rsi14 < 30), ('rsi14<25', 'buy', lambda f: f.rsi14 < 25),
    ('rsi14w<35', 'buy', lambda f: f.rsi14w < 35), ('rsi14w<30', 'buy', lambda f: f.rsi14w < 30),
    ('rsi14m<40', 'buy', lambda f: f.rsi14m < 40),
    ('bbp20<0', 'buy', lambda f: f.bbp20 < 0), ('bbp20w<0', 'buy', lambda f: f.bbp20w < 0),
    ('stoch14w<10', 'buy', lambda f: f.stoch14w < 10),
    ('d_sma200 p<=10', 'buy', lambda f: pe(f, 'd_sma200') <= 10), ('d_sma200 p<=3', 'buy', lambda f: pe(f, 'd_sma200') <= 3),
    ('d_sma50w p<=10', 'buy', lambda f: pe(f, 'd_sma50w') <= 10), ('d_sma200w p<=10', 'buy', lambda f: pe(f, 'd_sma200w') <= 10),
    ('d_sma200w p<=3', 'buy', lambda f: pe(f, 'd_sma200w') <= 3),
    ('dd_52w p<=10', 'buy', lambda f: pe(f, 'dd_52w') <= 10), ('dd_52w p<=3', 'buy', lambda f: pe(f, 'dd_52w') <= 3),
    ('dd_ath p<=10', 'buy', lambda f: pe(f, 'dd_ath') <= 10),
    ('min52s (pos<=.01)', 'buy', lambda f: f.pos52w <= 0.01),
    ('volat p>=95', 'buy', lambda f: pe(f, 'rv20') >= 95),
    ('vol x2 y dia -', 'buy', lambda f: (f.vr50 > 2) & (f.ret1 < 0)),
    ('sobre sma200', 'buy', lambda f: f.d_sma200 > 0), ('sobre sma10m', 'buy', lambda f: f.d_sma10m > 0),
    ('cruce oro', 'buy', lambda f: f.gc == 1),
    ('max52s (pos>=.99)', 'buy', lambda f: f.pos52w >= 0.99),
]

if __name__ == '__main__':
    assets = sys.argv[1:] or ASSETS
    for a in assets:
        run(a, SELL + BUY)
