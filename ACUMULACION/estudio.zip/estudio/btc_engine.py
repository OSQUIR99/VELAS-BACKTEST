import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, itertools
from lib import *; from strat import sim, perf, COST
a = 'BTC'; f = pd.read_parquet(f'{W}/feat3_{a}.parquet'); c = f['c']
LCOLS = [x for x in f.columns if x.startswith('L_')]
def liq_of(cols): return 100 * f[cols].mean(axis=1, skipna=True)
def rule(liq, trend_up, out_thr, in_thr, back_buf=None, dist=None):
    out = (liq <= out_thr) & ~trend_up
    back = (liq >= in_thr)
    if back_buf is not None: back = back | (dist > back_buf)
    return pd.Series(np.where(back, 1.0, np.where(out, 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
sp = pd.Timestamp(SPLIT[a]); start = pd.Timestamp('2011-11-05')
def ev(w):
    d = perf(c, w, a, start, sp); v = perf(c, w, a, sp, None); return d, v
print('--- rejilla: fuera si liq<=OUT y bajo MEDIA; dentro si liq>=IN o precio > media*(1+BUF) ---')
res = []
for ma, dist in (('sma200', f.d_sma200), ('sma150', c / sma(c, 150) - 1), ('sma250', c / sma(c, 250) - 1), ('sma50w', f.d_sma50w), ('ema200', f.d_ema200)):
    for out_thr, in_thr in ((20, 50), (33, 50), (33, 67), (40, 60), (45, 55)):
        for buf in (0.0, 0.05, 0.10):
            w = rule(f.liq, dist > 0, out_thr, in_thr, buf, dist)
            d, v = ev(w); res.append((ma, out_thr, in_thr, buf, d['mult'], v['mult'], d['ops'] + v['ops'], v['peor']))
G = pd.DataFrame(res, columns=['media', 'out', 'in', 'buf', 'D', 'V', 'ops', 'Vpeor'])
print(f"configs={len(G)} | D: min {G.D.min():.2f} mediana {G.D.median():.2f} max {G.D.max():.2f} | V: min {G.V.min():.2f} mediana {G.V.median():.2f} max {G.V.max():.2f} | % con D>1 y V>1: {100*((G.D>1)&(G.V>1)).mean():.0f}%")
print(G.groupby('media')[['D', 'V']].median().round(2).to_string())
print(G.groupby(['out', 'in'])[['D', 'V']].median().round(2).to_string())
print(G.groupby('buf')[['D', 'V']].median().round(2).to_string())
print('--- quitar una luz cada vez (regla base: sma200, out 33, in 50, buf 5%) ---')
for drop in [None] + LCOLS:
    cols = [x for x in LCOLS if x != drop]
    w = rule(liq_of(cols), f.d_sma200 > 0, 33, 50, 0.05, f.d_sma200); d, v = ev(w)
    print(f"sin {str(drop):<12} D x{d['mult']:.2f} V x{v['mult']:.2f} ops {d['ops']+v['ops']}")
print('--- solo una luz ---')
for only in LCOLS:
    l1 = 100 * f[only]
    w = rule(l1, f.d_sma200 > 0, 33, 50, 0.05, f.d_sma200); d, v = ev(w)
    print(f"solo {only:<12} D x{d['mult']:.2f} V x{v['mult']:.2f} ops {d['ops']+v['ops']}")
print('--- operaciones de la regla base ---')
w = rule(f.liq, f.d_sma200 > 0, 33, 50, 0.05, f.d_sma200)
wx = w.shift(1).fillna(1.0); ch = wx.diff().fillna(0)
sells = list(ch[ch < 0].index); buys = list(ch[ch > 0].index)
tot = 1.0
for s in sells:
    if s < start: continue
    b = next((x for x in buys if x > s), None)
    ps = c[s]; pb = c[b] if b is not None else c.iloc[-1]
    u = ps / pb * (1 - COST[a]) ** 2; tot *= u
    print(f"  venta {s.date()} {ps:>9.0f} -> recompra {(b.date() if b is not None else 'abierta')} {pb:>9.0f}  x{u:.2f}  liq venta {f.liq[s]:.0f}  ({(((b if b is not None else c.index[-1]) - s).days)} d)")
print('producto', round(tot, 2), '| estado actual', 'DENTRO' if w.iloc[-1] == 1 else 'FUERA', '| liq hoy', round(f.liq.iloc[-1]), '| d_sma200 hoy', round(f.d_sma200.iloc[-1], 3))
