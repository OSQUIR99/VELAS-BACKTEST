# -*- coding: utf-8 -*-
"""Compras: ¿mejora el precio medio repartir el dinero nuevo según una 'temperatura' en vez de comprar siempre lo mismo?
Presupuesto: 1 unidad de dinero por mes. Regla: multiplicador m(temperatura); lo no gastado va a una reserva; m>1 tira de la reserva.
Se compara con comprar 1 cada mes (DCA). Resultado: unidades finales (reserva sobrante valorada al precio final) y precio medio."""
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, sys
from lib import *

def temperature(f, asset):
    """Temperatura de precio 0-100 (100 = muy caliente): media de percentiles móviles de varios indicadores."""
    win = 1460 if asset == 'BTC' else 2520
    cols = ['d_sma200', 'd_sma50w', 'd_sma200w', 'rsi14w', 'bbp20w', 'dd_52w', 'roc_12m', 'rsi14']
    P = pd.concat([pct_rolling(f[k], win, win // 4) for k in cols], axis=1)
    return P.mean(axis=1, skipna=True).where(P.notna().sum(axis=1) >= 5)

def run_dca(c, T, mult_fn, lo, hi, maxres=None):
    m = c[(c.index >= lo) & (c.index < hi)]
    days = m.resample('MS').first().index
    first = [m[m.index >= d].index[0] for d in days if len(m[m.index >= d])]
    first = sorted(set(first))
    u = u0 = 0.0; res = 0.0; spent = 0.0
    for d in first:
        p = c[d]; t = T.get(d, np.nan)
        u0 += 1.0 / p
        k = 1.0 if np.isnan(t) else mult_fn(t)
        budget = 1.0 + res
        buy = min(k, budget)
        u += buy / p; res = budget - buy; spent += buy
    pf = m.iloc[-1]
    return {'n': len(first), 'u_dca': u0, 'u_regla': u + res / pf, 'u_regla_sin_reserva': u, 'reserva': res,
            'pm_dca': len(first) / u0, 'pm_regla': spent / u if u else np.nan}

RULES = {
    'suave (x2 frío, x0.5 caliente)': lambda t: 2.0 if t <= 20 else (0.5 if t >= 80 else 1.0),
    'fuerte (x3 <15, x2 <30, x0.5 >70, x0 >90)': lambda t: 3.0 if t <= 15 else (2.0 if t <= 30 else (0.0 if t >= 90 else (0.5 if t >= 70 else 1.0))),
    'solo frío (x0 salvo <30, x3)': lambda t: 3.0 if t <= 30 else 0.0,
    'lineal (2 - t/50)': lambda t: max(0.0, 2.0 - t / 50.0),
}
if __name__ == '__main__':
    rows = []
    for a in ASSETS:
        f = pd.read_parquet(f'{W}/feat2_{a}.parquet'); c = f['c']; T = temperature(f, a)
        T.to_frame('T').to_parquet(f'{W}/temp_{a}.parquet')
        sp = pd.Timestamp(SPLIT[a]); t0 = T.first_valid_index(); tend = c.index[-1] + pd.Timedelta(days=1)
        # rentabilidad posterior por tramo de temperatura
        S = pd.DataFrame({'T': T, 'fr3': f['fr_3m'], 'fr12': f['fr_12m']}).dropna(subset=['T'])
        S['b'] = pd.cut(S['T'], [0, 10, 25, 75, 90, 100], labels=['0-10', '10-25', '25-75', '75-90', '90-100'])
        for nm, g in (('D', S[S.index < sp]), ('V', S[S.index >= sp])):
            if len(g) < 300: continue
            tab = g.groupby('b').agg(dias=('T', 'size'), m3=('fr3', 'median'), m12=('fr12', 'median'), pos12=('fr12', lambda x: (x > 0).mean()))
            print(f"{a} {nm} temperatura -> mediana 3m / 12m / %positivos 12m: " + ' | '.join(f"{i}: {100*r.m3:+.0f}/{100*r.m12:+.0f}/{100*r.pos12:.0f}% ({int(r.dias)}d)" for i, r in tab.iterrows()))
        for rn, fn in RULES.items():
            for nm, lo, hi in (('D', t0, sp), ('V', max(sp, t0), tend)):
                if hi <= lo + pd.Timedelta(days=1500): continue
                r = run_dca(c, T, fn, lo, hi)
                rows.append({'activo': a, 'regla': rn, 'tramo': nm, 'unid vs DCA': r['u_regla'] / r['u_dca'], 'precio medio vs DCA': r['pm_regla'] / r['pm_dca'], 'reserva final (meses)': r['reserva']})
    R = pd.DataFrame(rows); R.to_csv(f'{W}/res_dca.csv', index=False)
    pd.set_option('display.width', 250)
    for col in ('unid vs DCA', 'precio medio vs DCA', 'reserva final (meses)'):
        print(f'\n--- {col} ---'); print(R.pivot_table(index=['regla', 'tramo'], columns='activo', values=col)[ASSETS].round(3).to_string())
