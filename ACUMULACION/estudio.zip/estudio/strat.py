# -*- coding: utf-8 -*-
"""Simulador en 'unidades': se parte de 1 unidad. Una regla da el % invertido objetivo (0..1) al cierre de cada día;
se ejecuta al cierre del día SIGUIENTE, con comisión. Resultado = unidades equivalentes finales (unidades + efectivo/precio)."""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from lib import *
COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}


def sim(c, w, cost):
    """c: precios; w: objetivo decidido al cierre t. Devuelve serie de unidades equivalentes y nº de operaciones."""
    wx = w.shift(1).fillna(1.0).values; p = c.values
    u, cash, prev = 1.0, 0.0, 1.0; ue = np.empty(len(p)); ntr = 0
    for i in range(len(p)):
        tw = wx[i]
        if tw != prev and not np.isnan(tw):
            tot = u * p[i] + cash
            cur_val = u * p[i]; tgt_val = tw * tot
            d = tgt_val - cur_val
            fee = abs(d) * cost
            if d > 0:   # compra
                d = min(d, cash); u += (d - d * cost) / p[i]; cash -= d
            else:       # venta
                u += d / p[i]; cash += (-d) - fee
            prev = tw; ntr += 1
        ue[i] = u + cash / p[i]
    return pd.Series(ue, index=c.index), ntr


def perf(c, w, asset, lo=None, hi=None):
    """Múltiplo de unidades frente a mantener en [lo, hi), partiendo de 1 unidad al inicio del tramo."""
    m = pd.Series(True, index=c.index)
    if lo is not None: m &= c.index >= lo
    if hi is not None: m &= c.index < hi
    cc, ww = c[m], w[m]
    ue, ntr = sim(cc, ww, COST[asset])
    return {'mult': ue.iloc[-1], 'peor': ue.min(), 'ops': ntr, 'fuera%': 100 * (1 - ww.shift(1).fillna(1).mean())}


def trend_rules(asset):
    """Devuelve dict nombre -> serie objetivo (1 = dentro, 0 = fuera)."""
    df = pd.read_parquet(f'{W}/px_{asset}.parquet'); c = df['c']
    R = {}
    for n in (100, 150, 200, 250):
        s = sma(c, n)
        R[f'D sma{n}'] = (c > s).astype(float).where(s.notna(), 1.0)
        # con banda del 3 %: salir solo si cae 3 % por debajo, volver si sube 3 % por encima
        up = c > s * 1.03; dn = c < s * 0.97
        st = pd.Series(np.where(up, 1.0, np.where(dn, 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
        R[f'D sma{n}±3%'] = st
    w = to_weekly(df, asset)['c']
    for n in (20, 30, 40, 50):
        s = sma(w, n); sig = (w > s).astype(float).where(s.notna(), 1.0)
        R[f'W sma{n}s'] = lag_to_daily(sig, c.index).fillna(1.0)
    for n in (21, 50):
        s = ema(w, n); sig = (w > s).astype(float).where(s.notna(), 1.0)
        R[f'W ema{n}s'] = lag_to_daily(sig, c.index).fillna(1.0)
    m = to_monthly(df)['c']
    for n in (8, 10, 12):
        s = sma(m, n); sig = (m > s).astype(float).where(s.notna(), 1.0)
        R[f'M sma{n}m'] = lag_to_daily(sig, c.index).fillna(1.0)
    s50, s200 = sma(c, 50), sma(c, 200)
    R['D cruce 50/200'] = (s50 > s200).astype(float).where(s200.notna(), 1.0)
    # momentum absoluto 12 meses
    bpy = BPY[asset]
    R['D mom12m>0'] = (c > c.shift(bpy)).astype(float).where(c.shift(bpy).notna(), 1.0)
    return c, R


if __name__ == '__main__':
    rows = []
    for a in ASSETS:
        c, R = trend_rules(a)
        sp = pd.Timestamp(SPLIT[a]); start = c.index[0] + pd.Timedelta(days=400)
        for nm, w in R.items():
            d = perf(c, w, a, start, sp) if sp > start + pd.Timedelta(days=700) else None
            v = perf(c, w, a, max(sp, start), None)
            rows.append({'activo': a, 'regla': nm, 'D mult': d['mult'] if d else np.nan, 'D peor': d['peor'] if d else np.nan, 'D ops': d['ops'] if d else np.nan,
                         'V mult': v['mult'], 'V peor': v['peor'], 'V ops': v['ops'], 'V fuera%': v['fuera%']})
    T = pd.DataFrame(rows); T.to_csv(f'{W}/res_trend.csv', index=False)
    pd.set_option('display.width', 250)
    for col in ('D mult', 'V mult', 'V peor', 'V ops'):
        print(f'\n--- {col} (unidades finales por cada 1 unidad mantenida; >1 = la regla acaba con más unidades) ---')
        print(T.pivot(index='regla', columns='activo', values=col)[ASSETS].round(2).to_string())
