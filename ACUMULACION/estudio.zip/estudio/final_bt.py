import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, json, sys
sys.path.insert(0, '/home/claude/work/tool')
import termometro as T
from lib import W, SPLIT, load_raw, sma
COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
P = T.leer_precios(); hasta = max(s.index[-1] for s in P.values())
L, V, info = T.luces_liquidez(hasta)
OUT = {}
def mult(c, w, a, lo, hi=None):
    m = (c.index >= lo) & ((c.index < hi) if hi is not None else True)
    ue, ops = T.simular(c[m], w[m], COST[a]); return ue, ops
def pares(ops, c):
    res = []; venta = None
    for (d, p, prev, tw) in ops:
        if tw < prev and venta is None: venta = [d, p, prev - tw]
        elif tw < prev: venta.append((d, p, prev - tw))
        elif tw > prev and venta is not None:
            res.append({'venta': str(venta[0].date()), 'p_venta': round(venta[1], 2), 'recompra': str(d.date()), 'p_recompra': round(p, 2), 'unid': round(venta[1] / p, 3), 'dias': (d - venta[0]).days}); venta = None
    if venta is not None: res.append({'venta': str(venta[0].date()), 'p_venta': round(venta[1], 2), 'recompra': 'abierta', 'p_recompra': round(float(c.iloc[-1]), 2), 'unid': round(venta[1] / float(c.iloc[-1]), 3), 'dias': (c.index[-1] - venta[0]).days})
    return res
def bloque(a, c, w, start, extra_splits=()):
    sp = pd.Timestamp(SPLIT[a]); r = {}
    ue_all, ops_all = mult(c, w, a, start)
    r['total'] = round(float(ue_all.iloc[-1]), 3); r['peor'] = round(float(ue_all.min()), 3); r['ops'] = len(ops_all)
    if sp > start:
        ue, ops = mult(c, w, a, start, sp); r['D'] = round(float(ue.iloc[-1]), 3); r['D_ops'] = len(ops)
        ue, ops = mult(c, w, a, sp); r['V'] = round(float(ue.iloc[-1]), 3); r['V_ops'] = len(ops); r['V_peor'] = round(float(ue.min()), 3)
    r['sub'] = []
    for lo, hi in extra_splits:
        ue, ops = mult(c, w, a, pd.Timestamp(lo), pd.Timestamp(hi)); r['sub'].append({'tramo': f'{lo[:4]}–{hi[:4]}', 'mult': round(float(ue.iloc[-1]), 2), 'ops': len(ops)})
    r['pares'] = pares(ops_all, c[c.index >= start])
    r['fuera_pct'] = round(100 * float((1 - w[w.index >= start].shift(1).fillna(1)).mean()), 1)
    step = 7 if a == 'BTC' else 5
    full = pd.DataFrame({'p': c[c.index >= start], 'u': ue_all, 'w': w[w.index >= start]}); s = full.iloc[::step]
    if s.index[-1] != full.index[-1]: s = pd.concat([s, full.iloc[[-1]]])
    r['serie'] = {'f': [str(d.date()) for d in s.index], 'p': [round(float(x), 2) for x in s.p], 'u': [round(float(x), 3) for x in s.u], 'w': [float(x) for x in s.w]}
    return r
# A. Bitcoin
a = 'BTC'; c = P[a]; liq = T.liquidez(L, a, c.index)
w = T.regla_btc(c, liq)
OUT['BTC'] = bloque(a, c, w, pd.Timestamp('2011-11-05'), (('2011-11-05', '2014-01-01'), ('2014-01-01', '2017-01-01'), ('2017-01-01', '2020-01-01'), ('2020-01-01', '2023-01-01'), ('2023-01-01', '2026-10-03')))
s = sma(c, 200); dist = c / s - 1
w1 = pd.Series(np.where((liq >= 50) | (dist > 0.05), 1.0, np.where((liq <= 33) & (dist < 0), 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
b1 = bloque(a, c, w1, pd.Timestamp('2011-11-05')); OUT['BTC']['golpe'] = {k: b1[k] for k in ('total', 'D', 'V', 'ops')}
wt = (c > s).astype(float).where(s.notna(), 1.0); bt = bloque(a, c, wt, pd.Timestamp('2011-11-05')); OUT['BTC']['solo_tendencia'] = {k: bt[k] for k in ('total', 'D', 'V', 'ops')}
OUT['BTC']['liq_serie'] = {'f': [str(d.date()) for d in liq['2011-11-05':].iloc[::7].index], 'v': [None if pd.isna(x) else round(float(x)) for x in liq['2011-11-05':].iloc[::7]]}
# B. plata y oro
for a in ('plata', 'oro'):
    c = P[a]; w = T.regla_parabolica(c, 252); OUT[a] = bloque(a, c, w, c.index[0] + pd.Timedelta(days=400))
    z = T.extension_z(c, 252); OUT[a]['z_serie'] = {'f': [str(d.date()) for d in z.dropna().iloc[::5].index], 'v': [round(float(x), 2) for x in z.dropna().iloc[::5]]}
# plata y oro semanal largo (evidencia)
from parab import run
for nm, a in (('plata_sem', 'plata'), ('oro_sem', 'oro')):
    wk = load_raw(a, '1w')['c']; r = np.log(wk).diff(); sd = r.ewm(span=52, min_periods=26).std(); zw = np.log(wk / sma(wk, 40)) / (sd * np.sqrt(40))
    TT = run(wk, zw >= 1.7, COST[a], back=(wk <= sma(wk, 40)), timeout=104)
    OUT[nm] = {'pares': [{'venta': str(x.venta.date()), 'p_venta': round(x.p_venta, 2), 'recompra': str(x.recompra.date()), 'p_recompra': round(x.p_recompra, 2), 'unid': round(x.unid, 3), 'subio_despues_pct': round(100 * (wk[x.venta:x.recompra].max() / x.p_venta - 1))} for x in TT.itertuples()], 'total': round(float(np.prod(TT.unid)), 2)}
# C. bolsa
paro, ratio = T.bandera_paro(pd.date_range('1967-01-01', hasta, freq='D'))
for a in ('sp500', 'nasdaq100'):
    c = P[a]; w = T.regla_bolsa(c, paro.reindex(c.index).ffill()); OUT[a] = bloque(a, c, w, max(pd.Timestamp('1968-06-01'), c.index[0] + pd.Timedelta(days=400)))
# D. señales de compra
OUT['compras'] = {}
for a in T.ACTIVOS:
    c = P[a]; bpy = T.BPY[a]; sc = T.senales_compra(a, c, L, V); sp = pd.Timestamp(SPLIT[a]); rows = []
    fr3 = c.shift(-(bpy // 4)) / c - 1; fr12 = c.shift(-bpy) / c - 1
    for k, cond in sc.items():
        prev = cond.shift(1).rolling(bpy // 12, min_periods=1).max().fillna(0).astype(bool); ep = cond & ~prev
        r = {'senal': k, 'desde': str(cond[cond].index[0].date()) if cond.any() else None}
        for nm, m in (('D', c.index < sp), ('V', c.index >= sp), ('T', np.ones(len(c), bool))):
            e3 = fr3[ep & m].dropna(); e12 = fr12[ep & m].dropna()
            r[nm] = {'n': int(len(e3)), 'm3': None if not len(e3) else round(100 * float(e3.mean()), 1), 'pos3': None if not len(e3) else round(100 * float((e3 > 0).mean())), 'base3': (None if not fr3[m].notna().any() else round(100 * float(fr3[m].mean()), 1)),
                     'm12': None if not len(e12) else round(100 * float(e12.mean()), 1), 'pos12': None if not len(e12) else round(100 * float((e12 > 0).mean())), 'base12': (None if not fr12[m].notna().any() else round(100 * float(fr12[m].mean()), 1)), 'basepos12': (None if not fr12[m].notna().any() else round(100 * float((fr12[m].dropna() > 0).mean())))}
        r['activa_hoy'] = bool(cond.iloc[-1])
        if cond.iloc[-1]:
            run_start = cond[::-1].cumprod()[::-1]; r['activa_desde'] = str(run_start[run_start == 1].index[0].date())
        rows.append(r)
    OUT['compras'][a] = rows
OUT['lectura'] = T.lectura()
json.dump(OUT, open(f'{W}/report_data.json', 'w'), ensure_ascii=False)
for a in ('BTC', 'plata', 'oro', 'sp500', 'nasdaq100'):
    r = OUT[a]; print(f"{a}: total x{r['total']} D x{r.get('D')} ({r.get('D_ops')} ops) V x{r.get('V')} ({r.get('V_ops')} ops) peor {r['peor']} fuera {r['fuera_pct']}% sub {[(x['tramo'], x['mult']) for x in r['sub']]}")
    print('   ', ' | '.join(f"{p['venta']}→{p['recompra']} x{p['unid']}" for p in r['pares']))
print('BTC golpe', OUT['BTC']['golpe'], 'solo tendencia', OUT['BTC']['solo_tendencia'])
print('plata_sem', OUT['plata_sem']['total'], [(p['venta'][:4], p['unid'], p['subio_despues_pct']) for p in OUT['plata_sem']['pares']])
print('oro_sem', OUT['oro_sem']['total'], [(p['venta'][:4], p['unid']) for p in OUT['oro_sem']['pares']])
for a in T.ACTIVOS:
    print(a)
    for r in OUT['compras'][a]:
        print(f"   {r['senal'][:58]:<58} D n={r['D']['n']} 3m {r['D']['m3']} (base {r['D']['base3']}) 12m {r['D']['m12']} ({r['D']['base12']}) | V n={r['V']['n']} 3m {r['V']['m3']} ({r['V']['base3']}) 12m {r['V']['m12']} ({r['V']['base12']}) pos12 {r['V']['pos12']} | hoy {r['activa_hoy']} {r.get('activa_desde','')}")
