import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from events import episodes
def sim_reserve(c, sig, beta, phi, lo, hi, bpy):
    m = c[(c.index >= lo) & (c.index < hi)]; s = episodes(sig.reindex(m.index).fillna(False), bpy // 12).values
    month = m.index.to_period('M'); first = np.r_[True, month[1:] != month[:-1]]
    u = u0 = res = 0.0; n = 0; dep = 0; p = m.values
    for i in range(len(p)):
        if first[i]:
            u0 += 1 / p[i]; u += beta / p[i]; res += 1 - beta; n += 1
        if s[i] and res > 0:
            x = phi * res; u += x / p[i]; res -= x; dep += 1
    return (u + res / p[-1]) / u0, u / u0, res, dep, n
rows = []
for a in ASSETS:
    f = pd.read_parquet(f'{W}/feat3_{a}.parquet'); c = f['c']; bpy = BPY[a]
    vol95 = pct_expanding(f.rv20, 750) >= 95
    fng = f['fng_crypto'] if a == 'BTC' else f['fng_cnn']
    SIG = {'volatilidad extrema (p>=95)': vol95, 'caída >=10% desde máx 52s': f.dd_52w <= -0.10, 'RSI diario<30': f.rsi14 < 30, 'miedo <=25 (desde 2011/2018)': fng <= 25}
    if a in ('sp500', 'nasdaq100'): SIG.update({'VIX>=30 (desde 1990)': f.vix >= 30, 'VIX>=30 o volatilidad extrema': (f.vix >= 30) | vol95})
    if a == 'BTC': SIG.update({'precio <= 1.1x media 200 sem': f.d_sma200w <= 0.10, 'liquidez>=67 y sobre sma200': (f.liq >= 67) & (f.d_sma200 > 0), 'financiación 7d<0': f.fund_7d < 0})
    if a in ('oro', 'plata'): SIG.update({'tipos reales -0.5 en 13s': f.ry10_13w <= -0.5, 'RSI semanal<35': f.rsi14w < 35})
    sp = pd.Timestamp(SPLIT[a]); t0 = c.index[0] + pd.Timedelta(days=1100); tend = c.index[-1] + pd.Timedelta(days=1)
    for sn, sig in SIG.items():
        for beta in (0.7, 0.5):
            r = {'activo': a, 'señal': sn, 'beta': beta}
            for nm, lo, hi in (('D', t0, sp), ('V', max(sp, t0), tend)):
                if hi <= lo + pd.Timedelta(days=1500) or not sig[(sig.index >= lo) & (sig.index < hi)].any(): continue
                x = sim_reserve(c, sig, beta, 1.0, lo, hi, bpy)
                r[nm] = x[0]; r[nm + '_n'] = x[3]
            rows.append(r)
T = pd.DataFrame(rows); T.to_csv(f'{W}/res_dca2.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print('Unidades finales frente a comprar lo mismo todos los meses (1.00 = igual). beta = parte que se compra siempre; el resto espera a la señal. n = veces que se usó la reserva')
print(T.round(3).to_string(index=False))
