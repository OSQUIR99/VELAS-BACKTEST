import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from strat import sim, perf, COST
rows = []
for a in ASSETS:
    f = pd.read_parquet(f'{W}/feat3_{a}.parquet'); c = f['c']
    liq = f['liq']; liq3 = f['liq3']
    up200 = f['d_sma200'] > 0; up50w = f['d_sma50w'] > 0
    def hyst(x, lo, hi):   # fuera si x<=lo, dentro si x>=hi
        s = pd.Series(np.where(x >= hi, 1.0, np.where(x <= lo, 0.0, np.nan)), index=x.index).ffill().fillna(1.0)
        return s
    def smooth(x, n=20): return x.rolling(n, min_periods=5).mean()
    R = {
        'liq>=50': (liq >= 50).astype(float).where(liq.notna(), 1.0),
        'liq media20 >=50': (smooth(liq) >= 50).astype(float).where(liq.notna(), 1.0),
        'liq hist (<=30 fuera, >=60 dentro)': hyst(smooth(liq), 30, 60).where(liq.notna(), 1.0),
        'liq3 media20 >=50': (smooth(liq3) >= 50).astype(float).where(liq3.notna(), 1.0),
        'fuera solo si liq<=33 Y bajo sma200': (~((liq <= 33) & ~up200)).astype(float),
        'fuera solo si liq media20<=40 Y bajo sma50w': (~((smooth(liq) <= 40) & ~up50w)).astype(float),
        'fuera si liq<=33 Y bajo sma200; vuelve con liq>=50 o sobre sma200+5%': None,
        'dentro si liq>=50 O sobre sma200': ((liq >= 50) | up200).astype(float),
    }
    # regla con histéresis combinada
    out = (liq <= 33) & ~up200; back = (liq >= 50) | (f['d_sma200'] > 0.05)
    st = pd.Series(np.where(back, 1.0, np.where(out, 0.0, np.nan)), index=c.index).ffill().fillna(1.0)
    R['fuera si liq<=33 Y bajo sma200; vuelve con liq>=50 o sobre sma200+5%'] = st
    sp = pd.Timestamp(SPLIT[a]); start = max(c.index[0] + pd.Timedelta(days=400), liq.first_valid_index())
    for nm, w in R.items():
        d = perf(c, w, a, start, sp) if sp > start + pd.Timedelta(days=700) else None
        v = perf(c, w, a, max(sp, start), None)
        rows.append({'activo': a, 'regla': nm, 'D': d['mult'] if d else np.nan, 'D ops': d['ops'] if d else np.nan, 'V': v['mult'], 'V peor': v['peor'], 'V ops': v['ops'], 'V fuera%': v['fuera%']})
T = pd.DataFrame(rows); T.to_csv(f'{W}/res_liq.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80)
for col in ('D', 'V', 'V peor', 'V ops', 'V fuera%'):
    print(f'\n--- {col} ---'); print(T.pivot(index='regla', columns='activo', values=col)[ASSETS].round(2).to_string())
