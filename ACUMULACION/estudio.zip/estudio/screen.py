# -*- coding: utf-8 -*-
"""Cribado: ¿qué indicadores anticipan la rentabilidad posterior de cada activo, y de forma estable en las dos mitades de su historia?"""
import pandas as pd, numpy as np, warnings, sys
warnings.filterwarnings('ignore')
from lib import *
from scipy.stats import spearmanr
E = pd.read_parquet(f'{W}/ext_daily.parquet')
E['stable_13w'] = E['stable_13w'].replace([np.inf, -np.inf], np.nan)
E.loc[E.index < '2013-01-01', 'exsply_90d'] = np.nan
PRICE = ['rsi14','rsi14w','rsi14m','bbp20','bbp20w','bbw20','stoch14','stoch14w','macdh','macdhw','d_sma50','d_sma200','d_ema200','d_sma20w','d_sma50w','d_ema50w','d_sma200w','d_ema200w','d_sma10m','sma200_slope','gc','dd_ath','dd_52w','up_52w','pos52w','roc_1m','roc_3m','roc_6m','roc_12m','rv20','rv60','vr50','vr20_250','upvol20']
COMMON = ['vix','move','fng_cnn','netliq_13w','netliq_26w','fedbs_13w','res_13w','gcb_13w','gcb_26w','gcb_52w','m2_yoy','m2_6m','m2real_yoy','nfci','nfci_13w','dxy_13w','dxy_d200','baa','baa_13w','ry10','ry10_13w','ff_26w','t10_13w','curve']
SPEC = {'BTC': ['fng_crypto','fund_7d','fund_30d','mvrv','exflow_30d','exsply_90d','etf_20d','etf_5d','stable_4w','stable_13w','cot_net_BTC','cot_idx_BTC','oi_13w_BTC','oi_pct3y_BTC','tff_am_BTC','tff_lev_BTC','tff_am_13w_BTC'],
        'sp500': ['cot_net_sp500','cot_idx_sp500','oi_13w_sp500','oi_pct3y_sp500','tff_am_sp500','tff_lev_sp500','tff_am_13w_sp500'],
        'nasdaq100': ['cot_net_nasdaq100','cot_idx_nasdaq100','oi_13w_nasdaq100','oi_pct3y_nasdaq100','tff_am_nasdaq100','tff_lev_nasdaq100','tff_am_13w_nasdaq100'],
        'oro': ['cot_net_oro','cot_idx_oro','oi_13w_oro','oi_pct3y_oro'], 'plata': ['cot_net_plata','cot_idx_plata','oi_13w_plata','oi_pct3y_plata']}
allrows = []
for a in ASSETS:
    f = pd.read_parquet(f'{W}/feat_{a}.parquet')
    X = f.join(E[COMMON + SPEC[a]], how='left')
    X.to_parquet(f'{W}/feat2_{a}.parquet')
    step = 7 if a == 'BTC' else 5
    S = X.iloc[::step]
    for ind in PRICE + COMMON + SPEC[a]:
        d = S[[ind, 'fr_1m', 'fr_3m', 'fr_12m']].dropna(subset=[ind, 'fr_3m'])
        if len(d) < 80: continue
        mid = len(d) // 2
        r = {'activo': a, 'ind': ind, 'desde': d.index[0].year, 'n': len(d)}
        for nm, g in (('H1', d.iloc[:mid]), ('H2', d.iloc[mid:])):
            r[f'ic3_{nm}'] = spearmanr(g[ind], g['fr_3m']).correlation
            g12 = g.dropna(subset=['fr_12m'])
            r[f'ic12_{nm}'] = spearmanr(g12[ind], g12['fr_12m']).correlation if len(g12) > 30 else np.nan
            q = g[ind].rank(pct=True)
            r[f'top_{nm}'] = 100 * (g.loc[q >= 0.9, 'fr_3m'].mean() - g['fr_3m'].mean())
            r[f'bot_{nm}'] = 100 * (g.loc[q <= 0.1, 'fr_3m'].mean() - g['fr_3m'].mean())
        allrows.append(r)
R = pd.DataFrame(allrows)
R.to_csv(f'{W}/screen_ic.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
for a in ASSETS:
    g = R[R.activo == a].copy()
    st3 = (np.sign(g.ic3_H1) == np.sign(g.ic3_H2)) & (g[['ic3_H1', 'ic3_H2']].abs().min(axis=1) >= 0.08)
    st12 = (np.sign(g.ic12_H1) == np.sign(g.ic12_H2)) & (g[['ic12_H1', 'ic12_H2']].abs().min(axis=1) >= 0.12)
    k = g[st3 | st12].copy()
    k['fuerza'] = k[['ic3_H1', 'ic3_H2']].abs().min(axis=1) + k[['ic12_H1', 'ic12_H2']].abs().min(axis=1).fillna(0)
    k = k.sort_values('fuerza', ascending=False)
    print(f"\n=== {a}: {len(k)} estables de {len(g)} ===")
    print(k[['ind', 'desde', 'n', 'ic3_H1', 'ic3_H2', 'ic12_H1', 'ic12_H2', 'top_H1', 'top_H2', 'bot_H1', 'bot_H2']].round(2).to_string(index=False))
