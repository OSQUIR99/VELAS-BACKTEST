from rt_lib import *
pd.set_option('display.width', 250)
for a in ('BTC', 'ETH'):
    p = prices(a); c = p.c; cv = c.values; idx = c.index; O = osc_set(a, p)
    tab = {}; tab2 = {}
    for k in range(3, 13):
        bear = divergences(c, O['rsi'], k, 60, 8 if k >= 5 else 5, 'bear').values; bi = np.flatnonzero(divergences(c, O['rsi'], k, 60, 8 if k >= 5 else 5, 'bull').values)
        for ch in (0.10, 0.15, 0.20, 0.30):
            t = trades(cv, np.flatnonzero(bear), bi, 10 ** 6, ch, COSTE[a]); r = resumen(cv, idx, t, CORTE[a])
            tab[(k, ch)] = r['total']; tab2[(k, ch)] = f"{r['n']}"
            if a == 'BTC' and k == 8 and ch == 0.15:
                g = np.array([x[2] for x in t]); top = np.argsort(-g)[:5]
                print('k=8 15%: mayores ganancias', [(str(idx[t[i][0]].date()), str(idx[t[i][1]].date()), round(100 * (np.exp(g[i]) - 1))) for i in top])
                print('   sin las 2 mejores: x', round(float(np.exp(np.sort(g)[:-2].sum())), 2), '| desde 2013: x', round(float(np.exp(g[idx[[x[0] for x in t]] >= '2013-01-01'].sum())), 2), '| desde 2017: x', round(float(np.exp(g[idx[[x[0] for x in t]] >= '2017-01-01'].sum())), 2))
    T = pd.Series(tab).unstack(); N = pd.Series(tab2).unstack()
    print(a, 'RSI, L=60, recompra en divergencia alcista o si sube X% (columnas). Unidades finales frente a mantener:'); print(T.round(2).to_string()); print('nº operaciones:'); print(N.to_string())
