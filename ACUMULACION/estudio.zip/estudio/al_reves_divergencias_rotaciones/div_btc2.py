from rt_lib import *
p = prices('BTC'); c = p.c; cv = c.values; idx = c.index; O = osc_set('BTC', p)
rows = {}
for k in range(5, 13):
    bear = divergences(c, O['rsi'], k, 60, 8, 'bear').values; bi = np.flatnonzero(divergences(c, O['rsi'], k, 60, 8, 'bull').values)
    for ch in (0.10, 0.15, 0.20, 0.30):
        t = trades(cv, np.flatnonzero(bear), bi, 10 ** 6, ch, COSTE['BTC']); ts = idx[[x[0] for x in t]]; g = np.array([x[2] for x in t])
        rows[(k, ch)] = {y: round(float(np.exp(g[ts >= f'{y}-01-01'].sum())), 2) for y in (2013, 2017, 2020, 2023)}
R = pd.DataFrame(rows).T
for y in R.columns: print('desde', y, '| variantes >1:', int((R[y] > 1).sum()), 'de', len(R), '| mediana x', R[y].median(), '| min', R[y].min(), 'max', R[y].max())
