"""Los indicadores AL REVÉS: las señales contrarias (sobreventa, divergencia alcista, giro al alza en mínimos, miedo...) usadas como VENTA,
con las mismas 17 formas de recomprar. Y la prueba de elegir sin saber el futuro mezclando señales normales y contrarias."""
import pickle, sys
from rt_lib import *
import swing as sw, swing_wf
from swing import onset, streak

def signals_inv(a, F):
    S = {}; c = F['c']
    def lev(name, s, ths, ge=False):
        for t in ths: S[f'INV {name}{">=" if ge else "<="}{t}'] = onset(s >= t if ge else s <= t)
    lev('rsi14', F['rsi14'], (30, 25, 20)); lev('rsi7', F['rsi7'], (15, 10)); lev('rsi2', F['rsi2'], (2, 0.5))
    for t in (40, 35, 30): S[f'INV rsi14w<={t}'] = onset((F['rsi14w_e'] <= t).where(F['rsi14w_e'].notna()).ffill().fillna(False)) & F['rsi14w_e'].notna()
    lev('bbz', F['bbz'], (-2, -2.5, -3)); lev('z20', F['z20'], (-2, -2.5, -3)); lev('z50', F['z50'], (-1.5, -2, -2.5, -3)); lev('kelt', F['kelt'], (-2.5, -3, -4))
    lev('d20p', F['d20p'], (3, 1)); lev('d50p', F['d50p'], (3, 1)); lev('roc5p', F['roc5p'], (1,)); lev('roc10p', F['roc10p'], (1,)); lev('roc20p', F['roc20p'], (3, 1)); lev('roc60p', F['roc60p'], (3, 1))
    dn = streak(c < c.shift(1)); lev('racha_baja', dn, (5, 7), ge=True)
    ll20 = F['l'].rolling(20, min_periods=20).min()
    S['INV martillo_min20'] = (F['l'] <= ll20) & (c > F['o']) & (F['clv'] > 0.7)
    S['INV envolvente_min20'] = (F['l'] <= ll20) & (F['l'] < F['l'].shift(1)) & (c > F['h'].shift(1))
    S['INV climax_baja'] = (F['vr'] >= 2.5) & (c <= F['lo20'])
    was20 = F['rsi14'].rolling(10, min_periods=1).min() <= 20; was25 = F['rsi14'].rolling(10, min_periods=1).min() <= 25
    S['INV rsi_x30_de20'] = onset(F['rsi14'] > 30) & was20; S['INV rsi_x30_de25'] = onset(F['rsi14'] > 30) & was25
    S['INV bb_reentra_arriba'] = onset(F['bbz'] > -2) & (F['bbz'].rolling(5, min_periods=1).min() <= -2.5)
    be20 = streak(c < F['e20']); be50 = streak(c < F['s50'])
    S['INV recupera_e20'] = (c > F['e20']) & (be20.shift(1) >= 10); S['INV recupera_s50'] = (c > F['s50']) & (be50.shift(1) >= 20)
    S['INV max20'] = onset(c >= F['hi20']); S['INV max10'] = onset(c >= c.rolling(10).max())
    S['INV e10x20_arriba'] = onset(F['e10'] > F['e20']); S['INV e20x50_arriba'] = onset(F['e20'] > F['e50'])
    for k in ('div_bull_rsi', 'div_bull_macd', 'div_bull_cmf', 'div_bull_delta', 'divw_bull_rsi', 'divw_bull_macd'):
        if k in F: S['INV ' + k] = F[k].fillna(False).astype(bool)
    if a == 'BTC':
        lev('fng', F['fng_crypto'], (25, 20, 12)); lev('fund7', F['fund_7d'], (0, -10)); lev('mvrv', F['mvrv'], (1.5, 1.2))
    else:
        if 'fng_cnn' in F: lev('fng', F['fng_cnn'], (25, 15))
        if a in ('sp500', 'nasdaq100'): lev('vix', F['vix'], (25, 30, 40), ge=True)
    if f'cot_idx_{a}' in F: lev('cot_idx', F[f'cot_idx_{a}'], (10, 3))
    if 'liq' in F: S['INV liq_favorable'] = onset(F['liq'] >= 67)
    return {k: s.fillna(False).astype(bool) for k, s in S.items()}

if __name__ == '__main__':
    orig = sw.signals
    for a in ASSETS:
        sw.signals = signals_inv
        res, TR, F = sw.study(a, tag='_inv')
        sw.signals = orig
        b = res[res.reg == 'bull']; t = res[res.reg == 'todo']
        ok = b[(b.s1 > 0) & (b.s2 > 0)]
        print(f"{a}: contrarias en fase alcista {len(b)} | con más unidades {100*(b.suma>0).mean():.1f}% | dos mitades {100*((b.s1>0)&(b.s2>0)).mean():.1f}% | media/op {100*(np.exp(b.suma.sum()/b.n.sum())-1):+.2f}% (azar {100*(np.exp((b.base*b.n).sum()/b.n.sum())-1):+.2f}%) || todos los regímenes: más unidades {100*(t.suma>0).mean():.1f}%, media/op {100*(np.exp(t.suma.sum()/t.n.sum())-1):+.2f}% (azar {100*(np.exp((t.base*t.n).sum()/t.n.sum())-1):+.2f}%)")
        # mezcla: elegir cada año entre normales y contrarias las que mejor iban
        TR0 = pickle.load(open(f'{W}/swing_tr_{a}.pkl', 'rb')); TRi = pickle.load(open(f'{W}/swing_tr_{a}_inv.pkl', 'rb'))
        pickle.dump({**TR0, **TRi}, open(f'{W}/swing_tr_{a}_mix.pkl', 'wb'))
        out, picks = swing_wf.wf(a, K=(1, 5, 20), crit='t', tag='_mix')
        print('   elegir cada 1-ene las mejores hasta entonces (normales + contrarias):', ' | '.join(f'{k} reglas: x{np.exp(sum(x[1] for x in v)):.2f} (años +{sum(x[1]>0 for x in v)}/-{sum(x[1]<0 for x in v)})' for k, v in out.items()), '| desde', out[1][0][0])
        print('   últimas elegidas:', [p[1] for p in picks[-2:]])
