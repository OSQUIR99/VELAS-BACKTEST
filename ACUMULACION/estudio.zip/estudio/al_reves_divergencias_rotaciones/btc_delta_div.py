"""BTC: divergencia bajista del delta de volumen (compras agresivas menos ventas agresivas, dato real de Binance) en fase alcista,
recompra al volver a la media de 20 sesiones. Vecinos y comprobación en ETH con el delta aproximado."""
import itertools
from rt_lib import *
import swing as sw
pd.set_option('display.width', 250)
def run_asset(a, oscs):
    p = prices(a) if a != 'BTC' else pd.read_parquet(f'{W}/px_BTC.parquet'); c = p.c; cv = c.values; idx = c.index; cost = COSTE[a]
    s200 = sma(c, 200); bull = ((c > s200) & (s200 > s200.shift(20))).values
    e20 = ema(c, 20); e10 = ema(c, 10); s50 = sma(c, 50); r14 = rsi(c, 14)
    RB = {'e20': (np.flatnonzero((c <= e20).values), 60, None), 'e20c': (np.flatnonzero((c <= e20).values), 60, 0.15), 'e10': (np.flatnonzero((c <= e10).values), 60, None),
          's50': (np.flatnonzero((c <= s50).values), 120, None), 'rsi50': (np.flatnonzero((r14 <= 50).values), 60, None), 'T10': (np.array([], int), 10, None), 'T20': (np.array([], int), 20, None)}
    rows = []
    for on, (k, L) in itertools.product(oscs, ((3, 40), (5, 60), (8, 90), (5, 40), (8, 60), (3, 60))):
        o = oscs[on]
        bear = divergences(c, o, k, L, 8 if k >= 5 else 5, 'bear').values
        first = o.first_valid_index(); valid = (idx >= first + pd.Timedelta(days=90))
        si = np.flatnonzero(bear & bull & valid)
        for rn, (rb, tmax, ch) in RB.items():
            t = trades(cv, si, rb, tmax, ch, cost)
            if len(t) < 5: continue
            ts = idx[[x[0] for x in t]]; g = np.array([x[2] for x in t])
            # azar: ventas en días alcistas válidos al azar, misma recompra
            pool = np.flatnonzero(bull & valid & s200.notna().values); rng = np.random.default_rng(1); sims = []
            for _ in range(300):
                tt = trades(cv, np.sort(rng.choice(pool, 3 * len(t), replace=False)), rb, tmax, ch, cost)[:len(t)]; sims.append(np.mean([x[2] for x in tt]))
            rows.append(dict(osc=on, k=k, L=L, rec=rn, n=len(g), gana=round((g > 0).mean(), 2), total=round(np.exp(g.sum()), 3),
                             a17_19=round(np.exp(g[ts < '2020-01-01'].sum()), 3), a20_22=round(np.exp(g[(ts >= '2020-01-01') & (ts < '2023-01-01')].sum()), 3), a23_26=round(np.exp(g[ts >= '2023-01-01'].sum()), 3),
                             media=round(100 * (np.exp(g.mean()) - 1), 2), azar=round(100 * (np.exp(np.median(sims)) - 1), 2), p_azar=round(float((np.array(sims) >= g.mean()).mean()), 3)))
    return pd.DataFrame(rows)
f3 = pd.read_parquet(f'{W}/feat3_BTC.parquet')
pb = pd.read_parquet(f'{W}/px_BTC.parquet')
O = {k: f3[k].reindex(pb.index) for k in ('delta7', 'delta30', 'delta90', 'cmf20', 'cmf60', 'cvd_30')}
R = run_asset('BTC', O); R.to_csv('res_btc_delta_div.csv', index=False)
print('BTC: variantes', len(R), '| ganan unidades', f'{100*(R.total>1).mean():.0f}%', '| mediana x', R.total.median(), '| las tres épocas >1:', f"{100*((R.a17_19>=1)&(R.a20_22>=1)&(R.a23_26>=1)).mean():.0f}%", '| mejor que el azar (p<0,05):', f'{100*(R.p_azar<0.05).mean():.0f}%')
print(R.pivot_table(index='osc', columns='rec', values='total', aggfunc='median').round(2).to_string())
print('por épocas (mediana):', R[['a17_19', 'a20_22', 'a23_26']].median().round(2).to_dict())
print(R[R.osc.isin(['delta30']) & R.rec.isin(['e20'])].to_string(index=False))
# ETH con el delta aproximado
pe = prices('ETH'); pe = pe[pe.index >= '2017-08-17']; c, h, l, v = pe.c, pe.h, pe.l, pe.v
rng_ = (h - l).replace(0, np.nan); clv = (((c - l) - (h - c)) / rng_).fillna(0)
OE = {'cmf20': (clv * v).rolling(20, min_periods=15).sum() / v.rolling(20, min_periods=15).sum(), 'cmf60': (clv * v).rolling(60, min_periods=45).sum() / v.rolling(60, min_periods=45).sum()}
import rt_lib; old = rt_lib.prices
RE = None
def pr(a): return pe
globals()['prices'] = pr
RE = run_asset('ETH', OE)
print('\nETH (delta aproximado): variantes', len(RE), '| ganan', f'{100*(RE.total>1).mean():.0f}%', '| mediana x', RE.total.median(), '| épocas', RE[['a17_19', 'a20_22', 'a23_26']].median().round(2).to_dict())
