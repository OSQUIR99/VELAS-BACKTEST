# -*- coding: utf-8 -*-
"""Utilidades para las pruebas del 4-oct (al revés, divergencias de ida y vuelta, rotaciones). Todo causal."""
import warnings; warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
from lib import *

def divergences(price, osc, k, L, minsep, kind, level=None, eps=0.0):
    """Idéntica a feat3.divergences: True en la barra en que la divergencia queda CONFIRMADA (k barras después del pivote)."""
    p = price.values; o = osc.values; n = len(p); out = np.zeros(n, bool)
    if kind == 'bear':
        piv = (price == price.rolling(2 * k + 1, center=True, min_periods=2 * k + 1).max()).values
    else:
        piv = (price == price.rolling(2 * k + 1, center=True, min_periods=2 * k + 1).min()).values
    idxs = np.where(piv)[0]
    for j in range(1, len(idxs)):
        i2 = idxs[j]
        if i2 + k >= n or np.isnan(o[i2]): continue
        for jj in range(j - 1, -1, -1):
            i1 = idxs[jj]
            if i2 - i1 > L: break
            if i2 - i1 < minsep or np.isnan(o[i1]): continue
            if kind == 'bear':
                if p[i2] > p[i1] * (1 + eps) and o[i2] < o[i1] and (level is None or o[i1] >= level): out[i2 + k] = True
            else:
                if p[i2] < p[i1] * (1 - eps) and o[i2] > o[i1] and (level is None or o[i1] <= level): out[i2 + k] = True
            break
    return pd.Series(out, index=price.index)

def raw(sym):
    df = pd.read_parquet(f'{BASE}/CRIPTO/{sym}/1d.parquet'); df['date'] = (df['fecha'] + pd.Timedelta(hours=4)).dt.floor('D')
    df = df.rename(columns={'apertura': 'o', 'maximo': 'h', 'minimo': 'l', 'cierre': 'c', 'volumen': 'v'}).set_index('date')[['o', 'h', 'l', 'c', 'v']].astype(float)
    return df[~df.index.duplicated(keep='last')].sort_index()

def load_eth():
    df = raw('ETH')
    cm = pd.read_csv(f'{W}/data/eth_coinmetrics.csv', usecols=['time', 'PriceUSD'], parse_dates=['time']).set_index('time')['PriceUSD'].dropna()
    pre = cm[cm.index < df.index[0]]; pre = pre[pre.index >= '2015-09-01']
    pre = pd.DataFrame({'o': pre, 'h': pre, 'l': pre, 'c': pre, 'v': np.nan})
    return pd.concat([pre, df]).sort_index()

def load_hype():
    d = pd.read_csv(f'{W}/data/hype_daily.csv', parse_dates=['fecha']).set_index('fecha')
    return d.rename(columns={'apertura': 'o', 'maximo': 'h', 'minimo': 'l', 'cierre': 'c', 'volumen': 'v'})[['o', 'h', 'l', 'c', 'v']].astype(float)

def prices(a):
    if a == 'ETH': return load_eth()
    if a == 'HYPE': return load_hype()
    return pd.read_parquet(f'{W}/px_{a}.parquet')

COSTE = {'BTC': 0.0015, 'ETH': 0.0015, 'HYPE': 0.002, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
CORTE = dict(SPLIT); CORTE['plata'] = '2018-01-01'; CORTE['ETH'] = '2021-01-01'; CORTE['HYPE'] = '2025-10-01'
BPY2 = dict(BPY); BPY2['ETH'] = 365; BPY2['HYPE'] = 365

def osc_set(a, p):
    c, h, l, v = p.c, p.h, p.l, p.v
    O = {'rsi': rsi(c, 14), 'macd': macd_hist(c)}
    rng = (h - l).replace(0, np.nan); clv = (((c - l) - (h - c)) / rng).fillna(0)
    cmf = (clv * v).rolling(20, min_periods=15).sum() / v.rolling(20, min_periods=15).sum()
    if a == 'BTC':
        f3 = pd.read_parquet(f'{W}/feat3_BTC.parquet').reindex(p.index); O['delta'] = f3['delta30']
    else:
        O['delta'] = cmf
    return O

def trades(c, sell_idx, rb_idx, tmax, chase, cost, lag=1):
    """Venta al cierre siguiente a la señal; recompra al cierre siguiente al primer día de rb_idx posterior a la venta
    (o tope de barras, o si el precio sube 'chase' sobre el de venta). Sin solapes."""
    n = len(c); out = []; free = 0; k2 = 2 * np.log(1 - cost)
    for s in sell_idx:
        ts = s + lag
        if ts <= free: continue
        if ts >= n - 1: break
        dmax = min(ts + tmax, n - 1 - lag); d = dmax
        j = np.searchsorted(rb_idx, ts + 1)
        if j < len(rb_idx) and rb_idx[j] < d: d = rb_idx[j]
        if chase is not None:
            w = np.flatnonzero(c[ts + 1:d + 1] >= c[ts] * (1 + chase))
            if len(w): d = min(d, ts + 1 + w[0])
        tr = d + lag
        abierta = tr >= n - 1 and dmax == n - 1 - lag
        tr = min(tr, n - 1)
        out.append((ts, tr, np.log(c[ts] / c[tr]) + (k2 if not abierta else k2 / 2), abierta)); free = tr
    return out

def resumen(c, idx, t, corte):
    if not t: return dict(n=0)
    ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t]); h1 = idx[ts] < pd.Timestamp(corte)
    fuera = sum(x[1] - x[0] for x in t) / len(c)
    return dict(n=len(g), gana=round(float((g > 0).mean()), 2), total=round(float(np.exp(g.sum())), 2), m1=round(float(np.exp(g[h1].sum())), 2), m2=round(float(np.exp(g[~h1].sum())), 2),
                n1=int(h1.sum()), n2=int((~h1).sum()), fuera=round(100 * fuera), media=round(100 * (np.exp(g.mean()) - 1), 2))
