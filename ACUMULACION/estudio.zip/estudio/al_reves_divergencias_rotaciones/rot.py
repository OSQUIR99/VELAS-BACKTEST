"""Rotación por fuerza relativa entre activos: BTC/ETH (desde 2016 y desde 2017), BTC/ETH/HYPE (desde dic-2024), S&P 500/Nasdaq 100 (desde 1985).
Decisión al cierre t con datos hasta t; ejecución al cierre t+1; comisión por cada compra y cada venta."""
import itertools, sys
from rt_lib import *
pd.set_option('display.width', 250)

def sim(P, W, cost):
    """P: precios (columnas = activos). W: peso objetivo decidido al cierre de cada día (filas que suman 1; NaN = mantener).
    Devuelve log-valor de la estrategia y número de cambios."""
    R = P.pct_change().fillna(0)
    Wt = W.ffill().fillna(1 / P.shape[1])
    held = Wt.shift(2).fillna(1 / P.shape[1])      # decidido en t, ejecutado al cierre t+1, rinde desde t+2
    turn = Wt.shift(1).fillna(1 / P.shape[1]).diff().abs().sum(axis=1).fillna(0)   # se paga el día de la ejecución
    port = (held * R).sum(axis=1) - turn * cost
    return np.log1p(port).cumsum(), int((turn > 1e-9).sum())

def bench(P):
    out = {f'mantener {c}': np.log(P[c] / P[c].iloc[0]) for c in P}
    out['mitad y mitad sin tocar'] = np.log((P / P.iloc[0]).mean(axis=1))
    return out

def rules(P, freq, wk_anchor):
    """Devuelve dict nombre -> pesos objetivo (DataFrame)."""
    L = np.log(P); out = {}
    dec = pd.Series(True, index=P.index) if freq == 'd' else pd.Series(P.index.dayofweek == wk_anchor, index=P.index)
    n = P.shape[1]
    for N in (20, 30, 60, 90, 120, 180, 252):
        mom = L - L.shift(N)
        for h in (0.0, 0.05, 0.10):
            M = mom.values; D = dec.values; Wv = np.full(M.shape, np.nan); cur = -1
            for i in range(len(M)):
                if not D[i] or np.isnan(M[i]).any(): continue
                b = int(np.argmax(M[i]))
                if cur < 0 or (b != cur and M[i, b] - M[i, cur] > h): cur = b
                Wv[i] = 0.0; Wv[i, cur] = 1.0
            W = pd.DataFrame(Wv, index=P.index, columns=P.columns)
            out[f'fuerza {N}d, margen {int(h*100)}%'] = W
    if n == 2:
        a, b = P.columns; lr = L[a] - L[b]
        for N in (20, 50, 100, 200):
            m = lr.rolling(N).mean(); W = pd.DataFrame(np.nan, index=P.index, columns=P.columns)
            sel = (lr > m).where(m.notna())
            W[a] = sel.astype(float).where(sel.notna() & dec); W[b] = 1 - W[a]
            out[f'par sobre su media {N}d'] = W
        for win, z0 in itertools.product((180, 365, 730), (1.0, 1.5, 2.0)):
            mu = lr.rolling(win, min_periods=win // 2).mean(); sd = lr.rolling(win, min_periods=win // 2).std(); z = (lr - mu) / sd
            st = pd.Series(np.nan, index=P.index); st[z > z0] = 0.0; st[z < -z0] = 1.0; st[z.abs() < 0.25] = 0.5
            st = st.ffill().where(dec)
            W = pd.DataFrame({a: st, b: 1 - st}); out[f'vuelta a la media del par z{z0} ({win}d)'] = W
    return out

def evaluate(name, P, cost, freq, anchor, cuts):
    B = bench(P); res = []
    for rn, Wd in rules(P, freq, anchor).items():
        lv, ncamb = sim(P, Wd, cost)
        row = dict(par=name, frec=freq, regla=rn, cambios_año=round(ncamb / (len(P) / (365 if 'BTC' in P.columns else 252)), 1))
        for bn, bv in B.items(): row[bn] = round(float(np.exp(lv.iloc[-1] - bv.iloc[-1])), 2)
        bb = B['mitad y mitad sin tocar']
        segs = [P.index[0]] + [pd.Timestamp(c) for c in cuts] + [P.index[-1]]
        segs = [lv.index[min(lv.index.searchsorted(s), len(lv) - 1)] for s in segs]
        best = max(B[k].iloc[-1] for k in B if k.startswith('mantener')); row['mejor de los dos (o tres)'] = round(float(np.exp(lv.iloc[-1] - best)), 2)
        for i in range(len(segs) - 1):
            s0, s1 = segs[i], segs[i + 1]
            row[f'{s0.year}-{s1.year}'] = round(float(np.exp((lv[s1] - lv[s0]) - (bb[s1] - bb[s0]))), 2)
            # frente al mejor de los activos en ese tramo
            bseg = max(B[k][s1] - B[k][s0] for k in B if k.startswith('mantener'))
            row[f'mejor {s0.year}-{s1.year}'] = round(float(np.exp((lv[s1] - lv[s0]) - bseg)), 2)
        res.append(row)
    return pd.DataFrame(res)

if __name__ == '__main__':
    btc = pd.read_parquet(f'{W}/px_BTC.parquet')['c']; eth = load_eth()['c']; hype = load_hype()['c']
    tasks = []
    P1 = pd.concat([btc, eth], axis=1, keys=['BTC', 'ETH'], sort=True).dropna()
    tasks.append(('BTC/ETH desde 2016', P1[P1.index >= '2016-06-01'], 0.0015, ['2018-01-01', '2020-01-01', '2022-01-01', '2024-01-01']))
    tasks.append(('BTC/ETH desde 2019', P1[P1.index >= '2019-01-01'], 0.0015, ['2021-01-01', '2023-01-01', '2025-01-01']))
    P3 = pd.concat([btc, eth, hype], axis=1, keys=['BTC', 'ETH', 'HYPE'], sort=True).dropna()
    tasks.append(('BTC/ETH/HYPE desde dic-2024', P3, 0.0015, ['2025-10-01']))
    sp = pd.read_parquet(f'{W}/px_sp500.parquet')['c']; nq = pd.read_parquet(f'{W}/px_nasdaq100.parquet')['c']
    P2 = pd.concat([sp, nq], axis=1, keys=['S&P 500', 'Nasdaq 100'], sort=True).dropna()
    tasks.append(('S&P 500/Nasdaq 100 desde 1985', P2, 0.001, ['1995-01-01', '2005-01-01', '2015-01-01']))
    allr = []
    for name, P, cost, cuts in tasks:
        for freq in ('d', 'w'):
            anchor = 6 if 'BTC' in P.columns else 4
            r = evaluate(name, P, cost, freq, anchor, cuts); allr.append(r)
            bcols = [c for c in r.columns if c.startswith('mantener') or c.startswith('mitad')] + ['mejor de los dos (o tres)']
            segc = [c for c in r.columns if c[:4].isdigit()]; segb = [c for c in r.columns if c.startswith('mejor ') and c[6:10].isdigit()]
            print(f'\n== {name} | decisión {"diaria" if freq=="d" else "semanal"} | {P.index[0].date()} -> {P.index[-1].date()} | variantes {len(r)}')
            print('   frente a cada referencia: % de variantes que ganan / mediana:', ' | '.join(f'{c}: {100*(r[c]>1).mean():.0f}% / x{r[c].median():.2f}' for c in bcols))
            print('   por tramos frente a mitad y mitad (mediana):', {c: r[c].median() for c in segc}, '| variantes que ganan en todos los tramos:', f"{100*(r[segc]>1).all(axis=1).mean():.0f}%")
            print('   por tramos frente al mejor activo de ese tramo (mediana):', {c[6:]: r[c].median() for c in segb}, '| ganan al mejor en todos los tramos:', f"{100*(r[segb]>1).all(axis=1).mean():.0f}%")
            fam = r.regla.str.extract(r'^(fuerza|par sobre|vuelta)')[0]
            print('   por familia (mediana frente a mitad y mitad):', r.groupby(fam)['mitad y mitad sin tocar'].median().round(2).to_dict(), '| frente al mejor de los activos:', r.groupby(fam)['mejor de los dos (o tres)'].median().round(2).to_dict())
            print(r.sort_values('mitad y mitad sin tocar', ascending=False).head(3)[['regla', 'cambios_año'] + bcols + segb].to_string(index=False))
    pd.concat(allr).to_csv('res_rot.csv', index=False)
