from c2 import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); tk = btc_taker().reindex(d.index)
c = d.c.values; dates = d.index; n = len(c); idx = np.arange(n)
bp = bull_phase(c); first = np.where(tk.notna().values)[0][0]
e20 = ema(c, 20); e10 = ema(c, 10); s50 = pd.Series(c).rolling(50).mean().values; rsi = rsi_wilder(c)
v = d.v.astype(float)
delta = (((2*tk-1)*v).rolling(90, min_periods=60).sum() / v.rolling(90, min_periods=60).sum()).values
mask = bp & (idx >= first + 90)
rng = np.random.default_rng(1)
for k in (3, 5, 8):
    minsep = 8 if k >= 5 else 5
    ph = pivots(c, k, "high")
    hh = np.zeros(n, bool)  # higher-high pivot pairs (price condition only)
    for j in range(len(ph)):
        cand = ph[:j]; cand = cand[(ph[j]-cand >= minsep) & (ph[j]-cand <= 60)]
        if len(cand) and c[ph[j]] > c[cand[-1]] and ph[j]+k < n: hh[ph[j]+k] = True
    hh &= mask
    real = divergences(c, delta, k, 60, "bear") & mask
    neg = hh & ~real  # higher highs WITHOUT delta divergence
    rs = divergences(c, rsi, k, 60, "bear") & mask
    line = "k=%d nHH=%d nDiv=%d | " % (k, hh.sum(), real.sum())
    for rule in RULES:
        f = make_rebuy_rule(rule, c, e20, e10, s50, rsi)
        a = roundtrip(c, real, f, .0015); b = roundtrip(c, hh, f, .0015); z = roundtrip(c, neg, f, .0015); r2 = roundtrip(c, rs, f, .0015)
        line += "%s div x%.2f(%d) allHH x%.2f(%d) HHnoDiv x%.2f(%d) RSIdiv x%.2f; " % (rule, a["mult"], a["n"], b["mult"], b["n"], z["mult"], z["n"], r2["mult"])
    print(line)
# concentration for k=5 ema20 and k=8 bars20
for k, rule in [(5, "ema20"), (8, "bars20"), (8, "rsi50")]:
    sig = divergences(c, delta, k, 60, "bear") & mask
    res = roundtrip(c, sig, make_rebuy_rule(rule, c, e20, e10, s50, rsi), .0015)
    g = np.sort(res["gains"])[::-1]
    yrs = pd.Series(res["gains"], index=[dates[t[0]].year for t in res["trades"]]).groupby(level=0).sum().apply(np.exp).round(2)
    print(k, rule, "n=%d mult %.2f, w/o best2 %.2f, w/o best3 %.2f, win%% %.0f; by year:" % (res["n"], res["mult"], np.exp(g[2:].sum()), np.exp(g[3:].sum()), 100*(g > 0).mean()), dict(yrs))
