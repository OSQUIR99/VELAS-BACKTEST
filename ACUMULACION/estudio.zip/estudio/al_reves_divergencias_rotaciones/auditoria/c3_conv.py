from c3 import *
def sim_w(P, lb, margin, cost, wk_anchor=None, warm="ew_daily"):
    """momentum computed on sliced data only; EW daily-rebalanced (no cost) until momentum exists."""
    L = np.log(P.values); n, m = L.shape; mom = np.full_like(L, np.nan); mom[lb:] = L[lb:] - L[:-lb]
    dec = np.ones(n, bool) if wk_anchor is None else np.asarray(P.index.dayofweek == wk_anchor)
    W = np.full((n, m), np.nan); cur = -1
    for i in range(n):
        if not dec[i] or np.isnan(mom[i]).any(): continue
        b = int(np.argmax(mom[i]))
        if cur < 0 or (b != cur and mom[i, b] - mom[i, cur] > margin): cur = b
        W[i] = 0; W[i, cur] = 1
    W = pd.DataFrame(W).ffill().fillna(1 / m).values
    R = np.vstack([np.zeros(m), P.values[1:] / P.values[:-1] - 1])
    held = np.vstack([np.full((2, m), 1 / m), W[:-2]])
    Wprev = np.vstack([np.full((1, m), 1 / m), W[:-1]])
    turn = np.r_[0, np.abs(np.diff(Wprev, axis=0)).sum(axis=1)]
    port = (held * R).sum(axis=1) - turn * cost
    return np.exp(np.log1p(port).cumsum()), int((turn > 1e-9).sum())
cost = .0015
full = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH"), "HYPE": load_close("HYPE")}, axis=1).dropna()
P3 = full[full.index >= "2024-11-29"]
eq, ns = sim_w(P3, 60, .10, cost); b = P3 / P3.iloc[0]; ew = b.mean(axis=1)
print("HYPE (EW warm-up, no-cost benchmarks): vsHYPE x%.2f vsEW x%.2f" % (eq[-1] / b.HYPE.iloc[-1], eq[-1] / ew.iloc[-1]))
r = [sim_w(P3, lb, m, cost)[0][-1] / b.HYPE.iloc[-1] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .1]]
print("  21 variants median vsHYPE x%.2f" % np.median(r))
P1 = full[["BTC", "ETH"]]; P1 = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH")}, axis=1).dropna(); P1 = P1[(P1.index >= "2019-01-01") & (P1.index <= "2026-09-28")]
eq, ns = sim_w(P1, 60, .05, cost); b = P1 / P1.iloc[0]
print("BTC/ETH 2019 (momentum from sliced data, EW warm-up): vsBTC x%.2f" % (eq[-1] / b.BTC.iloc[-1]))
r = np.array([sim_w(P1, lb, m, cost, wk)[0][-1] / b.BTC.iloc[-1] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .1] for wk in [None, 6]])
print("  42 variants: beat BTC %.0f%% median x%.2f" % (100 * (r > 1).mean(), np.median(r)))
