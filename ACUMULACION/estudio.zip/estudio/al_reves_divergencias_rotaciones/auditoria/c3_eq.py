from c3 import *
P = pd.concat({"SP": load_trad("sp500", "1985-01-01").c, "NDX": load_trad("nasdaq100", "1985-01-01").c}, axis=1).dropna()
P = P[P.index >= "1985-01-31"]
cost = .001
def run(lb, m, wk, start="1985-01-31", end=None):
    F = P.copy(); mom = np.log(F / F.shift(lb))
    # momentum needs lb bars: start sim when available (benchmark from same date)
    F2 = F[F.index >= start]; M = mom.loc[F2.index]
    if end: F2 = F2[F2.index <= end]; M = M.loc[F2.index]
    ok = M.notna().all(axis=1).values; t0 = np.argmax(ok)
    F2 = F2.iloc[t0:]; M = M.iloc[t0:]
    px = F2.values; mv = M.values; n = len(F2); dates = F2.index
    dm = np.asarray(dates.dayofweek == 4) if wk else np.ones(n, bool)
    held = int(np.argmax(mv[0])); units = (1 - cost) / px[0, held]; pending = None; eq = np.empty(n); sw = []
    for t in range(n):
        if pending is not None:
            val = units * px[t, held] * (1 - cost); held = pending; units = val * (1 - cost) / px[t, held]; pending = None; sw.append(dates[t])
        eq[t] = units * px[t, held]
        if t < n - 1 and dm[t]:
            best = int(np.argmax(mv[t]))
            if best != held and mv[t, best] - mv[t, held] > m: pending = best
    eq = pd.Series(eq, index=dates); b = F2 / F2.iloc[0] * (1 - cost)
    return eq, b, sw
eq, b, sw = run(60, .05, True)
yrs = (eq.index[-1] - eq.index[0]).days / 365.25
print("base 60/5%%/weekly from %s: vsNDX x%.2f vsSP x%.2f vs5050 x%.2f switches %d (%.2f/yr)" % (eq.index[0].date(), eq.iloc[-1] / b.NDX.iloc[-1], eq.iloc[-1] / b.SP.iloc[-1], eq.iloc[-1] / (0.5 * b.SP + 0.5 * b.NDX).iloc[-1], len(sw), len(sw) / yrs))
rows = []
for lb in [20, 30, 60, 90, 120, 180, 252]:
    for m in [0, .05, .10]:
        for wk in [False, True]:
            eq, b, sw = run(lb, m, wk)
            rel = eq / b.NDX
            r9505 = (rel["2005-12-30":].iloc[0] / rel[:"1995-01-03"].iloc[-1])
            rows.append(dict(lb=lb, m=m, wk=wk, vsNDX=eq.iloc[-1] / b.NDX.iloc[-1], sw_per_yr=len(sw) / yrs, rel_1995_2005=r9505,
                             rel_ex=(eq.iloc[-1] / b.NDX.iloc[-1]) / r9505))
G = pd.DataFrame(rows)
print(G.sort_values("vsNDX", ascending=False).round(2).to_string())
print("median vsNDX all 42: %.2f ; share >=0.9: %d" % (G.vsNDX.median(), (G.vsNDX >= .9).sum()))
