from alib import *
assets = {"sp500": ("1928-01-01", 0.001), "nasdaq100": ("1985-01-01", 0.001), "oro": ("1975-01-01", 0.001)}
for a, (st, cost) in assets.items():
    d = load_trad(a, st); c = d.c.values
    r = rsi_wilder(c)
    bear = divergences(c, r, 5, 60, "bear", 65); bull = divergences(c, r, 5, 60, "bull", 35)
    res = roundtrip(c, bear, make_rebuy_div(bull, c), cost)
    print(a, d.index[0].date(), d.index[-1].date(), "nbear", bear.sum(), "nbull", bull.sum(), "trades", res["n"], "out%%=%.1f" % (100*res["out"]), "mult=%.3f" % res["mult"],
          "open_end", res["trades"][-1][3] if res["trades"] else None, "win%%=%.0f" % (100*(res['gains']>0).mean()))
