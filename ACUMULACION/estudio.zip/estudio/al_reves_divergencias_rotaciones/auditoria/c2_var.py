from c2 import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); tk = btc_taker().reindex(d.index)
c = d.c.values; n = len(c); idx = np.arange(n); bp = bull_phase(c); first = np.where(tk.notna().values)[0][0]
e20 = ema(c, 20); e10 = ema(c, 10); s50 = pd.Series(c).rolling(50).mean().values; rsi = rsi_wilder(c)
v = d.v.astype(float)
delta = (((2*tk-1)*v).rolling(90, min_periods=60).sum() / v.rolling(90, min_periods=60).sum()).values
def rule_fn(rule, off):
    def fn(s, e, ps, n):
        cap = 120 if rule == "sma50" else 60
        cond = {"ema20": c <= e20, "rsi50": rsi <= 50}[rule]
        u = first_true_after(cond, s + off, e + cap + 1)
        r = u + 1 if u is not None else e + cap
        return r if r < n else None
    return fn
for k in (5, 8):
    sig = divergences(c, delta, k, 60, "bear") & bp & (idx >= first + 90)
    for rule in ["ema20", "rsi50"]:
        for off in (1, 2):
            res = roundtrip(c, sig, rule_fn(rule, off), .0015)
            print(k, rule, "check from", "e" if off == 1 else "e+1", res["n"], "%.2f" % res["mult"])
