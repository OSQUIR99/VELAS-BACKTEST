from c3 import *
P = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH"), "HYPE": load_close("HYPE")}, axis=1)
P = P[P.index >= "2024-11-29"].dropna()
print(P.index[0].date(), P.index[-1].date(), len(P))
cost = .0015
def sim_nan(P, lb, margin, start_idx=0):
    """variant b: momentum of assets without lb history is NaN and ignored; hold leader among available."""
    mom = np.log(P / P.shift(lb)).values; px = P.values; n = len(P)
    # before any momentum: hold equal-weight? -> start in BTC/ETH leader once BTC/ETH momentum exists (it does: use full history)
    return mom
# full histories so BTC/ETH have momentum from day 1
full = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH"), "HYPE": load_close("HYPE")}, axis=1)
full = full[full.index >= "2015-01-01"]
def run(lb, margin, start, end=None, mode="ignore_nan"):
    F = full.copy(); mom = np.log(F / F.shift(lb)); F = F[F.index >= start].dropna(); mom = mom.loc[F.index]
    if end: F = F[F.index <= end]; mom = mom.loc[F.index]
    px = F.values; mv = mom.values; n = len(F); dates = F.index
    m0 = np.where(np.isnan(mv[0]), -np.inf, mv[0]); held = int(np.argmax(m0))
    units = (1 - cost) / px[0, held]; pending = None; eq = np.empty(n); nsw = 0
    for t in range(n):
        if pending is not None:
            val = units * px[t, held] * (1 - cost); held = pending; units = val * (1 - cost) / px[t, held]; pending = None; nsw += 1
        eq[t] = units * px[t, held]
        m = np.where(np.isnan(mv[t]), -np.inf, mv[t])
        if t < n - 1:
            best = int(np.argmax(m))
            if best != held and m[best] - m[held] > margin: pending = best
    eq = pd.Series(eq, index=dates)
    b = F / F.iloc[0] * (1 - cost); ew = b.mean(axis=1)
    return eq.iloc[-1] / b.HYPE.iloc[-1], eq.iloc[-1] / ew.iloc[-1], nsw, eq.iloc[-1], b.HYPE.iloc[-1], ew.iloc[-1]
print("HYPE B&H from 2024-11-29: x%.1f" % (P.HYPE.iloc[-1] / P.HYPE.iloc[0]))
for start in ["2024-11-29", "2025-01-28"]:
    r = run(60, .10, start)
    print("start", start, "(HYPE momentum NaN until 60d -> ignored): vsHYPE x%.2f vsEW x%.2f switches %d  [strat x%.2f, HYPE x%.2f, EW x%.2f]" % r)
    rs = [run(lb, m, start)[0] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .10]]
    re = [run(lb, m, start)[1] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .10]]
    print("   21 variants: median vsHYPE x%.2f, median vsEW x%.2f" % (np.median(rs), np.median(re)))
