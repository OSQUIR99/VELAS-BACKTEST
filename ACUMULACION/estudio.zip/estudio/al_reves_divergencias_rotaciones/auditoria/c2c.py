import c2
from c2 import *
# variant: 90 days after first non-NaN delta value
src = open('c2.py').read()
def run_v(d, tk, KL, offset_from_valid_delta=True):
    tk = tk.reindex(d.index); c = d.c.values; v = d.v.astype(float)
    valid = tk.notna() & v.notna()
    delta = (((2*tk-1)*v).where(valid).rolling(90, min_periods=60).sum() / v.where(valid).rolling(90, min_periods=60).sum()).values
    first = np.where(~np.isnan(delta))[0][0]
    bp = bull_phase(c); e20 = ema(c, 20); e10 = ema(c, 10); s50 = pd.Series(c).rolling(50).mean().values; rsi = rsi_wilder(c)
    out = []
    for k, L in KL:
        be = divergences(c, delta, k, L, "bear") & bp & (np.arange(len(c)) >= first + 90)
        for rule in RULES:
            res = roundtrip(c, be, make_rebuy_rule(rule, c, e20, e10, s50, rsi), .0015)
            out.append(dict(k=k, L=L, rule=rule, n=res["n"], mult=res["mult"]))
    return pd.DataFrame(out)
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); tk = btc_taker()
KL = [(k, L) for k in (3, 5, 8) for L in (40, 60)]
df = run_v(d, tk, KL)
print(df.pivot_table(index=["k","L"], columns="rule", values="mult").round(2))
print(df.pivot_table(index=["k","L"], columns="rule", values="n"))
print("%d/%d gain, min %.2f max %.2f med %.2f" % ((df.mult>1).sum(), len(df), df.mult.min(), df.mult.max(), df.mult.median()))
