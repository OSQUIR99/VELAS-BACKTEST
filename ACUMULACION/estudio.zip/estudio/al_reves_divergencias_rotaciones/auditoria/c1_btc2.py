from alib import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); c = d.c.values; dates = d.index
r = rsi_wilder(c)
db = load_crypto("BTC"); cb = db.c.values; rb = rsi_wilder(cb)
A = {}; Bn = {}
for k in range(3, 13):
    be = divergences(c, r, k, 60, "bear"); bu = divergences(c, r, k, 60, "bull")
    be2 = divergences(cb, rb, k, 60, "bear"); bu2 = divergences(cb, rb, k, 60, "bull")
    for X in [.10, .15, .20, .30]:
        res = roundtrip(c, be, make_rebuy_div(bu, c, "chase", X=X), .0015)
        g = [t[2] for t in res["trades"] if dates[t[0]] >= pd.Timestamp("2017-01-01")]
        A[(k, X)] = np.exp(sum(g))
        res2 = roundtrip(cb, be2, make_rebuy_div(bu2, cb, "chase", X=X), .0015)
        Bn[(k, X)] = res2["mult"]
for nm, T in [("subset of full-run trades sold>=2017", A), ("Binance-only data 2017-08-17", Bn)]:
    M = pd.Series(T).unstack(); print(nm); print(M.round(2))
    print(" wins k3-10 %d/32, k5-12 %d/32, all %d/40" % ((M.loc[3:10] > 1).sum().sum(), (M.loc[5:12] > 1).sum().sum(), (M > 1).sum().sum()))
