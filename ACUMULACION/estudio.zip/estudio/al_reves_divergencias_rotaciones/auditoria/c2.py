from alib import *
import itertools

def make_rebuy_rule(rule, c, e20, e10, s50, rsi):
    c = np.asarray(c, float)
    def fn(s, e, ps, n):
        if rule in ("ema20", "ema10", "sma50", "rsi50", "ema20chase"):
            cap = 120 if rule == "sma50" else 60
            cond = {"ema20": c <= e20, "ema10": c <= e10, "sma50": c <= s50, "rsi50": rsi <= 50,
                    "ema20chase": (c <= e20) | (c >= ps * 1.15)}[rule]
            u = first_true_after(cond, e + 1, e + cap + 1)
            r = u + 1 if u is not None else e + cap
            if rule == "ema20chase":
                pass
            return r if r < n else None
        if rule == "bars10": return e + 10 if e + 10 < n else None
        if rule == "bars20": return e + 20 if e + 20 < n else None
    return fn

RULES = ["ema20", "ema10", "sma50", "rsi50", "bars10", "bars20", "ema20chase"]

def run_asset(d, tk, cost=.0015, KL=None, trunc=None, retsig=False):
    tk = tk.reindex(d.index)
    if trunc is not None:
        d = d[d.index <= trunc]; tk = tk[tk.index <= trunc]
    c = d.c.values
    v = d.v.astype(float)
    num = ((2 * tk - 1) * v)
    valid = tk.notna() & v.notna()
    delta = (num.where(valid).rolling(90, min_periods=60).sum() / v.where(valid).rolling(90, min_periods=60).sum()).values
    first = np.where(valid.values)[0][0]
    bp = bull_phase(c)
    e20 = ema(c, 20); e10 = ema(c, 10); s50 = pd.Series(c).rolling(50).mean().values; rsi = rsi_wilder(c)
    out = []; sigs = {}
    for k, L in KL:
        be = divergences(c, delta, k, L, "bear")
        idx = np.arange(len(c))
        be = be & bp & (idx >= first + 90)
        sigs[(k, L)] = d.index[be]
        for rule in RULES:
            res = roundtrip(c, be, make_rebuy_rule(rule, c, e20, e10, s50, rsi), cost)
            out.append(dict(k=k, L=L, rule=rule, n=res["n"], mult=res["mult"], out=res["out"],
                            win=(res["gains"] > 0).mean() if res["n"] else np.nan))
    df = pd.DataFrame(out)
    return (df, sigs) if retsig else df

if __name__ == "__main__":
    d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01")
    tk = btc_taker()
    KL = [(k, L) for k in (3, 5, 8) for L in (40, 60)]
    df, sigs = run_asset(d, tk, KL=KL, retsig=True)
    print(df.pivot_table(index=["k", "L"], columns="rule", values="mult").round(2))
    print(df.pivot_table(index=["k", "L"], columns="rule", values="n"))
    print("BTC: %d/%d gain, min %.2f max %.2f median %.2f" % ((df.mult > 1).sum(), len(df), df.mult.min(), df.mult.max(), df.mult.median()))
    print(df[(df.k == 5) & (df.L == 60) & (df.rule == "ema20")]); print(df[(df.k == 8) & (df.L == 60) & (df.rule == "rsi50")])
    df.to_csv("c2_btc.csv", index=False)
    # Binance-only SMA200 (no coinmetrics) sensitivity
    df2 = run_asset(load_crypto("BTC"), tk, KL=KL)
    print("Binance-only price history: %d/%d gain, min %.2f max %.2f" % ((df2.mult > 1).sum(), len(df2), df2.mult.min(), df2.mult.max()))
