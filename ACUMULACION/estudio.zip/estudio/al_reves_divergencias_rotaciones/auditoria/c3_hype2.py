from c3 import *
cost = .0015
full = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH"), "HYPE": load_close("HYPE")}, axis=1)
full = full[full.index >= "2024-11-29"].dropna()
def run(lb, margin, F=full, trunc_lb=True, ret_eq=False):
    px = F.values; n = len(F); dates = F.index
    lp = np.log(px)
    mv = np.full_like(lp, np.nan)
    for t in range(n):
        j = t - lb
        if j >= 0: mv[t] = lp[t] - lp[j]
        elif trunc_lb and t > 0: mv[t] = lp[t] - lp[0]
    held = None; units = None; pending = None; eq = np.full(n, np.nan); nsw = 0; cash = 1.0
    for t in range(n):
        if pending is not None:
            val = (units * px[t, held] * (1 - cost)) if held is not None else cash
            held = pending; units = val * (1 - cost) / px[t, held]; pending = None; nsw += 1
        eq[t] = units * px[t, held] if held is not None else cash
        if t < n - 1 and not np.all(np.isnan(mv[t])):
            m = np.where(np.isnan(mv[t]), -np.inf, mv[t]); best = int(np.argmax(m))
            if held is None or (best != held and m[best] - m[held] > margin): pending = best
    eq = pd.Series(eq, index=dates)
    b = F / F.iloc[0] * (1 - cost); ew = b.mean(axis=1)
    if ret_eq: return eq
    return eq.iloc[-1] / b.HYPE.iloc[-1], eq.iloc[-1] / ew.iloc[-1], nsw, eq.iloc[-1]
r = run(60, .10); print("truncated-lookback, start cash 2024-11-29 (first decision at close 11-29, buy 11-30): vsHYPE x%.2f vsEW x%.2f switches %d strat x%.2f" % r)
rs = np.array([run(lb, m)[:2] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .10]])
print("  21 variants median vsHYPE x%.2f vsEW x%.2f; vsHYPE range %.2f-%.2f" % (np.median(rs[:, 0]), np.median(rs[:, 1]), rs[:, 0].min(), rs[:, 0].max()))
eq = run(60, .10, ret_eq=True)
F = full
print(" holdings path:")
held = None

# variant: hold EW basket (bought at 11-29 close) until all lb-momenta exist, then rotate (sell basket -> leader)
def run_ew(lb, margin, F=full):
    px = F.values; n = len(F); lp = np.log(px)
    b = F / F.iloc[0] * (1 - cost); ew = b.mean(axis=1).values
    t0 = lb  # first bar with all momenta
    mv = np.full_like(lp, np.nan); mv[lb:] = lp[lb:] - lp[:-lb]
    eq = ew.copy(); held = None; pending = None; nsw = 0; units = None
    for t in range(t0, n):
        if pending is not None:
            val = (units * px[t, held] * (1 - cost)) if held is not None else ew[t] * (1 - cost)
            held = pending; units = val * (1 - cost) / px[t, held]; pending = None; nsw += 1
        eq[t] = units * px[t, held] if held is not None else ew[t]
        if t < n - 1:
            best = int(np.argmax(mv[t]))
            if held is None or (best != held and mv[t, best] - mv[t, held] > margin): pending = best
    return eq[-1] / b.HYPE.iloc[-1], eq[-1] / ew[-1], nsw, eq[-1]
r = run_ew(60, .10); print("EW-until-momentum variant: vsHYPE x%.2f vsEW x%.2f switches %d strat x%.2f" % r)
rs = np.array([run_ew(lb, m)[:2] for lb in [20, 30, 60, 90, 120, 180, 252] for m in [0, .05, .10] if lb < len(full) - 5])
print("  variants median vsHYPE x%.2f vsEW x%.2f (n=%d)" % (np.median(rs[:, 0]), np.median(rs[:, 1]), len(rs)))
