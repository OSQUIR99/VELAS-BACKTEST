from c2 import *
from c2c import run_v
KL = [(3, 60), (5, 60), (8, 60)]
allr = []
for s in ["ETH", "SOL", "XRP", "BNB", "LTC"]:
    for nm, d in [("binance", load_crypto(s))] + ([("cm", load_crypto("ETH", "eth_coinmetrics.csv", "2015-09-01"))] if s == "ETH" else []):
        tk = alt_taker(s)
        for conv, f in [("A_taker+90", lambda d, tk: run_asset(d, tk, KL=KL)), ("B_delta+90", lambda d, tk: run_v(d, tk, KL))]:
            df = f(d, tk); df["asset"] = s; df["hist"] = nm; df["conv"] = conv; allr.append(df)
A = pd.concat(allr)
for (h, conv), g in A.groupby(["hist", "conv"]):
    print(h, conv)
    print(g.groupby("asset").mult.agg(lambda x: "%d/21 gain, med %.2f" % ((x > 1).sum(), x.median())))
for conv in ["A_taker+90", "B_delta+90"]:
    for ethh in ["binance", "cm"]:
        g = A[(A.conv == conv) & ((A.asset != "ETH") | (A.hist == ethh))]
        g = g[(g.asset != "ETH") | (g.hist == ethh)]
        print(conv, "ETH hist", ethh, "-> total %d/%d gain (%.0f%%), median %.3f" % ((g.mult > 1).sum(), len(g), 100 * (g.mult > 1).mean(), g.mult.median()))
A.to_csv("c2_alts.csv", index=False)
