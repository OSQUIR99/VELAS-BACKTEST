from c2 import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); tk = btc_taker()
KL = [(k, L) for k in (3, 5, 8) for L in (40, 60)]
df, sigs = run_asset(d, tk, KL=KL, retsig=True)
for kl in [(3,60),(5,60),(8,60)]:
    print(kl, [str(x.date()) for x in sigs[kl]])
