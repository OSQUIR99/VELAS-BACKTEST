from alib import *
import itertools, json
KL = [(3,40),(5,60),(8,90),(5,40),(3,60),(8,60)]
def setup(name):
    if name == "BTC":
        d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); cost = .0015; X = .15
        tk = btc_taker().reindex(d.index)
        delta = ((2*tk-1)*d.v).rolling(30).sum() / d.v.rolling(30).sum()
        osc3 = delta.values
    elif name == "ETH":
        d = load_crypto("ETH", "eth_coinmetrics.csv", "2015-09-01"); cost = .0015; X = .15
        osc3 = cmf(d)
    else:
        st = {"sp500": "1928-01-01", "nasdaq100": "1985-01-01", "oro": "1975-01-01"}[name]
        d = load_trad(name, st); cost = .001; X = {"sp500": .05, "nasdaq100": .06, "oro": .05}[name]
        osc3 = cmf(d)
    return d, cost, X, osc3

def grid(name):
    d, cost, X, osc3 = setup(name); c = d.c.values
    oscs = {"RSI": (rsi_wilder(c), 65, 35), "MACD": (macd_hist_norm(c), 0, 0), "DELTA": (osc3, 0, 0)}
    rows = []
    for (k, L), lev in itertools.product(KL, [True, False]):
        sigs = {}
        for o, (x, hi, lo) in oscs.items():
            sigs[o] = (divergences(c, x, k, L, "bear", hi if lev else None), divergences(c, x, k, L, "bull", lo if lev else None))
        sigs["RSIorMACD"] = (sigs["RSI"][0] | sigs["MACD"][0], sigs["RSI"][1] | sigs["MACD"][1])
        for o, (be, bu) in sigs.items():
            for mode in ["div", "cap", "chase"]:
                res = roundtrip(c, be, make_rebuy_div(bu, c, mode, X=X, cap=120), cost)
                rows.append(dict(asset=name, k=k, L=L, lev=lev, osc=o, mode=mode, n=res["n"], mult=res["mult"], out=res["out"]))
    return pd.DataFrame(rows)

allr = pd.concat([grid(a) for a in ["sp500", "nasdaq100", "oro", "BTC", "ETH"]])
allr.to_csv("c1_grid.csv", index=False)
g = allr.groupby("asset")
print(pd.DataFrame({"nvar": g.size(), "pct_gain": g.mult.apply(lambda s: 100*(s > 1).mean()), "median": g.mult.median(), "max": g.mult.max()}))
print(allr[allr.mult > 1].sort_values("mult", ascending=False).head(25))
print(allr.groupby(["asset", "osc"]).mult.apply(lambda s: (s > 1).mean()).unstack())
print(allr.groupby(["asset", "mode"]).mult.apply(lambda s: (s > 1).mean()).unstack())
