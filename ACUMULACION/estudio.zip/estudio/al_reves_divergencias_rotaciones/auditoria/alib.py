# Independent audit library (written from scratch)
import numpy as np, pandas as pd, sys

B = "/mnt/user-data/uploads/VELAS PARA BACKTEST/"
W = "/home/claude/work/data/"


def load_pq(rel):
    d = pd.read_parquet(B + rel + "/1d.parquet")
    d["date"] = (d.fecha + pd.Timedelta(hours=4)).dt.floor("D")
    d = d.drop_duplicates("date", keep="last").set_index("date").sort_index()
    return d[["apertura", "maximo", "minimo", "cierre", "volumen"]].rename(
        columns=dict(apertura="o", maximo="h", minimo="l", cierre="c", volumen="v"))


def load_trad(name, start):
    d = load_pq("TRADICIONAL/" + name)
    return d[d.index >= start]


def load_crypto(sym, cm_file=None, cm_start=None):
    d = load_pq("CRIPTO/" + sym)
    if cm_file:
        cm = pd.read_csv(W + cm_file, usecols=["time", "PriceUSD"], parse_dates=["time"]).dropna()
        cm = cm.set_index("time").PriceUSD
        cm = cm[(cm.index >= cm_start) & (cm.index < d.index[0])]
        pre = pd.DataFrame({"o": np.nan, "h": np.nan, "l": np.nan, "c": cm, "v": np.nan})
        d = pd.concat([pre, d])
    return d


def btc_taker():
    sys.path.insert(0, "/home/claude/work")
    import ext
    df, meta = ext.dec("btc_taker")
    return df.iloc[:, 0] / 1000.0


def alt_taker(sym):
    t = pd.read_csv(W + f"taker_{sym}USDT.csv", parse_dates=["fecha"]).set_index("fecha")
    return t.ratio


# ---------------- indicators ----------------
def rsi_wilder(c, n=14):
    c = np.asarray(c, float)
    out = np.full(len(c), np.nan)
    d = np.diff(c)
    g = np.where(d > 0, d, 0.0); l = np.where(d < 0, -d, 0.0)
    if len(d) < n: return out
    ag = g[:n].mean(); al = l[:n].mean()
    out[n] = 100 - 100 / (1 + ag / al) if al > 0 else 100.0
    for i in range(n, len(d)):
        ag = (ag * (n - 1) + g[i]) / n; al = (al * (n - 1) + l[i]) / n
        out[i + 1] = 100 - 100 / (1 + ag / al) if al > 0 else 100.0
    return out


def ema(s, n):
    return pd.Series(s).ewm(span=n, adjust=False).mean().values


def macd_hist_norm(c):
    c = pd.Series(np.asarray(c, float))
    m = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    sig = m.ewm(span=9, adjust=False).mean()
    return ((m - sig) / c).values


def cmf(d, n=20):
    h, l, c, v = d.h, d.l, d.c, d.v.astype(float).replace(0, np.nan)
    rng = (h - l)
    mfm = ((c - l) - (h - c)) / rng.replace(0, np.nan)
    mfm = mfm.fillna(0)
    return ((mfm * v).rolling(n).sum() / v.rolling(n).sum()).values


def bull_phase(c):
    c = pd.Series(np.asarray(c, float))
    s = c.rolling(200).mean()
    return ((c > s) & (s > s.shift(20))).values


# ---------------- divergences ----------------
def pivots(p, k, kind):
    s = pd.Series(p)
    w = s.rolling(2 * k + 1, center=True)
    ref = w.max() if kind == "high" else w.min()
    return np.where((s == ref).values & ref.notna().values)[0]


def divergences(p, osc, k, L, kind, level=None):
    """returns boolean array of signal bars (i2+k)."""
    p = np.asarray(p, float); osc = np.asarray(osc, float)
    n = len(p); sig = np.zeros(n, bool)
    minsep = 8 if k >= 5 else 5
    piv = pivots(p, k, "high" if kind == "bear" else "low")
    for j in range(len(piv)):
        i2 = piv[j]
        # most recent previous pivot with minsep <= i2-i1 <= L
        cand = piv[:j]
        cand = cand[(i2 - cand >= minsep) & (i2 - cand <= L)]
        if len(cand) == 0: continue
        i1 = cand[-1]
        a1, a2 = osc[i1], osc[i2]
        if np.isnan(a1) or np.isnan(a2): continue
        if kind == "bear":
            ok = p[i2] > p[i1] and a2 < a1 and (level is None or a1 >= level)
        else:
            ok = p[i2] < p[i1] and a2 > a1 and (level is None or a1 <= level)
        if ok and i2 + k < n: sig[i2 + k] = True
    return sig


# ---------------- round-trip engine ----------------
def roundtrip(c, bear, rebuy_fn, cost, start=0, end=None):
    """bear: bool signal array. rebuy_fn(s, e, Psell) -> execution bar index of rebuy (or None => still out).
    s = sale signal bar, e = s+1 sale execution bar. Returns dict."""
    c = np.asarray(c, float); n = len(c) if end is None else end
    t = start; trades = []; out = 0
    lc = np.log(1 - cost)
    while True:
        idx = np.where(bear[t:n])[0]
        if len(idx) == 0: break
        s = t + idx[0]; e = s + 1
        if e >= n: break
        ps = c[e]
        r = rebuy_fn(s, e, ps, n)
        if r is None or r >= n:
            g = np.log(ps / c[n - 1]) + 2 * lc
            trades.append((e, n - 1, g, True)); out += n - 1 - e
            break
        g = np.log(ps / c[r]) + 2 * lc
        trades.append((e, r, g, False)); out += r - e
        t = r  # next bear signal may fire at the rebuy bar or later
    gains = np.array([x[2] for x in trades])
    return dict(trades=trades, n=len(trades), mult=float(np.exp(gains.sum())) if len(gains) else 1.0,
                out=out / max(1, n - start), gains=gains)


def first_true_after(arr, a, b):
    """first index i in [a, b) with arr[i] True, else None"""
    b = min(b, len(arr))
    if a >= b: return None
    idx = np.where(arr[a:b])[0]
    return a + idx[0] if len(idx) else None


def make_rebuy_div(bull, c, mode="div", X=None, cap=None):
    c = np.asarray(c, float)
    def fn(s, e, ps, n):
        cands = []
        b = first_true_after(bull, s + 1, n)
        if b is not None and b + 1 < n: cands.append(b + 1)
        if mode == "cap":
            if e + cap < n: cands.append(e + cap)
        if mode == "chase":
            u = first_true_after(c >= ps * (1 + X), e + 1, n)
            if u is not None and u + 1 < n: cands.append(u + 1)
        return min(cands) if cands else None
    return fn
