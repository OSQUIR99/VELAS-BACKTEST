from c2 import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); tk = btc_taker()
# 1) alignment
x = pd.DataFrame({"r": tk.reindex(d.index), "c": d.c}).dropna()
ret = np.log(x.c).diff()
print("BTC corr(ratio_t, ret_t)=%.3f  corr(ratio_t, ret_t+1)=%.3f  corr(ratio_t, ret_t-1)=%.3f" % (x.r.corr(ret), x.r.corr(ret.shift(-1)), x.r.corr(ret.shift(1))))
for s in ["ETH", "SOL", "XRP", "BNB", "LTC"]:
    dd = load_crypto(s); t = alt_taker(s)
    x = pd.DataFrame({"r": t.reindex(dd.index), "c": dd.c}).dropna(); ret = np.log(x.c).diff()
    print(s, "corr t=%.3f t+1=%.3f t-1=%.3f" % (x.r.corr(ret), x.r.corr(ret.shift(-1)), x.r.corr(ret.shift(1))))
# 2) truncation
KL = [(3, 60), (5, 60), (8, 60)]
_, full = run_asset(d, tk, KL=KL, retsig=True)
for T in ["2020-06-30", "2023-03-15", "2025-02-01"]:
    _, tr = run_asset(d, tk, KL=KL, trunc=pd.Timestamp(T), retsig=True)
    for kl in KL:
        a = set(full[kl][full[kl] <= T]); b = set(tr[kl])
        print(T, kl, "signals<=T full:", len(a), "trunc:", len(b), "identical:", a == b)
# 3) random-sale null (bull-phase days, beyond first+90), EMA20 and bars20 rebuy, same trade count as k=5 L=60
c = d.c.values; bp = bull_phase(c); valid = tk.reindex(d.index).notna().values; first = np.where(valid)[0][0]
e20 = ema(c, 20); e10 = ema(c, 10); s50 = pd.Series(c).rolling(50).mean().values; rsi = rsi_wilder(c)
elig = np.where(bp & (np.arange(len(c)) >= first + 90))[0]
rng = np.random.default_rng(0)
for rule, real in [("ema20", 1.57), ("bars20", 2.33), ("rsi50", 1.73)]:
    ms = []
    for it in range(1000):
        sig = np.zeros(len(c), bool); sig[rng.choice(elig, 29, replace=False)] = True
        ms.append(roundtrip(c, sig, make_rebuy_rule(rule, c, e20, e10, s50, rsi), .0015)["mult"])
    ms = np.array(ms)
    print(rule, "random bull-phase sales (29 candidate signals): median x%.2f, P(>1)=%.2f, P(>=real %.2f)=%.3f" % (np.median(ms), (ms > 1).mean(), real, (ms >= real).mean()))
