from c3 import *
P = pd.concat({"BTC": load_close("BTC"), "ETH": load_close("ETH")}, axis=1).dropna()
cost = .0015
def report(P, start, end, lb=60, margin=.05, weekly=False, periods=None, label=""):
    eq, sw = rot_sim(P, lb, margin, cost, fri if weekly else None, start, end)
    Pw = P[(P.index >= start) & (P.index <= end)]
    b = bh(Pw, cost); fifty = 0.5 * b.BTC + 0.5 * b.ETH
    out = dict(label=label, vsBTC=eq.iloc[-1] / b.BTC.iloc[-1], vsETH=eq.iloc[-1] / b.ETH.iloc[-1], vs5050=eq.iloc[-1] / fifty.iloc[-1],
               switches=len(sw), years=(Pw.index[-1] - Pw.index[0]).days / 365.25)
    if periods:
        for a, z in periods:
            s = eq[(eq.index >= a) & (eq.index <= z)]; pb = Pw[(Pw.index >= a) & (Pw.index <= z)]
            r = s.iloc[-1] / s.iloc[0]; best = (pb.iloc[-1] / pb.iloc[0]).max()
            out[a[:4] + "-" + z[:4]] = r / best
    return out, eq, sw
per = [("2019-01-01", "2021-01-01"), ("2021-01-01", "2023-01-01"), ("2023-01-01", "2025-01-01"), ("2025-01-01", "2026-09-28")]
o, eq, sw = report(P, "2019-01-01", "2026-09-28", periods=per, label="base 60/5% daily")
print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in o.items()})
per_b = [("2019-01-01", "2020-12-31"), ("2021-01-01", "2022-12-31"), ("2023-01-01", "2024-12-31"), ("2025-01-01", "2026-09-28")]
o2, _, _ = report(P, "2019-01-01", "2026-09-28", periods=per_b, label="base (calendar-year blocks)")
print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in o2.items()})
# grid
rows = []
for lb in [20, 30, 60, 90, 120, 180, 252]:
    for m in [0, .05, .10]:
        for wk in [False, True]:
            o, _, _ = report(P, "2019-01-01", "2026-09-28", lb, m, wk, per)
            rows.append(dict(lb=lb, m=m, wk=wk, **{k: v for k, v in o.items() if k != "label"}))
G = pd.DataFrame(rows)
print("grid 42: beat BTC %.0f%%, median vsBTC %.2f, median vs best 2021-2023 %.2f; medians per period:" % (100 * (G.vsBTC > 1).mean(), G.vsBTC.median(), G["2021-2023"].median()),
      G[["2019-2021", "2021-2023", "2023-2025", "2025-2026"]].median().round(2).to_dict())
print("BTC/ETH B&H 2019->2026-09-28: BTC x%.1f ETH x%.1f" % (P.BTC["2026-09-28"] / P.BTC["2019-01-01"], P.ETH["2026-09-28"] / P.ETH["2019-01-01"]))
# from 2016-06-01
o3, eq3, sw3 = report(P, "2016-06-01", "2026-09-28", periods=[("2016-06-01", "2018-01-01"), ("2018-01-01", "2026-09-28"), ("2016-06-01","2017-12-31")], label="from 2016-06")
print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in o3.items()})
s = eq3; print(" rot growth 2016-06..2018-01: x%.1f ; 2018-01..end: x%.2f ; BTC same: x%.1f / x%.2f ; ETH: x%.1f / x%.2f" % (
    s["2018-01-01"] / s.iloc[0], s.iloc[-1] / s["2018-01-01"], P.BTC["2018-01-01"] / P.BTC["2016-06-01"], P.BTC.iloc[-1] / P.BTC["2018-01-01"],
    P.ETH["2018-01-01"] / P.ETH["2016-06-01"], P.ETH.iloc[-1] / P.ETH["2018-01-01"]))
rows = []
for lb in [20, 30, 60, 90, 120, 180, 252]:
    for m in [0, .05, .10]:
        for wk in [False, True]:
            o, e, _ = report(P, "2016-06-01", "2026-09-28", lb, m, wk)
            rows.append(dict(lb=lb, m=m, wk=wk, vsBTC=o["vsBTC"], g1617=(e["2018-01-01"] / e.iloc[0]) / (P.BTC["2018-01-01"] / P.BTC["2016-06-01"]), g18=(e.iloc[-1] / e["2018-01-01"]) / (P.BTC.iloc[-1] / P.BTC["2018-01-01"])))
G2 = pd.DataFrame(rows)
print("2016 grid: median vsBTC %.2f, median rel-to-BTC 2016-06..2018 %.2f, median rel-to-BTC 2018..end %.2f, %%beat BTC after 2018: %.0f%%" % (G2.vsBTC.median(), G2.g1617.median(), G2.g18.median(), 100 * (G2.g18 > 1).mean()))
