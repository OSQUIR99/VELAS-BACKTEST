from alib import *

def rot_sim(P, lb, margin, cost, decide_mask=None, start=None, end=None, warm=None):
    """P: DataFrame of closes (aligned, no NaN in sim window). Returns daily equity (value of 1 unit of cash
    invested at start close), list of switch dates. Momentum = ln(P_t/P_{t-lb}). Hold one asset.
    Decision at close t (from data <= t) executed at close t+1. Cost per side on each leg."""
    P = P.copy()
    mom = np.log(P / P.shift(lb))
    if start is not None:
        sel = (P.index >= start) & (P.index <= (end or P.index[-1]))
    else:
        sel = np.ones(len(P), bool)
    Pw = P[sel]; Mw = mom[sel]
    dates = Pw.index; px = Pw.values; mv = Mw.values; n = len(Pw)
    if decide_mask is None: dm = np.ones(n, bool)
    else: dm = decide_mask(dates)
    # initial pick at first close: leader by momentum (if available), buy at start close with cost
    m0 = mv[0]
    held = int(np.nanargmax(m0)) if not np.all(np.isnan(m0)) else None
    eq = np.empty(n); switches = []
    if held is None:  # momentum not available: hold equal weight until available (not used in reported runs)
        raise ValueError("momentum not available at start")
    units = (1 - cost) / px[0, held]
    pending = None
    for t in range(n):
        if pending is not None:  # execute at close t
            val = units * px[t, held] * (1 - cost)
            held = pending; units = val * (1 - cost) / px[t, held]; pending = None
            switches.append(dates[t])
        eq[t] = units * px[t, held]
        if t < n - 1 and dm[t] and not np.any(np.isnan(mv[t])):
            best = int(np.nanargmax(mv[t]))
            if best != held and mv[t, best] - mv[t, held] > margin:
                pending = best
    return pd.Series(eq, index=dates), switches


def bh(P, cost):
    return P / P.iloc[0] * (1 - cost)


def fri(dates):
    return np.asarray(dates.dayofweek == 4)


def load_close(sym):
    if sym == "BTC": d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01")
    elif sym == "ETH": d = load_crypto("ETH", "eth_coinmetrics.csv", "2015-09-01")
    elif sym == "HYPE":
        h = pd.read_csv(W + "hype_daily.csv", parse_dates=["fecha"]).set_index("fecha"); return h.cierre
    else: d = load_trad(sym, "1985-01-01")
    return d.c
