from alib import *
d = load_crypto("BTC", "btc_coinmetrics.csv", "2010-10-01"); c = d.c.values; dates = d.index
r = rsi_wilder(c)
tab = {}
for k in range(3, 13):
    be = divergences(c, r, k, 60, "bear"); bu = divergences(c, r, k, 60, "bull")
    for X in [.10, .15, .20, .30]:
        res = roundtrip(c, be, make_rebuy_div(bu, c, "chase", X=X), .0015)
        tab[(k, X)] = (res["mult"], res["n"])
        if k == 8 and X == .15:
            tr = res["trades"]; g = res["gains"]
            print("k8 X15:", res["n"], "trades mult %.3f out %.1f%%" % (res["mult"], 100*res["out"]))
            o = np.argsort(-g)
            for j in o[:4]: print("  best", dates[tr[j][0]].date(), "->", dates[tr[j][1]].date(), "x%.2f" % np.exp(g[j]), "open" if tr[j][3] else "")
            print("  without 2 best: x%.3f" % np.exp(g.sum() - g[o[:2]].sum()))
            for e, rr, gg, op in tr: print("   ", dates[e].date(), dates[rr].date(), "%.3f" % np.exp(gg))
M = pd.DataFrame({X: {k: tab[(k, X)][0] for k in range(3, 13)} for X in [.1, .15, .2, .3]})
N = pd.DataFrame({X: {k: tab[(k, X)][1] for k in range(3, 13)} for X in [.1, .15, .2, .3]})
print(M.round(2)); print(N)
# from 2017 on: restart at 2017-01-01 and at 2017-08-17 (Binance)
for st in ["2017-01-01", "2017-08-17"]:
    s0 = int(np.searchsorted(dates, pd.Timestamp(st)))
    tab2 = {}
    for k in range(3, 13):
        be = divergences(c, r, k, 60, "bear"); bu = divergences(c, r, k, 60, "bull")
        for X in [.10, .15, .20, .30]:
            res = roundtrip(c, be, make_rebuy_div(bu, c, "chase", X=X), .0015, start=s0)
            tab2[(k, X)] = res["mult"]
    M2 = pd.Series(tab2).unstack()
    print("from", st); print(M2.round(2))
    print(" wins k3-10:", (M2.loc[3:10] > 1).sum().sum(), "/32 ; wins k3-12:", (M2 > 1).sum().sum(), "/40 ; k5-12:", (M2.loc[5:12] > 1).sum().sum(), "/32")
