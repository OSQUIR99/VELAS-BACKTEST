"""Prueba fuera de muestra en otras criptos: ¿la divergencia bajista del delta de 90 días funciona también en ETH, SOL, XRP, BNB y LTC?"""
import itertools
from rt_lib import *
pd.set_option('display.width', 250)
def grid(c, deltas, cost):
    cv = c.values; idx = c.index; s200 = sma(c, 200); bull = ((c > s200) & (s200 > s200.shift(20))).values
    e20 = ema(c, 20); e10 = ema(c, 10); s50 = sma(c, 50); r14 = rsi(c, 14)
    RB = {'e20': (np.flatnonzero((c <= e20).values), 60, None), 'e20c': (np.flatnonzero((c <= e20).values), 60, 0.15), 'e10': (np.flatnonzero((c <= e10).values), 60, None),
          's50': (np.flatnonzero((c <= s50).values), 120, None), 'rsi50': (np.flatnonzero((r14 <= 50).values), 60, None), 'T10': (np.array([], int), 10, None), 'T20': (np.array([], int), 20, None)}
    rows = []
    for on, k in itertools.product(deltas, (3, 5, 8)):
        o = deltas[on]; valid = (idx >= o.first_valid_index() + pd.Timedelta(days=30)) if o.notna().any() else np.zeros(len(c), bool)
        si = np.flatnonzero(divergences(c, o, k, 60, 8 if k >= 5 else 5, 'bear').values & bull & valid)
        pool = np.flatnonzero(bull & valid & s200.notna().values)
        for rn, (rb, tmax, ch) in RB.items():
            t = trades(cv, si, rb, tmax, ch, cost)
            if len(t) < 4: continue
            g = np.array([x[2] for x in t]); rng = np.random.default_rng(2); sims = []
            for _ in range(300):
                tt = trades(cv, np.sort(rng.choice(pool, min(len(pool), 3 * len(t)), replace=False)), rb, tmax, ch, cost)[:len(t)]; sims.append(np.mean([x[2] for x in tt]))
            rows.append(dict(osc=on, k=k, rec=rn, n=len(g), gana=round((g > 0).mean(), 2), total=round(float(np.exp(g.sum())), 3), media=round(100 * (np.exp(g.mean()) - 1), 2),
                             azar=round(100 * (np.exp(np.median(sims)) - 1), 2), p_azar=round(float((np.array(sims) >= g.mean()).mean()), 3)))
    return pd.DataFrame(rows)
out = {}
for sym in ('ETH', 'SOL', 'XRP', 'BNB', 'LTC'):
    p = raw(sym); tk = pd.read_csv(f'data/taker_{sym}USDT.csv', parse_dates=['fecha']).set_index('fecha')['ratio']
    p = p[p.index >= tk.index[0]]; v = p.v; dl = (2 * tk.reindex(p.index) - 1) * v
    D = {f'delta{n}': dl.rolling(n, min_periods=int(n * 0.66)).sum() / v.rolling(n, min_periods=int(n * 0.66)).sum() for n in (7, 30, 90)}
    R = grid(p.c, D, COSTE.get(sym, 0.0015)); R['activo'] = sym; out[sym] = R
A = pd.concat(out.values()); A.to_csv('res_alt_delta_div.csv', index=False)
print(A.groupby(['activo', 'osc']).apply(lambda x: pd.Series({'variantes': len(x), 'ganan%': round(100 * (x.total > 1).mean()), 'mediana': x.total.median(), 'ops': x.n.median(), 'p<0.05%': round(100 * (x.p_azar < 0.05).mean())})).unstack('osc').to_string())
d90 = A[A.osc == 'delta90']
print('\ndelta90 en las 5 criptos juntas: variantes', len(d90), '| ganan', f'{100*(d90.total>1).mean():.0f}%', '| mediana x', d90.total.median(), '| media por operación (mediana)', d90.media.median(), '% vs azar', d90.azar.median(), '%')
