"""¿Sirven las divergencias alcistas diarias para COMPRAR (dinero nuevo)? Rentabilidad a 20 y 60 sesiones tras la confirmación, frente a un día cualquiera."""
from rt_lib import *
rows = []
for a in ['BTC', 'ETH', 'sp500', 'nasdaq100', 'oro', 'plata']:
    p = prices(a); c = p.c; O = osc_set(a, p); idx = c.index; h1 = idx < pd.Timestamp(CORTE[a])
    f = {n: 100 * (c.shift(-(n + 1)) / c.shift(-1) - 1) for n in (20, 60)}
    for on in ('rsi', 'macd', 'delta'):
        lvl = {'rsi': 35, 'macd': 0, 'delta': None}[on]
        d = divergences(c, O[on], 5, 60, 8, 'bull', level=lvl)
        valid = O[on].notna() & f[60].notna()
        for n in (20, 60):
            x = f[n]
            rows.append(dict(activo=a, osc=on, h=n, n1=int((d & h1 & valid).sum()), n2=int((d & ~h1 & valid).sum()),
                             div1=round(x[d & h1 & valid].mean(), 1), base1=round(x[h1 & valid].mean(), 1), div2=round(x[d & ~h1 & valid].mean(), 1), base2=round(x[~h1 & valid].mean(), 1),
                             pos_div=round(100 * (x[d & valid] > 0).mean()), pos_base=round(100 * (x[valid] > 0).mean())))
R = pd.DataFrame(rows); R.to_csv('res_bulldiv_fwd.csv', index=False)
R['mejor1'] = R.div1 > R.base1; R['mejor2'] = R.div2 > R.base2
print(R.to_string(index=False))
print('\nmejor que un día cualquiera en las dos mitades:', int((R.mejor1 & R.mejor2).sum()), 'de', len(R))
