"""Vender en divergencia bajista diaria y recomprar en la siguiente divergencia alcista. Vecinos de parámetros, cinco activos + ETH."""
import itertools, sys, json
from rt_lib import *
pd.set_option('display.width', 250)
CH = {'BTC': 0.15, 'ETH': 0.15, 'sp500': 0.05, 'nasdaq100': 0.06, 'oro': 0.05, 'plata': 0.08}
rows = []; detail = {}
for a in ['BTC', 'ETH', 'sp500', 'nasdaq100', 'oro', 'plata']:
    p = prices(a); c = p.c; cv = c.values; idx = c.index; O = osc_set(a, p); cost = COSTE[a]
    s200 = sma(c, 200); bull = ((c > s200) & (s200 > s200.shift(20))).values
    rng = np.random.default_rng(0)
    for (k, L), lv, osn in itertools.product(((3, 40), (5, 60), (8, 90), (5, 40), (3, 60), (8, 60)), ('con', 'sin'), ('rsi', 'macd', 'delta', 'rsi+macd')):
        def dv(kind):
            out = None
            for o in osn.split('+'):
                level = None if lv == 'sin' else ({'rsi': 65, 'macd': 0, 'delta': None}[o] if kind == 'bear' else {'rsi': 35, 'macd': 0, 'delta': None}[o])
                d = divergences(c, O[o], k, L, 8 if k >= 5 else 5, kind, level=level)
                out = d if out is None else (out | d)
            return out.values
        bear, bull_d = dv('bear'), dv('bull')
        bi = np.flatnonzero(bull_d)
        for reg in ('todo', 'alcista'):
            si = np.flatnonzero(bear & (bull if reg == 'alcista' else True))
            for rec, tmax, ch in (('div', 10 ** 6, None), ('div|120d', 120, None), ('div|persigue', 10 ** 6, CH[a])):
                t = trades(cv, si, bi, tmax, ch, cost)
                r = resumen(cv, idx, t, CORTE[a])
                if r['n'] < 3: continue
                # referencia: el mismo número de ventas en días al azar (mismo régimen), misma regla de recompra
                pool = np.flatnonzero((bull if reg == 'alcista' else np.ones(len(cv), bool)) & s200.notna().values)
                sims = []
                for _ in range(200):
                    rs = np.sort(rng.choice(pool, size=min(len(pool), 3 * r['n']), replace=False))
                    tt = trades(cv, rs, bi, tmax, ch, cost)[:r['n']]
                    if tt: sims.append(np.mean([x[2] for x in tt]))
                sims = np.array(sims); gm = np.log(1 + r['media'] / 100)
                rows.append(dict(activo=a, k=k, L=L, nivel=lv, osc=osn, reg=reg, rec=rec, **r, azar=round(100 * (np.exp(np.median(sims)) - 1), 2), pct_azar=round(float((sims < gm).mean()) * 100)))
R = pd.DataFrame(rows); R.to_csv('res_div_rt.csv', index=False)
for a, x in R.groupby('activo', sort=False):
    y = x[x.reg == 'todo']; z = x[x.reg == 'alcista']
    print(f"\n== {a}: variantes {len(y)} (todo) | ganan unidades {100*(y.total>1).mean():.0f}% | en las dos mitades {100*((y.m1>1)&(y.m2>1)).mean():.0f}% | mediana x{y.total.median():.2f} (1ª x{y.m1.median():.2f}, 2ª x{y.m2.median():.2f}) | tiempo fuera mediana {y.fuera.median():.0f}% | mejor que el azar (mediana percentil) {y.pct_azar.median():.0f}")
    print(f"   solo en fase alcista: ganan {100*(z.total>1).mean():.0f}% | ambas {100*((z.m1>1)&(z.m2>1)).mean():.0f}% | mediana x{z.total.median():.2f}")
    print('   por oscilador (todo):', y.groupby('osc').total.median().round(2).to_dict(), '| por recompra:', y.groupby('rec').total.median().round(2).to_dict())
    print(y.sort_values('total', ascending=False).head(3)[['k', 'L', 'nivel', 'osc', 'rec', 'n', 'gana', 'total', 'm1', 'm2', 'fuera', 'media', 'azar', 'pct_azar']].to_string(index=False))
