import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *
from events import SELL, BUY, episodes, units_fixed, units_limit, XLIM
rows = []
for a in ASSETS:
    f = pd.read_parquet(f'{W}/feat_{a}.parquet'); bpy = BPY[a]; x = XLIM[a]; sp = pd.Timestamp(SPLIT[a])
    for name, kind, fn in SELL + BUY:
        cond = fn(f).reindex(f.index).fillna(False).astype(bool); r = {'activo': a, 'tipo': kind, 'cond': name}
        for nm, mask in (('D', f.index < sp), ('V', f.index >= sp)):
            g = f[mask]; ep = episodes(cond[mask], bpy // 12) & g['fr_3m'].notna(); e = g[ep]; r[nm + '_ep'] = int(ep.sum())
            if kind == 'sell':
                ul, hit = units_limit(e, x, '6m'); ula, _ = units_limit(g, x, '6m'); r[nm + '_x'] = 100 * ul.mean(); r[nm + '_base'] = 100 * ula.mean()
            else:
                r[nm + '_x'] = 100 * e['fr_3m'].mean(); r[nm + '_base'] = 100 * g['fr_3m'].mean()
        rows.append(r)
R = pd.DataFrame(rows); R.to_csv(f'{W}/res_events.csv', index=False)
C = pd.read_csv(f'{W}/res_cond.csv'); C['tipo'] = C['tipo'].map({'V': 'sell', 'C': 'buy'})
ALL = pd.concat([R, C[['activo', 'tipo', 'cond', 'D_ep', 'D_x', 'D_base', 'V_ep', 'V_x', 'V_base']]]); ALL.to_csv(f'{W}/res_all_signals.csv', index=False)
S = ALL[ALL.tipo == 'sell']
print('VENTAS: nº de señales probadas por activo, cuántas ganan unidades (x>0) en cada tramo y en ambos (con >=4 episodios por tramo)')
for a in ASSETS:
    g = S[S.activo == a]; okD = (g.D_x > 0) & (g.D_ep >= 4); okV = (g.V_x > 0) & (g.V_ep >= 4)
    both = g[okD & okV] if a != 'plata' else g[okV]
    print(f"  {a}: probadas {len(g)} | ganan en D {int(okD.sum())} | ganan en V {int(okV.sum())} | en ambos {len(both)}: {list(both.cond)}")
    print(f"      mediana de unidades ganadas por señal: D {g.D_x.median():+.1f}%  V {g.V_x.median():+.1f}%")
B = ALL[ALL.tipo == 'buy']
print('COMPRAS: señales cuya rentabilidad media a 3 meses supera a la de un día cualquiera en ambos tramos (>=5 episodios por tramo)')
for a in ASSETS:
    g = B[B.activo == a]; ok = (g.D_x > g.D_base) & (g.V_x > g.V_base) & (g.D_ep >= 5) & (g.V_ep >= 5)
    if a == 'plata': ok = (g.V_x > g.V_base) & (g.V_ep >= 5)
    k = g[ok].copy(); k['exc'] = (k.V_x - k.V_base) if a == 'plata' else np.minimum(k.D_x - k.D_base, k.V_x - k.V_base)
    k = k.sort_values('exc', ascending=False).head(10)
    print(f"  {a}: {int(ok.sum())} de {len(g)} -> " + '; '.join(f"{r.cond} (D {r.D_x:+.1f} vs {r.D_base:+.1f}, V {r.V_x:+.1f} vs {r.V_base:+.1f})" for r in k.itertuples()))
