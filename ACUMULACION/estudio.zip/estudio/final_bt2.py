import warnings; warnings.filterwarnings('ignore')
import sys; sys.path.insert(0, '/home/claude/work/tool')
import pandas as pd, numpy as np, json
import termometro as T
from lib import W, SPLIT, load_raw, sma
COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
P = T.leer_precios(); hasta = max(s.index[-1] for s in P.values()); L, V, info = T.luces_liquidez(hasta)
paro = T.bandera_paro(pd.date_range('1967-01-01', hasta, freq='D'))[0]
OUT = {'punt': {}}
BANDS = [-1, 25, 39.999, 59.999, 74.999, 101]; LAB = ['roja', 'floja', 'neutra', 'buena', 'verde']
def buckets(S, sp):
    S = S.copy(); S['b'] = pd.cut(S.s, BANDS, labels=LAB); res = {}
    for nm, g in (('D', S[S.index < sp]), ('V', S[S.index >= sp])):
        if len(g) < 60: res[nm] = None; continue
        t = g.groupby('b').agg(n=('s', 'size'), m3=('fr3', 'mean'), p3=('fr3', lambda x: (x > 0).mean()), m12=('fr12', 'mean'), p12=('fr12', lambda x: (x > 0).mean()))
        res[nm] = {'ic3': round(float(g[['s', 'fr3']].corr(method='spearman').iloc[0, 1]), 2), 'ic12': round(float(g[['s', 'fr12']].corr(method='spearman').iloc[0, 1]), 2), 'desde': str(g.index[0].date())[:4], 'hasta': str(g.index[-1].date())[:4],
                   'b': {i: {'n': int(r.n), 'm3': None if r.n < 5 or pd.isna(r.m3) else round(100 * r.m3, 1), 'p3': None if r.n < 5 or pd.isna(r.p3) else round(100 * r.p3), 'm12': None if r.n < 5 or pd.isna(r.m12) else round(100 * r.m12, 1), 'p12': None if r.n < 5 or pd.isna(r.p12) else round(100 * r.p12)} for i, r in t.iterrows()}}
    return res
def pares(ops, c, ue=None):
    """Un episodio = desde la primera venta hasta la recompra. Unidades = unidades equivalentes tras recomprar / antes de vender."""
    res = []; cur = None
    for d, p, prev, tw in ops:
        if tw < prev:
            if cur is None: cur = {'venta': str(d.date()), 'p_venta': round(p, 2), 'd0': d, 'tramo2': None, 'p_tramo2': None}
            else: cur['tramo2'] = str(d.date()); cur['p_tramo2'] = round(p, 2)
        elif tw > prev and cur is not None:
            u = (float(ue[d]) / float(ue[ue.index < cur['d0']].iloc[-1])) if ue is not None else cur['p_venta'] / p
            cur.update({'recompra': str(d.date()), 'p_recompra': round(p, 2), 'unid': round(u, 3), 'dias': (d - cur['d0']).days}); cur.pop('d0'); res.append(cur); cur = None
    if cur is not None:
        u = (float(ue.iloc[-1]) / float(ue[ue.index < cur['d0']].iloc[-1])) if ue is not None else cur['p_venta'] / float(c.iloc[-1])
        cur.update({'recompra': 'abierta', 'p_recompra': round(float(c.iloc[-1]), 2), 'unid': round(u, 3), 'dias': (c.index[-1] - cur['d0']).days}); cur.pop('d0'); res.append(cur)
    return res
def mult(c, w, a, t0, t1=None):
    m = (c.index >= t0) & ((c.index < t1) if t1 is not None else True); ue, ops = T.simular(c[m], w[m], COST[a]); return ue, ops
for a in T.ACTIVOS:
    pts, mx, sc = T.puntuacion(a, P, L, V, paro); c = P[a]; bpy = T.BPY[a]; sp = pd.Timestamp(SPLIT[a]); step = 7 if a == 'BTC' else 5
    S = pd.DataFrame({'s': sc, 'fr3': c.shift(-(bpy // 4)) / c - 1, 'fr12': c.shift(-bpy) / c - 1}).dropna(subset=['s']).iloc[::step]
    hist = sc.dropna()['2021-10-01':].iloc[::step]
    d = {'desde': str(sc.first_valid_index().date()), 'buckets': buckets(S, sp), 'hist': {'f': [str(x.date()) for x in hist.index], 'v': [round(float(x)) for x in hist.values]},
         'pct_tiempo': {l: round(100 * float((pd.cut(sc.dropna(), BANDS, labels=LAB) == l).mean())) for l in LAB}}
    t0 = sc.first_valid_index()
    if a in ('BTC', 'nasdaq100'):
        w = T.regla_puntuacion(sc, a == 'BTC')
        ue, ops = mult(c, w, a, t0); r = {'total': round(float(ue.iloc[-1]), 2), 'peor': round(float(ue.min()), 2), 'ops': len(ops), 'pares': pares(ops, c[c.index >= t0], ue)}
        r['D'] = round(float(mult(c, w, a, t0, sp)[0].iloc[-1]), 2); r['V'] = round(float(mult(c, w, a, sp)[0].iloc[-1]), 2)
        r['D_ops'] = len(mult(c, w, a, t0, sp)[1]); r['V_ops'] = len(mult(c, w, a, sp)[1])
        if a == 'BTC':
            r['desde2023'] = round(float(mult(c, w, a, pd.Timestamp('2023-01-01'))[0].iloc[-1]), 2); r['peor_desde2020'] = round(float(mult(c, w, a, sp)[0].min()), 2)
            full = pd.DataFrame({'p': c[c.index >= t0], 'u': ue, 'w': w[w.index >= t0], 's': sc[sc.index >= t0]}); s_ = full.iloc[::7]
            if s_.index[-1] != full.index[-1]: s_ = pd.concat([s_, full.iloc[[-1]]])
            r['serie'] = {'f': [str(x.date()) for x in s_.index], 'p': [round(float(x), 2) for x in s_.p], 'u': [round(float(x), 3) for x in s_.u], 'w': [float(x) for x in s_.w], 's': [round(float(x)) for x in s_.s]}
            w2 = T.regla_puntuacion(sc, False); r['golpe'] = {'D': round(float(mult(c, w2, a, t0, sp)[0].iloc[-1]), 2), 'V': round(float(mult(c, w2, a, sp)[0].iloc[-1]), 2), 'total': round(float(mult(c, w2, a, t0)[0].iloc[-1]), 2), 'desde2023': round(float(mult(c, w2, a, pd.Timestamp('2023-01-01'))[0].iloc[-1]), 2), 'pares': pares(mult(c, w2, a, t0)[1], c[c.index >= t0], mult(c, w2, a, t0)[0])}
        d['regla'] = r
    OUT['punt'][a] = d
# plata semanal larga
S_ = load_raw('plata', '1w')['c']; G_ = load_raw('oro', '1w')['c'].reindex(S_.index).ffill()
m = sma(S_, 40); gm = sma(G_, 40); hi = S_.rolling(52, min_periods=26).max(); r_ = np.log(S_).diff(); sd = r_.ewm(span=52, min_periods=26).std(); z = np.log(S_ / m) / (sd * np.sqrt(40))
rp = (G_ / S_).rolling(520, min_periods=156).rank(pct=True) * 100
pts = pd.DataFrame({'t': 2 * (S_ > m), 's': 1 * (m > m.shift(4)), 'g': (2 * (G_ > gm)).where(gm.notna()), 'd': 2 * (S_ / hi - 1 > -0.10), 'z': 2 * (z < 1.7), 'r': (1 * (rp > 20)).where(rp.notna())}).astype(float).where(m.notna())
mxw = pd.Series({'t': 2, 's': 1, 'g': 2, 'd': 2, 'z': 2, 'r': 1}); scw = (100 * pts.sum(axis=1, skipna=True) / pts.notna().mul(mxw, axis=1).sum(axis=1)).where(m.notna())
X = pd.DataFrame({'s': scw, 'fr3': S_.shift(-13) / S_ - 1, 'fr12': S_.shift(-52) / S_ - 1}).dropna(subset=['s'])
OUT['plata_semanal'] = buckets(X, pd.Timestamp('2006-01-01'))
OUT['lectura'] = T.lectura()
json.dump(OUT, open(f'{W}/report_data2.json', 'w'), ensure_ascii=False)
for a in T.ACTIVOS:
    d = OUT['punt'][a]; print(a, 'hoy', OUT['lectura']['activos'][a]['puntuacion'], OUT['lectura']['activos'][a]['zona'], '| % tiempo', d['pct_tiempo'])
    for nm in ('D', 'V'):
        b = d['buckets'][nm]
        if b: print(f"   {nm} {b['desde']}-{b['hasta']} IC {b['ic3']}/{b['ic12']}: " + ' | '.join(f"{k}: n={v['n']} 3m {v['m3']} ({v['p3']}%+) 12m {v['m12']} ({v['p12']}%+)" for k, v in b['b'].items()))
    if 'regla' in d: r = d['regla']; print('   regla:', {k: r[k] for k in ('D', 'V', 'total', 'peor', 'ops', 'D_ops', 'V_ops')}, r.get('desde2023'), [(p['venta'], p['unid']) for p in r['pares']])
b = OUT['plata_semanal']
for nm in ('D', 'V'): print(f"plata semanal {nm} {b[nm]['desde']}-{b[nm]['hasta']} IC {b[nm]['ic3']}/{b[nm]['ic12']}: " + ' | '.join(f"{k}: n={v['n']} 3m {v['m3']} ({v['p3']}%+) 12m {v['m12']} ({v['p12']}%+)" for k, v in b[nm]['b'].items()))
