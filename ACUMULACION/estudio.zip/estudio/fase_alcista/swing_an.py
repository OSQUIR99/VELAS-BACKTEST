import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
from lib import *
for a in ASSETS:
    r = pd.read_csv(f'res_swing_{a}.csv')
    b = r[r.reg == 'bull'].copy()
    print(f'\n===== {a} ===== pruebas alcista {len(b)}; suma>0 {100*(b.suma>0).mean():.1f}%; mediana de suma {b.suma.median():.2f}; base media por op (T20) {r[(r.reg=="bull")&(r.rec=="T20")].base.iloc[0]:.4f}')
    ok = b[(b.s1 > 0) & (b.s2 > 0) & (b.n1 >= 5) & (b.n2 >= 5)].sort_values('suma', ascending=False)
    print('pasan ambas mitades (n>=5 por mitad):', len(ok))
    print(ok.head(25)[['senal', 'rec', 'n', 'gana', 'suma', 's1', 's2', 'n1', 'n2', 'media', 'base', 'z', 'dias']].round(3).to_string(index=False))
    # por familia de recompra: % positivo
    print(b.groupby('rec').apply(lambda x: pd.Series({'pos%': 100 * (x.suma > 0).mean(), 'med_suma': x.suma.median()})).round(2).T.to_string())
