"""Pérdida de impulso DENTRO de la fase alcista: media rápida cruza bajo la lenta -> vender; recomprar al recuperar. Vecinos y años."""
import pandas as pd, numpy as np, itertools, sys
pd.set_option('display.width', 250)
from lib import *
import swing as sw
def fam(a):
    F = sw.build(a); c = F['c']; cv = c.values; idx = F.index; cost = sw.COST[a]
    split = idx.searchsorted(pd.Timestamp(SPLIT[a] if a != 'plata' else '2018-01-01'))
    yrs = idx.year.values
    rows = []; TRS = {}
    for (f, s), rg, rec in itertools.product(((5, 20), (10, 20), (10, 30), (10, 50), (20, 50), (20, 100), (30, 100), (50, 100), (1, 20), (1, 50), (1, 100)), ('bull', 'bull2', 'todo'), ('cruce', 'r_fast', 'T10', 'T20')):
        ef = ema(c, f) if f > 1 else c; es = ema(c, s)
        sig = sw.onset(ef < es)
        m = sig.values & (F[rg].values if rg != 'todo' else True) & F['s200'].notna().values
        si = np.flatnonzero(m)
        if rec == 'cruce': rb, tmax = np.flatnonzero((ef > es).values), 10 ** 6
        elif rec == 'r_fast': rb, tmax = np.flatnonzero((c > (ema(c, max(f, 10)))).values), 60
        else: rb, tmax = None, int(rec[1:])
        t = sw.run(cv, si, rb, tmax, None, None, cost)
        if len(t) < 6: continue
        ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t]); h1 = ts < split
        d = dict(f=f, s=s, reg=rg, rec=rec, ops=len(g), gana=(g > 0).mean(), suma=g.sum(), s1=g[h1].sum(), s2=g[~h1].sum(), n2=(~h1).sum())
        if a == 'BTC': d['s23'] = g[idx[ts] >= '2023-01-01'].sum()
        rows.append(d); TRS[(f, s, rg, rec)] = (ts, np.array([x[1] for x in t]), g)
    return pd.DataFrame(rows), TRS, F
for a in (sys.argv[1:] or ASSETS):
    r, TRS, F = fam(a)
    print(f'\n== {a}: variantes {len(r)}; suma>0 {100*(r.suma>0).mean():.0f}%; ambas>0 {100*((r.s1>0)&(r.s2>0)).mean():.0f}%; mediana {r.suma.median():+.2f} (1ª {r.s1.median():+.2f}, 2ª {r.s2.median():+.2f})')
    print(r.groupby('reg').apply(lambda x: pd.Series({'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean(), 'med': x.suma.median(), 'med_s2': x.s2.median()})).round(2).T.to_string())
    if a == 'BTC':
        print(r[r.reg == 'bull'].sort_values('suma', ascending=False).head(14).round(2).to_string(index=False))
        ts, tr, g = TRS[(20, 50, 'bull', 'r_fast')]
        y = pd.Series(g, index=F.index[ts].year).groupby(level=0).agg(['sum', 'count']).round(2)
        print('20/50 r_fast por año:', y.T.to_string())
