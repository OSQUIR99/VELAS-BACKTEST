"""Prueba de 'elegir sin saber el futuro': cada 1 de enero se eligen las reglas que mejor habían ido HASTA entonces
y se aplican solo el año siguiente. Si hay asimetría de verdad, esto debe sumar unidades."""
import pandas as pd, numpy as np, pickle, sys
from lib import *
def wf(a, K=(1, 5, 20), crit='t', minn=8, start_years=8, tag='', filt=None):
    TR = pickle.load(open(f'{W}/swing_tr_{a}{tag}.pkl', 'rb'))
    if filt: TR = {k: v for k, v in TR.items() if filt(k)}
    keys = list(TR.keys())
    first = min(v[0][0] for v in TR.values()); last = max(v[1][-1] for v in TR.values())
    y0 = pd.Timestamp(first).year + start_years; y1 = pd.Timestamp(last).year
    out = {k: [] for k in K}; picks = []
    for Y in range(y0, y1 + 1):
        t0 = np.datetime64(f'{Y}-01-01'); t1 = np.datetime64(f'{Y+1}-01-01')
        sc = []
        for k in keys:
            ts, tr, g = TR[k]; m = tr < t0
            n = m.sum()
            if n < minn: sc.append(-9); continue
            gg = g[m]
            sc.append(gg.mean() / (gg.std() + 1e-9) * np.sqrt(n) if crit == 't' else gg.sum())
        sc = np.array(sc); order = np.argsort(-sc)
        for kk in K:
            sel = [keys[i] for i in order[:kk] if sc[i] > 0]
            if not sel: out[kk].append((Y, 0.0, 0)); continue
            tot = 0; nt = 0
            for k in sel:
                ts, tr, g = TR[k]; m = (ts >= t0) & (ts < t1); tot += g[m].sum(); nt += m.sum()
            out[kk].append((Y, tot / len(sel), nt))
        picks.append((Y, keys[order[0]], round(sc[order[0]], 2)))
    return out, picks
if __name__ == '__main__':
    for a in (sys.argv[1:] or ASSETS):
        for crit in ('t', 'sum'):
            out, picks = wf(a, crit=crit)
            s = ' | '.join(f'K={k}: suma {sum(x[1] for x in v):+.2f} (años + {sum(x[1]>0 for x in v)}/- {sum(x[1]<0 for x in v)}, ops {sum(x[2] for x in v)})' for k, v in out.items())
            print(a, crit, out[1][0][0], '->', out[1][-1][0], s)
        print('   últimas elegidas:', picks[-3:])
