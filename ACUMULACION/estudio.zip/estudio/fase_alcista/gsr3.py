import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
exec(open('gsr.py').read().split("rows = []")[0].replace("print(", "pass;(lambda *a, **k: None)("))
cuts = ['1990-01-01', '2000-01-01', '2010-01-01', '2020-01-01']
def tr(mode, win=260):
    # dos tramos: mitad en 1,5 desviaciones, mitad en 2; vuelta en la media
    xs = []
    for zin in (1.5, 2.0):
        x, turn, w, z = run(win, zin, 0.0, mode); xs.append(w)
    w = (xs[0] + xs[1]) / 2; base = {'plata': 0.0, 'oro': 1.0, 'ambos': 0.5}[mode]
    turn = (w - w.shift(1)).abs().fillna(0)
    port = w.shift(1).fillna(base) * rg + (1 - w.shift(1).fillna(base)) * rs
    lv = np.log1p(port - turn * 2 * COST).cumsum()
    bench = {'plata': np.log((1 + rs).cumprod()), 'oro': np.log((1 + rg).cumprod()), 'ambos': np.log(0.5 * (1 + rg).cumprod() + 0.5 * (1 + rs).cumprod())}[mode]
    x = lv - bench
    seg = [x[:cuts[0]].iloc[-1]] + [x[:cuts[i + 1]].iloc[-1] - x[:cuts[i]].iloc[-1] for i in range(3)] + [x.iloc[-1] - x[:cuts[3]].iloc[-1]]
    return x, seg, w
for win in (156, 260, 520):
    for mode in ('plata', 'oro', 'ambos'):
        x, seg, w = tr(mode, win)
        print(f'ventana {win//52} años, {mode}: x{np.exp(x.iloc[-1]):.2f} | por periodo (1975-89, 90s, 2000s, 2010s, 2020-26):', ' '.join(f'x{np.exp(s):.2f}' for s in seg), '| peor racha:', f'{100*(np.exp((x - x.cummax()).min())-1):.0f}%', '| % del tiempo cambiado:', round(100 * (w != {'plata': 0.0, 'oro': 1.0, 'ambos': 0.5}[mode]).mean()))
