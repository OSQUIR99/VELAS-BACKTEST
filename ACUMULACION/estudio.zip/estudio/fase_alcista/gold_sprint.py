import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250)
from lib import *
import swing as sw
def fam(a, split=None, liqs=('', 'F'), regs=('bull', 'todo')):
    F = sw.build(a); c = F['c'].values; idx = F.index; cost = sw.COST[a]; bpy = BPY[a]
    split = idx.searchsorted(pd.Timestamp(split or SPLIT[a]))
    rows = []
    for n, pc in itertools.product((10, 20, 40, 60), (95, 97, 99)):
        rp = pct_rolling(F['c'] / F['c'].shift(n) - 1, 3 * bpy, bpy)
        s = sw.onset(rp >= pc)
        for rg, lq in itertools.product(regs, liqs):
            m = s.values & (F['bull'].values if rg == 'bull' else True) & ((F['liq'] >= 50).fillna(False).values if lq == 'F' else True)
            si = np.flatnonzero(m)
            for lim, tmax in itertools.product((0.02, 0.03, 0.04, 0.05, 0.07), (40, 60, 90, 120)):
                t = sw.run(c, si, None, tmax, lim, None, cost)
                if len(t) < 6: continue
                ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t]); h1 = ts < split
                rows.append(dict(n=n, pc=pc, reg=rg, liq=lq, lim=lim, tmax=tmax, ops=len(g), gana=(g > 0).mean(), suma=g.sum(), s1=g[h1].sum(), s2=g[~h1].sum(), n1=h1.sum(), n2=(~h1).sum()))
    return pd.DataFrame(rows), F
if __name__ == '__main__':
    for a, sp in (('oro', None), ('plata', '2018-01-01'), ('sp500', None), ('nasdaq100', None), ('BTC', None)):
        r, F = fam(a, sp)
        print(f'\n== {a}: {len(r)} variantes; suma>0 {100*(r.suma>0).mean():.0f}%; ambas mitades>0 {100*((r.s1>0)&(r.s2>0)).mean():.0f}%; mediana suma {r.suma.median():+.2f}')
        print(r.groupby(['reg', 'liq']).apply(lambda x: pd.Series({'var': len(x), 'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean(), 'med_suma': x.suma.median(), 'med_s1': x.s1.median(), 'med_s2': x.s2.median()})).round(2).to_string())
        if a == 'oro':
            b = r[(r.reg == 'bull')]
            print(b.groupby(['n', 'pc']).apply(lambda x: pd.Series({'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean(), 'med': x.suma.median(), 'ops': x.ops.median()})).round(2).T.to_string())
            print(b.groupby(['lim']).apply(lambda x: pd.Series({'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean(), 'med': x.suma.median(), 'gana': x.gana.median()})).round(2).T.to_string())
            print(b.groupby(['tmax']).apply(lambda x: pd.Series({'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean(), 'med': x.suma.median()})).round(2).T.to_string())
