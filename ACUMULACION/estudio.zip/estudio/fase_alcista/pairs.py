"""Rotación entre dos activos: ¿acabas con más valor (y por tanto más unidades de ambos) que manteniendo los dos sin tocar?"""
import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250)
from lib import *
PX = {a: pd.read_parquet(f'{W}/px_{a}.parquet')['c'] for a in ASSETS}
# plata larga: semanal desde 1970 -> usar semanal para oro/plata
def simw(ra, rb, wA, cost):
    """wA: peso objetivo en A decidido al cierre t (ejecutado al cierre t+1). Devuelve log-valor relativo a mantener 50/50 sin tocar."""
    w = wA.shift(1).fillna(0.5)            # peso vigente durante el día t+1.. (ejecución al cierre siguiente)
    w_eff = w.shift(1).fillna(0.5)         # el peso ejecutado al cierre t+1 rinde desde t+2
    port = (w_eff * ra + (1 - w_eff) * rb)
    turn = (w_eff - w_eff.shift(1)).abs().fillna(0)
    lv = np.log1p(port - turn * 2 * cost).cumsum()
    ha = (1 + ra).cumprod(); hb = (1 + rb).cumprod()
    bench = np.log(0.5 * ha + 0.5 * hb)
    return lv - bench, turn
rows = []
for A, B in (('oro', 'plata'), ('sp500', 'nasdaq100'), ('sp500', 'oro'), ('nasdaq100', 'oro'), ('BTC', 'oro'), ('BTC', 'nasdaq100'), ('BTC', 'sp500')):
    d = pd.concat([PX[A], PX[B]], axis=1, keys=['a', 'b']).dropna()
    ra = d.a.pct_change().fillna(0); rb = d.b.pct_change().fillna(0); lr = np.log(d.a / d.b)
    cost = 0.001 if 'BTC' not in (A, B) else 0.00125
    mid = d.index[len(d) // 2]
    for n in (50, 100, 200):
        wA = (lr > lr.rolling(n).mean()).astype(float).where(lr.rolling(n).mean().notna(), 0.5)
        x, turn = simw(ra, rb, wA, cost)
        rows.append(dict(par=f'{A}/{B}', regla=f'impulso relativo {n}d', total=x.iloc[-1], h1=x[mid], h2=x.iloc[-1] - x[mid], cambios_año=turn.sum() / (len(d) / 252)))
    for win, zt in itertools.product((756, 1260), (1.0, 1.5, 2.0)):
        z = (lr - lr.rolling(win, min_periods=win // 2).mean()) / lr.rolling(win, min_periods=win // 2).std()
        st = pd.Series(np.nan, index=d.index); st[z > zt] = 0.0; st[z < -zt] = 1.0; st[(z.abs() < 0.25)] = 0.5
        wA = st.ffill().fillna(0.5)
        x, turn = simw(ra, rb, wA, cost)
        rows.append(dict(par=f'{A}/{B}', regla=f'vuelta a la media z{zt} ({win}d)', total=x.iloc[-1], h1=x[mid], h2=x.iloc[-1] - x[mid], cambios_año=turn.sum() / (len(d) / 252)))
    # reequilibrio simple 50/50 con bandas
    w = 0.5; ws = []; 
    va, vb = 0.5, 0.5; lv = []
    for i in range(len(d)):
        va *= 1 + ra.iloc[i]; vb *= 1 + rb.iloc[i]
        if abs(va / (va + vb) - 0.5) > 0.10:
            t = (va + vb); mv = abs(va - t / 2); t -= mv * 2 * cost; va = vb = t / 2
        lv.append(np.log(va + vb))
    lv = pd.Series(lv, index=d.index); bench = np.log(0.5 * (1 + ra).cumprod() + 0.5 * (1 + rb).cumprod()); x = lv - bench
    rows.append(dict(par=f'{A}/{B}', regla='reequilibrar 50/50 (banda 10 pt)', total=x.iloc[-1], h1=x[mid], h2=x.iloc[-1] - x[mid], cambios_año=np.nan))
    print(A, B, d.index[0].date(), '->', d.index[-1].date(), 'mitad', mid.date())
r = pd.DataFrame(rows).round(2)
print(r.to_string(index=False))
