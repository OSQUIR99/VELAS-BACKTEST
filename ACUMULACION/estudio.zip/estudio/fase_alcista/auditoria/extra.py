import numpy as np, pandas as pd
from a_core import *
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from b_run import indicators, prep, run, COST
pd.set_option('display.width', 220)
# --- A: year-end sanity values and Jan-1980 bars
sw = load('plata','1w'); gw = load('oro','1w')
print(sw.loc['1980-01-01':'1980-02-10', ['apertura','maximo','minimo','cierre']].to_string())
ye = pd.concat([gw.cierre.resample('YE').last().rename('gold'), sw.cierre.resample('YE').last().rename('silver')],axis=1)
ye.index=ye.index.year
print(ye.loc[[1975,1979,1980,1985,1990,1995,2000,2005,2008,2010,2015,2020,2024,2025]].round(2).T.to_string())
# --- A: rebuild weekly from daily where available (gold all history; silver 2009-09+), true Friday closes
gd = load('oro','1d').cierre; sd = load('plata','1d').cierre
gW = gd.resample('W-FRI').last().dropna()
sW_w = weekly('plata'); sW_d = sd.resample('W-FRI').last().dropna()
sW = pd.concat([sW_w.loc[:'2009-09-04'], sW_d.loc['2009-09-11':]])
alt = pd.concat([gW.rename('g'), sW.rename('s')],axis=1).dropna().loc['1975':'2026-09-25']; alt['R']=alt.g/alt.s
za,_,_ = zscore(alt.R)
for mode in ['silver','gold']:
    r = simulate(alt, za, mode); st = swap_table(r, alt, mode)
    print('daily-rebuilt weekly:', mode, 'x%.3f'%r['val'].iloc[-1], 'n', len(st), 'win', (st['gain%']>0).sum(), 'rows', len(alt))
print('last z %.3f R %.2f'%(za.iloc[-1], alt.R.iloc[-1]))
# --- A: two-tranche as two independent halves
full = ratio_frame().loc[:'2026-09-25']; z,_,_ = zscore(full.R)
for mode in ['silver','gold']:
    a = simulate(full,z,mode,tranches=((1.5,1.0),))['val']; b = simulate(full,z,mode,tranches=((2.0,1.0),))['val']
    v = 0.5*a+0.5*b
    per=[]
    for p0,p1 in [('1975','1989'),('1990','1999'),('2000','2009'),('2010','2019'),('2020','2026')]:
        seg=v.loc[p0:p1]; i0=v.index.get_loc(seg.index[0]); prev=v.iloc[i0-1] if i0>0 else 1.0
        per.append(round(seg.iloc[-1]/prev,3))
    print('two halves', mode, 'x%.3f'%v.iloc[-1], per, 'relDD %.1f%%'%(100*rel_dd(v)))
# rank of headline among grid
rows=[]
for win in [104,156,260,520]:
    zw,_,_=zscore(full.R,win)
    for ez in [1.0,1.5,2.0]:
        for xz in [0.0,0.5]:
            rows.append((win,ez,xz,np.log(simulate(full,zw,'silver',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1]),np.log(simulate(full,zw,'gold',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1])))
g=pd.DataFrame(rows,columns=['win','e','x','s','g'])
g['rs']=g.s.rank(ascending=False); g['rg']=g.g.rank(ascending=False)
print(g[(g.win==260)&(g.e==1.5)&(g.x==0)].to_string())
# grid restricted to post-1985 sample
rows=[]
sub=full.loc['1985':]
for win in [104,156,260,520]:
    zw,_,_=zscore(full.R,win); zw=zw.loc['1985':]
    for ez in [1.0,1.5,2.0]:
        for xz in [0.0,0.5]:
            rows.append((np.log(simulate(sub,zw,'silver',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1]),np.log(simulate(sub,zw,'gold',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1])))
q=pd.DataFrame(rows,columns=['s','g'])
print('grid from 1985: silver pos %d/24 median %.2f min %.2f | gold pos %d/24 median %.2f min %.2f'%((q.s>0).sum(),q.s.median(),q.s.min(),(q.g>0).sum(),q.g.median(),q.g.min()))
rows=[]
sub=full.loc['2000':]
for win in [104,156,260,520]:
    zw,_,_=zscore(full.R,win); zw=zw.loc['2000':]
    for ez in [1.0,1.5,2.0]:
        for xz in [0.0,0.5]:
            rows.append((np.log(simulate(sub,zw,'silver',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1]),np.log(simulate(sub,zw,'gold',tranches=((ez,1.0),),exit_z=xz)['val'].iloc[-1])))
q=pd.DataFrame(rows,columns=['s','g'])
print('grid from 2000: silver pos %d/24 median %.2f min %.2f | gold pos %d/24 median %.2f min %.2f'%((q.s>0).sum(),q.s.median(),q.s.min(),(q.g>0).sum(),q.g.median(),q.g.min()))
# max adverse excursion per silver-holder swap (in units vs not swapping)
r=simulate(full,z,'silver'); v=r['val']; ex=r['ex']
runs=(ex!=ex.shift()).cumsum()
for k,idx in ex[ex>0].groupby(runs[ex>0]).groups.items():
    i0=v.index.get_loc(idx[0]); base=v.iloc[i0-1]
    print(idx[0].date(), 'weeks', len(idx), 'worst interim %.1f%%'%(100*(v.loc[idx].min()/base-1)), 'final %.1f%%'%(100*(v.loc[idx[-1]]/base-1)))

# --- B: rule-consistent placebo: random onset days in bull phase with same rebuy rules
rng=np.random.default_rng(7)
for asset,start,pct,lab in [('sp500','1928-01-01',0.03,'SP'),('nasdaq100','1985-01-01',0.04,'NDX')]:
    f=indicators(prep(asset,start)); cv=f.c.values; e20=f.ema20.values; bull=f.bull.values; n=len(cv)
    hi=(f.rsi>=70).values; ab=(f.c>f.bbu).values; below=(f.ema10<f.ema20).values
    sh=lambda a: np.r_[False,a[:-1]]
    ons={'R1':hi&~sh(hi)&bull,'R2':ab&~sh(ab)&bull,'R3':below&~sh(below)&bull}
    rbs={'R1':lambda d,si,ps: cv[d]<=e20[d],'R2':lambda d,si,ps: cv[d]<=ps*(1-pct),'R3':lambda d,si,ps: cv[d]>e20[d]}
    for k in ons:
        tr=run(f,ons[k],rbs[k])
        sims=[];ns=[]
        p=ons[k].sum()/bull.sum()
        for it in range(300):
            on=bull&(rng.random(n)<p)
            t2=run(f,on,rbs[k]); sims.append(t2.lg.mean()); ns.append(len(t2))
        sims=np.array(sims)
        print(lab,k,'actual n=%d mean/trade %+.4f sum %+.3f | random-bull-day onset, same rebuy rule: n~%d mean/trade %+.4f (sd %.4f) -> pctile of actual %.0f%%'%(len(tr),tr.lg.mean(),tr.lg.sum(),np.mean(ns),sims.mean(),sims.std(),100*(sims<tr.lg.mean()).mean()))
