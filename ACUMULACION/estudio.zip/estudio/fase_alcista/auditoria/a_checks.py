import numpy as np, pandas as pd
from a_core import *
pd.set_option('display.width', 200)

full = ratio_frame().loc[:'2026-09-25']
zf, _, _ = zscore(full.R)
rs = simulate(full, zf, 'silver'); rg = simulate(full, zf, 'gold')

# (2) truncation test
print('== truncation test')
for end in ['1982-06-25', '1995-12-29', '2005-03-11', '2015-08-14', '2023-01-06']:
    # truncate RAW data before any processing
    g = load('oro', '1w'); s = load('plata', '1w')
    g = g[g.index <= end]; s = s[s.index <= end]
    gw = g['cierre'].resample('W-FRI').last().dropna(); sw = s['cierre'].resample('W-FRI').last().dropna()
    d = pd.concat([gw.rename('g'), sw.rename('s')], axis=1).dropna().loc['1975-01-01':]
    d['R'] = d.g / d.s
    zt, _, _ = zscore(d.R)
    a = simulate(d, zt, 'silver'); b = simulate(d, zt, 'gold')
    idx = d.index
    dz = (zt - zf.reindex(idx)).abs().max()
    dpos_s = (a['ex'] - rs['ex'].reindex(idx)).abs().max(); dtar_s = (a['target'] - rs['target'].reindex(idx)).abs().max()
    dpos_g = (b['ex'] - rg['ex'].reindex(idx)).abs().max(); dtar_g = (b['target'] - rg['target'].reindex(idx)).abs().max()
    dval = (a['val'] / rs['val'].reindex(idx) - 1).abs().max()
    print(end, 'n', len(d), 'last', idx[-1].date(), 'max|dz| %.2e' % dz, 'pos diff', dpos_s, dtar_s, dpos_g, dtar_g, 'val diff %.2e' % dval)

# (3) data sanity
print('\n== data sanity')
g = weekly('oro'); s = weekly('plata')
for nm, x in [('gold', g), ('silver', s)]:
    x = x.loc['1975':]
    r = x.pct_change()
    lr = np.log(x).diff()
    print(nm, 'n', len(x), 'dups', x.index.duplicated().sum(), 'nonpos', (x <= 0).sum())
    print('  weekly ret >|20%|:')
    print(r[r.abs() > 0.20].round(3).to_string())
    gaps = pd.Series(x.index[1:] - x.index[:-1], index=x.index[1:])
    print('  gaps >7d:', [(i.date(), v.days) for i, v in gaps[gaps > pd.Timedelta(days=7)].items()])
    # stale prints
    print('  zero-change weeks:', int((r == 0).sum()))
# missing weeks in joined frame
exp = pd.date_range(full.index[0], full.index[-1], freq='W-FRI')
print('missing weeks in joined frame:', [d.date() for d in exp.difference(full.index)])
# ratio weekly jumps
rr = np.log(full.R).diff()
print('ratio weekly log change > 0.15:'); print(rr[rr.abs() > 0.15].round(3).to_string())
print('ratio around extremes:')
print(full.loc['1980-01-04':'1980-02-08'].round(2).to_string())
print(full.loc['2020-03-06':'2020-04-03'].round(2).to_string())

# weekly vs daily Fridays 2010-2026
print('\n== weekly vs daily')
gd = load('oro', '1d')['cierre']; sd_ = load('plata', '1d')['cierre']
for nm, w, d in [('gold', g, gd), ('silver', s, sd_)]:
    dw = d.resample('W-FRI').last().dropna()
    j = pd.concat([w.rename('w'), dw.rename('d')], axis=1).dropna().loc['2010':'2026-09-25']
    rel = (j.w / j.d - 1)
    print(nm, 'n', len(j), 'max|rel diff| %.4f%%' % (100 * rel.abs().max()), 'n diff>0.1%%: %d' % (rel.abs() > 0.001).sum(), 'n>1%%: %d' % (rel.abs() > 0.01).sum())
    if (rel.abs() > 0.001).any():
        print(pd.concat([j, rel.rename('rel')], axis=1)[rel.abs() > 0.001].round(4).head(20).to_string())
# gold weekly vs daily all history
dw = gd.resample('W-FRI').last().dropna()
j = pd.concat([g.rename('w'), dw.rename('d')], axis=1).dropna().loc['1975':'2026-09-25']
rel = (j.w / j.d - 1)
print('gold all-history n', len(j), 'n diff>0.1%%: %d' % (rel.abs() > 0.001).sum(), 'max %.3f%%' % (100 * rel.abs().max()))
print(pd.concat([j, rel.rename('rel')], axis=1)[rel.abs() > 0.001].round(4).head(15).to_string())
# daily-based ratio backtest 2010+ using Friday closes from daily files (z from weekly history up to 2009, then daily Fridays)
gdw = gd.resample('W-FRI').last(); sdw = sd_.resample('W-FRI').last()
alt = full.copy()
jj = pd.concat([gdw.rename('g'), sdw.rename('s')], axis=1).dropna().loc['2010':'2026-09-25']
alt.loc[jj.index.intersection(alt.index), ['g', 's']] = jj.loc[jj.index.intersection(alt.index)]
alt['R'] = alt.g / alt.s
za, _, _ = zscore(alt.R)
ra = simulate(alt, za, 'silver'); print('silver holder with daily-file Fridays post-2010: x%.3f' % ra['val'].iloc[-1])
print(swap_table(ra, alt, 'silver').tail(3).to_string())

# (5) time swapped
print('\n== time in other metal')
print('silver holder in gold: %.1f%% of all weeks; %.1f%% of weeks since first valid z' % (100 * (rs['ex'] > 0).mean(), 100 * (rs['ex'][zf.notna()] > 0).mean()))
print('gold holder in silver: %.1f%% ; %.1f%%' % (100 * (rg['ex'] > 0).mean(), 100 * (rg['ex'][zf.notna()] > 0).mean()))

# (6) statistical strength
print('\n== stats')
for mode, r in [('silver', rs), ('gold', rg)]:
    st = swap_table(r, full, mode)
    lg = np.log(1 + st['gain%'] / 100)
    lgc = lg[st.status == 'closed']
    print(mode, 'n', len(lg), 'sum log %.3f' % lg.sum(), 'mean %.3f sd %.3f t=%.2f' % (lgc.mean(), lgc.std(), lgc.mean() / lgc.std() * np.sqrt(len(lgc))),
          'largest trade share of total log: %.0f%%' % (100 * lg.max() / lg.sum()))
# placebo: circular shift of the position series (keeps durations & clustering), relative to ratio path
lrR = np.log(full.R).diff().fillna(0).values
rng = np.random.default_rng(0)
for mode, r in [('silver', rs), ('gold', rg)]:
    pos = r['ex'].values
    sign = 1 if mode == 'silver' else -1   # silver holder in gold gains when R rises
    actual = (pos[:-1] * sign * lrR[1:]).sum()   # gross, position held at close t earns ratio move t->t+1
    sims = []
    n = len(pos)
    for k in range(5000):
        sh = rng.integers(130, n - 1)
        p = np.roll(pos, sh)
        sims.append((p[:-1] * sign * lrR[1:]).sum())
    sims = np.array(sims)
    print(mode, 'gross log gain actual %.3f; circular-shift placebo mean %.3f sd %.3f; p(placebo>=actual)=%.4f' % (actual, sims.mean(), sims.std(), (sims >= actual).mean()))
# mean-reversion strength of the ratio: AR(1) half-life on weekly lr, and ADF-like stat
lr = np.log(full.R)
x = lr.shift(1).dropna(); y = lr.diff().dropna()
x, y = x.align(y, join='inner')
X = np.column_stack([np.ones(len(x)), x.values]); beta, *_ = np.linalg.lstsq(X, y.values, rcond=None)
res = y.values - X @ beta; se = np.sqrt(res.var(ddof=2) * np.linalg.inv(X.T @ X)[1, 1])
print('AR(1) on log ratio: beta %.5f t(DF) %.2f half-life %.0f weeks' % (beta[1], beta[1] / se, np.log(0.5) / np.log(1 + beta[1])))
print('ratio start %.1f end %.1f; ln change %.3f' % (full.R.iloc[0], full.R.iloc[-1], np.log(full.R.iloc[-1] / full.R.iloc[0])))
# z at each entry and durations
for mode, r in [('silver', rs), ('gold', rg)]:
    ex = r['ex']
    runs = (ex != ex.shift()).cumsum()[ex > 0]
    print(mode, 'durations (weeks):', runs.groupby(runs).size().tolist())
