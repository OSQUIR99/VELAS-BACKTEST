import numpy as np, pandas as pd
from a_core import *
full = ratio_frame().loc[:'2026-09-25']; z,_,_ = zscore(full.R)
rg=full.g.pct_change().fillna(0); rs=full.s.pct_change().fillna(0)
def cw(mode, cost=0.00125):
    r=simulate(full,z,mode,tranches=((1.5,.5),(2.0,.5)))
    f=r['ex']  # fraction in other metal after execution at close t
    ro, rd = (rg, rs) if mode=='silver' else (rs, rg)
    fp=f.shift(1).fillna(0)
    port=fp*ro+(1-fp)*rd
    turn=(f-fp).abs()
    lv=np.log1p(port-turn*2*cost).cumsum()-np.log((1+rd).cumprod())
    return lv
for mode in ['silver','gold']:
    x=cw(mode); cuts=['1990-01-01','2000-01-01','2010-01-01','2020-01-01']
    seg=[x[:cuts[0]].iloc[-1]]+[x[:cuts[i+1]].iloc[-1]-x[:cuts[i]].iloc[-1] for i in range(3)]+[x.iloc[-1]-x[:cuts[3]].iloc[-1]]
    v=np.exp(x)
    print(mode,'const-weight accounting x%.3f'%np.exp(x.iloc[-1]), [round(float(np.exp(s)),3) for s in seg], 'relDD %.1f%%'%(100*(v/v.cummax()-1).min()))
