import numpy as np, pandas as pd
from a_core import *
pd.set_option('display.width', 200)

df = ratio_frame()
df = df.loc[:'2026-09-25']
print('sample', df.index[0].date(), df.index[-1].date(), len(df))
z, m, sd = zscore(df.R, 260)
print('last: R %.2f  mean5y %.2f  z %.3f' % (df.R.iloc[-1], np.exp(m.iloc[-1]), z.iloc[-1]))
print('R min', df.R.idxmin().date(), round(df.R.min(), 2), ' R max', df.R.idxmax().date(), round(df.R.max(), 2))

for mode in ['silver', 'gold']:
    r = simulate(df, z, mode)
    st = swap_table(r, df, mode)
    print('\n== single tranche', mode, 'holder: x%.3f' % r['val'].iloc[-1], ' relDD %.1f%%' % (100 * rel_dd(r['val'])))
    print(st.to_string())
    print('n swaps', len(st), 'winners', (st['gain%'] > 0).sum())
    if mode == 'silver':
        print('time in gold: %.1f%%' % (100 * (r['ex'] > 0).mean()), ' (from first valid z: %.1f%%)' % (100 * (r['ex'][z.notna()] > 0).mean()))
    else:
        print('time in silver: %.1f%%' % (100 * (r['ex'] > 0).mean()))

# two-tranche
print('\n== two-tranche (0.5 @1.5, 0.5 @2.0)')
periods = [('1975', '1989'), ('1990', '1999'), ('2000', '2009'), ('2010', '2019'), ('2020', '2026')]
for mode in ['silver', 'gold']:
    r = simulate(df, z, mode, tranches=((1.5, 0.5), (2.0, 0.5)))
    v = r['val']
    out = []
    for a, b in periods:
        seg = v.loc[a:b]
        prev = v.loc[:a].iloc[-1] if a != '1975' else 1.0
        # value just before the period start
        i0 = v.index.get_loc(seg.index[0])
        prev = v.iloc[i0 - 1] if i0 > 0 else 1.0
        out.append(round(seg.iloc[-1] / prev, 3))
    print(mode, 'x%.3f' % v.iloc[-1], 'sub', out, 'relDD %.1f%%' % (100 * rel_dd(v)), 'ntrades', len(r['trades']))
    dd = v / v.cummax() - 1
    print('   dd trough', dd.idxmin().date(), 'peak', v.loc[:dd.idxmin()].idxmax().date())

# robustness grid
print('\n== grid')
rows = []
for win in [104, 156, 260, 520]:
    zw, _, _ = zscore(df.R, win)
    for ez in [1.0, 1.5, 2.0]:
        for xz in [0.0, 0.5]:
            for mode in ['silver', 'gold']:
                # exit z 0.5 interpretation A: exit when signal x <= 0.5 (i.e. exit earlier, before reaching mean)
                rA = simulate(df, zw, mode, tranches=((ez, 1.0),), exit_z=xz)
                # interpretation B: exit when x <= -0.5 (overshoot past mean)
                rB = simulate(df, zw, mode, tranches=((ez, 1.0),), exit_z=-xz)
                rows.append((win, ez, xz, mode, np.log(rA['val'].iloc[-1]), np.log(rB['val'].iloc[-1])))
gr = pd.DataFrame(rows, columns=['win', 'entry', 'exit', 'mode', 'logA', 'logB'])
for mode in ['silver', 'gold']:
    q = gr[gr['mode'] == mode]
    for c in ['logA', 'logB']:
        print(mode, c, 'positive %d/%d' % ((q[c] > 0).sum(), len(q)), 'median %.3f' % q[c].median(), 'min %.3f max %.3f' % (q[c].min(), q[c].max()))
print(gr.pivot_table(index=['win', 'entry', 'exit'], columns='mode', values=['logA', 'logB']).round(2).to_string())

# sensitivity
print('\n== sensitivity')
r = simulate(df, z, 'silver', cost=0.01); print('cost 1%%/side silver: x%.3f' % r['val'].iloc[-1])
r = simulate(df, z, 'gold', cost=0.01); print('cost 1%%/side gold: x%.3f' % r['val'].iloc[-1])
for dl in [1, 2, 4, 8]:
    r = simulate(df, z, 'silver', delay=dl); r2 = simulate(df, z, 'gold', delay=dl)
    print('delay %d: silver x%.3f gold x%.3f' % (dl, r['val'].iloc[-1], r2['val'].iloc[-1]))
r = simulate(df, z, 'silver', delay=0) if False else None

# start-date dependence
print('\n== start dates (silver holder, single tranche; z computed with full history, trading from start)')
for st in ['1975', '1985', '2000', '2010']:
    sub = df.loc[st:]
    zs = z.loc[st:]
    r = simulate(sub, zs, 'silver'); r2 = simulate(sub, zs, 'gold')
    rt = simulate(sub, zs, 'silver', tranches=((1.5, .5), (2.0, .5)))
    stb = swap_table(r, sub, 'silver')
    print(st, 'silver x%.3f (n=%d, win=%d)' % (r['val'].iloc[-1], len(stb), (stb['gain%'] > 0).sum()), '2tr x%.3f' % rt['val'].iloc[-1], 'gold x%.3f' % r2['val'].iloc[-1])
print('-- z recomputed from scratch from start date')
for st in ['1985', '2000', '2010']:
    sub = df.loc[st:]
    zs, _, _ = zscore(sub.R, 260)
    r = simulate(sub, zs, 'silver'); r2 = simulate(sub, zs, 'gold')
    print(st, 'silver x%.3f gold x%.3f' % (r['val'].iloc[-1], r2['val'].iloc[-1]))

# excluding the open trade
r = simulate(df, z, 'silver'); v = r['val']
print('\nsilver value before last (open) swap: x%.3f' % v.loc[:'2025-12-12'].iloc[-1])
