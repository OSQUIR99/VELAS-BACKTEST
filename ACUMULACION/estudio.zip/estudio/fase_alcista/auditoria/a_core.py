import numpy as np, pandas as pd
BASE = '/mnt/user-data/uploads/VELAS PARA BACKTEST/TRADICIONAL/'


def load(asset, tf):
    d = pd.read_parquet(BASE + asset + '/' + tf + '.parquet')
    d['date'] = (d['fecha'] + pd.Timedelta(hours=4)).dt.floor('D')
    return d.set_index('date').sort_index()


def weekly(asset):
    d = load(asset, '1w')
    return d['cierre'].resample('W-FRI').last().dropna()


def ratio_frame(start='1975-01-01', end=None):
    g = weekly('oro'); s = weekly('plata')
    df = pd.concat([g.rename('g'), s.rename('s')], axis=1).dropna()
    df = df.loc[start:end] if end else df.loc[start:]
    df['R'] = df.g / df.s
    return df


def zscore(R, win=260, minp=None):
    if minp is None:
        minp = win // 2
    lr = np.log(R)
    m = lr.rolling(win, min_periods=minp).mean()
    sd = lr.rolling(win, min_periods=minp).std()
    return (lr - m) / sd, m, sd


def simulate(df, z, mode='silver', tranches=((1.5, 1.0),), exit_z=0.0, cost=0.00125, delay=1):
    """mode 'silver': default silver; swap to gold when z < -thr; back when z >= -exit_z.
    mode 'gold': default gold; swap to silver when z > thr; back when z <= exit_z.
    tranches: tuple of (threshold, fraction). Target fraction in the 'other' metal is decided
    at close t and executed at close t+delay.
    Returns dict with units series (in default metal equivalent), relative multiple, swaps."""
    zz = z.values
    n = len(df)
    g = df.g.values; s = df.s.values
    sign = -1.0 if mode == 'silver' else 1.0   # signal variable x = sign*z ; enter when x > thr
    x = sign * zz
    # desired fraction in the other metal, decided at close t (state machine)
    target = np.zeros(n)
    f = 0.0
    for t in range(n):
        if np.isnan(x[t]):
            target[t] = f
            continue
        if f > 0 and x[t] <= exit_z:
            f = 0.0
        else:
            need = sum(fr for thr, fr in tranches if x[t] > thr)
            # tranche levels are sticky until exit
            if need > f:
                f = need
        target[t] = f
    # executed fraction at close t = target[t-delay]
    ex = np.zeros(n)
    ex[delay:] = target[:-delay]
    # portfolio: units of default metal D and other metal O
    pD = s if mode == 'silver' else g
    pO = g if mode == 'silver' else s
    D = 1.0; O = 0.0
    val = np.zeros(n)  # value in default-metal units
    cur = 0.0
    trades = []
    for t in range(n):
        if ex[t] != cur:
            tot = D + O * pO[t] / pD[t]          # in default units
            cur_other_val = O * pO[t] / pD[t]
            new_other_val = ex[t] * tot           # target value in other metal (pre-cost)
            delta = new_other_val - cur_other_val
            # cost: both legs, cost per side on traded notional
            c = abs(delta) * (1 - (1 - cost) ** 2)
            if delta > 0:   # sell default, buy other
                D -= delta
                O += (delta - c) * pD[t] / pO[t]
            else:
                O -= (-delta) * pD[t] / pO[t]
                D += (-delta) - c
            trades.append((df.index[t], cur, ex[t], df.R.values[t], zz[t - delay] if t - delay >= 0 else np.nan))
            cur = ex[t]
        val[t] = D + O * pO[t] / pD[t]
    return dict(val=pd.Series(val, index=df.index), target=pd.Series(target, index=df.index),
                ex=pd.Series(ex, index=df.index), trades=trades)


def swap_table(res, df, mode):
    """Round-trip swaps for single-tranche: units multiple per round trip."""
    rows = []
    tr = res['trades']
    v = res['val']
    i = 0
    while i < len(tr):
        d0, a, b, R0, z0 = tr[i]
        if b > a:
            # find exit
            j = i + 1
            while j < len(tr) and tr[j][2] != 0:
                j += 1
            if j < len(tr):
                d1 = tr[j][0]; R1 = tr[j][3]
                pos0 = v.index.get_loc(d0); pos1 = v.index.get_loc(d1)
                gain = v.iloc[pos1] / v.iloc[pos0 - 1] - 1
                rows.append((d0.date(), round(R0, 2), d1.date(), round(R1, 2), round(gain * 100, 1), 'closed'))
            else:
                pos0 = v.index.get_loc(d0)
                gain = v.iloc[-1] / v.iloc[pos0 - 1] - 1
                rows.append((d0.date(), round(R0, 2), None, round(df.R.iloc[-1], 2), round(gain * 100, 1), 'open'))
            i = j + 1
        else:
            i += 1
    return pd.DataFrame(rows, columns=['in', 'R_in', 'out', 'R_out', 'gain%', 'status'])


def rel_dd(val):
    return (val / val.cummax() - 1).min()
