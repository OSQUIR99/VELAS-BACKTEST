import numpy as np, pandas as pd
from a_core import load, BASE
pd.set_option('display.width', 220)
COST = 0.001


def prep(asset, start):
    d = load(asset, '1d')
    d = d[~d.index.duplicated(keep='last')]
    c = d['cierre'].loc[start:].copy()
    return c


def rsi_wilder(c, n=14):
    dlt = c.diff()
    up = dlt.clip(lower=0); dn = (-dlt).clip(lower=0)
    # Wilder: seed with SMA of first n changes, then recursive
    au = np.full(len(c), np.nan); ad = np.full(len(c), np.nan)
    u = up.values; d = dn.values
    au[n] = u[1:n + 1].mean(); ad[n] = d[1:n + 1].mean()
    for i in range(n + 1, len(c)):
        au[i] = (au[i - 1] * (n - 1) + u[i]) / n
        ad[i] = (ad[i - 1] * (n - 1) + d[i]) / n
    rs = au / np.where(ad == 0, np.nan, ad)
    r = 100 - 100 / (1 + rs)
    r[(ad == 0) & ~np.isnan(au)] = 100
    return pd.Series(r, index=c.index)


def indicators(c):
    f = pd.DataFrame({'c': c})
    f['sma200'] = c.rolling(200).mean()
    f['bull'] = (c > f.sma200) & (f.sma200 > f.sma200.shift(20))
    f['rsi'] = rsi_wilder(c)
    f['ema10'] = c.ewm(span=10, adjust=False).mean()
    f['ema20'] = c.ewm(span=20, adjust=False).mean()
    m = c.rolling(20).mean(); s = c.rolling(20).std(ddof=0)
    f['bbu'] = m + 2 * s; f['bbl'] = m - 2 * s
    return f


def run(f, onset, rebuy_fn, maxbars=60, timeout_mode='decision'):
    """onset: bool array (signal at close t). sell at t+1. rebuy_fn(d, sell_idx, sell_px)->bool evaluated for d>sell_idx.
    Decision at close d -> execute at d+1. Timeout: decision at sell_idx+maxbars at the latest."""
    c = f.c.values; n = len(c)
    trades = []
    t = 0
    free_from = 0   # first index at which a new signal may fire
    on = np.where(onset)[0]
    k = 0
    while k < len(on):
        t = on[k]
        if t < free_from or t + 1 >= n:
            k += 1; continue
        si = t + 1; ps = c[si]
        d = si + 1; found = None; why = None
        while d < n:
            if rebuy_fn(d, si, ps):
                found = d; why = 'rule'; break
            if d - si >= maxbars:
                found = d; why = 'timeout'; break
            d += 1
        if found is None or found + 1 >= n:
            break   # open trade at the end -> dropped
        bi = found + 1; pb = c[bi]
        trades.append((f.index[t], f.index[si], f.index[bi], ps, pb, np.log(ps / pb) + 2 * np.log(1 - COST), why, bi - si))
        free_from = bi   # a signal at/after the rebuy close can fire again
        k += 1
    return pd.DataFrame(trades, columns=['sig', 'sell', 'rebuy', 'ps', 'pb', 'lg', 'why', 'bars'])


def summ(name, tr):
    if len(tr) == 0:
        print(name, 'no trades'); return
    print('%-40s n=%4d win=%5.1f%% sumlog=%+7.3f mean=%+.4f med bars=%d timeout=%4.1f%%' % (
        name, len(tr), 100 * (tr.lg > 0).mean(), tr.lg.sum(), tr.lg.mean(), tr.bars.median(), 100 * (tr.why == 'timeout').mean()))


def all_rules(asset, start, pct, label, sub=None):
    c = prep(asset, start)
    f = indicators(c)
    if sub:
        pass
    cv = f.c.values; e20 = f.ema20.values
    bull = f.bull.values
    out = {}
    # Rule 1
    hi = (f.rsi >= 70).values
    hi_prev = np.r_[False, hi[:-1]]
    bull_prev = np.r_[False, bull[:-1]]
    on_a = hi & ~hi_prev & bull                      # RSI crossing, bull at t
    on_b = (hi & bull) & ~(hi_prev & bull_prev)      # onset of combined condition
    rb1 = lambda d, si, ps: cv[d] <= e20[d]
    for nm, on in [('R1 RSI70 cross (rsi-cross&bull)', on_a), ('R1 RSI70 (combined onset)', on_b)]:
        tr = run(f, on, rb1); out[nm] = tr
    # Rule 2
    ab = (f.c > f.bbu).values
    ab_prev = np.r_[False, ab[:-1]]
    on_a = ab & ~ab_prev & bull
    on_b = (ab & bull) & ~(ab_prev & bull_prev)
    rb2 = lambda d, si, ps: cv[d] <= ps * (1 - pct)
    for nm, on in [('R2 BBupper (cross&bull)', on_a), ('R2 BBupper (combined onset)', on_b)]:
        out[nm] = run(f, on, rb2)
    # Rule 3
    below = (f.ema10 < f.ema20).values
    below_prev = np.r_[False, below[:-1]]
    on_a = below & ~below_prev & bull
    on_b = (below & bull) & ~(below_prev & bull_prev)
    rb3 = lambda d, si, ps: cv[d] > e20[d]
    for nm, on in [('R3 EMA10<EMA20 cross (cross&bull)', on_a), ('R3 EMA10<EMA20 (combined onset)', on_b)]:
        out[nm] = run(f, on, rb3)
    print('\n==', label, c.index[0].date(), c.index[-1].date(), 'n', len(c), 'bull days %.1f%%' % (100 * f.bull.mean()))
    for k, v in out.items():
        summ(k, v)
    return f, out


fs, os_ = all_rules('sp500', '1928-01-01', 0.03, 'S&P500 1928+')
fn, on_ = all_rules('nasdaq100', '1985-01-01', 0.04, 'Nasdaq100 1985+')

# sub-periods
print('\n== sub-period sums (first variant of each rule)')
for lab, o in [('SP', os_), ('NDX', on_)]:
    for k, tr in o.items():
        if 'combined' in k: continue
        g = tr.groupby(pd.cut(tr.sell.dt.year, [1900, 1949, 1979, 1999, 2009, 2030])).lg.agg(['count', 'sum'])
        print(lab, k, ' | '.join('%s: n=%d sum=%+.2f' % (str(i), r['count'], r['sum']) for i, r in g.iterrows()))

# placebo: random sale days in bull phase with identical holding lengths -> is loss just drift?
print('\n== placebo: sell on random bull days, same holding-length distribution (drift + cost baseline)')
rng = np.random.default_rng(1)
for lab, f, o in [('SP', fs, os_), ('NDX', fn, on_)]:
    cv = f.c.values; n = len(cv); bull_idx = np.where(f.bull.values)[0]
    for k, tr in o.items():
        if 'combined' in k: continue
        bars = tr.bars.values
        sims = []
        for it in range(2000):
            t = rng.choice(bull_idx[bull_idx < n - 70], size=len(bars))
            si = t + 1; bi = np.minimum(si + bars, n - 1)
            sims.append((np.log(cv[si] / cv[bi]) + 2 * np.log(1 - COST)).sum())
        sims = np.array(sims)
        print(lab, '%-36s actual %+.3f | placebo mean %+.3f sd %.3f | pct of placebo below actual %.1f%%' % (k, tr.lg.sum(), sims.mean(), sims.std(), 100 * (sims < tr.lg.sum()).mean()))

# forward returns
print('\n== S&P forward 20-bar return close t+1 -> close t+21')
f = fs.copy()
f['fwd'] = f.c.shift(-21) / f.c.shift(-1) - 1
for a, b in [('2000', '2026'), ('1928', '2026'), ('1928', '1999')]:
    q = f.loc[a:b]
    A = q[q.bull].fwd; B = q[q.bull & (q.rsi >= 70)].fwd; C = q[q.bull & (q.c < q.bbl)].fwd; ALL = q.fwd
    print(a, b, 'bull: %.2f%% (n=%d) | bull&RSI>=70: %.2f%% (n=%d) | bull&<BBlow: %.2f%% (n=%d) | all days %.2f%%' % (
        100 * A.mean(), A.notna().sum(), 100 * B.mean(), B.notna().sum(), 100 * C.mean(), C.notna().sum(), 100 * ALL.mean()))
    # crude significance for C vs A: cluster by onset episodes
    cc = q[q.bull & (q.c < q.bbl)]
    ep = (cc.index.to_series().diff() > pd.Timedelta(days=30)).cumsum()
    print('    (c) independent clusters (gap>30d): %d ; cluster-mean fwd %.2f%%, se %.2f%%' % (ep.nunique(), 100 * cc.fwd.groupby(ep.values).mean().mean(), 100 * cc.fwd.groupby(ep.values).mean().std() / np.sqrt(ep.nunique())))
f = fn.copy(); f['fwd'] = f.c.shift(-21) / f.c.shift(-1) - 1
q = f.loc['2000':'2026']
print('NDX 2000-2026 bull %.2f%% | RSI>=70 %.2f%% | <BBlow %.2f%%' % (100 * q[q.bull].fwd.mean(), 100 * q[q.bull & (q.rsi >= 70)].fwd.mean(), 100 * q[q.bull & (q.c < q.bbl)].fwd.mean()))

# data sanity of S&P
c = prep('sp500', '1928-01-01')
r = c.pct_change()
print('\nS&P data: first', c.index[0].date(), 'max |ret|>12%:', [(i.date(), round(v, 3)) for i, v in r[r.abs() > 0.12].items()])
gaps = pd.Series(c.index[1:] - c.index[:-1], index=c.index[1:])
print('gaps > 6 days:', [(i.date(), v.days) for i, v in gaps[gaps > pd.Timedelta(days=6)].items()][:20])
print('bars per year sample:', c.groupby(c.index.year).size().loc[[1928, 1929, 1940, 1950, 1960, 1970, 2000, 2025]].to_dict())
c = prep('nasdaq100', '1985-01-01'); r = c.pct_change()
print('NDX first', c.index[0].date(), 'max |ret|>12%:', [(i.date(), round(v, 3)) for i, v in r[r.abs() > 0.12].items()])
gaps = pd.Series(c.index[1:] - c.index[:-1], index=c.index[1:])
print('gaps > 6 days:', [(i.date(), v.days) for i, v in gaps[gaps > pd.Timedelta(days=6)].items()][:20])
print('bars per year:', c.groupby(c.index.year).size().loc[[1985, 1986, 1990, 2000, 2025]].to_dict())
