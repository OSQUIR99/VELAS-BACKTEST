import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
pd.set_option('display.width', 250)
exec(open('gsr.py').read().split("rows = []")[0].replace("print(", "pass;(lambda *a, **k: None)("))
R = d.g / d.s
def trades(mode, win=260, zin=1.5, zout=0.0, cost=COST):
    x, turn, w, z = run(win, zin, zout, mode)
    base = 0.0 if mode == 'plata' else 1.0
    ch = w[(w != w.shift(1)) & w.shift(1).notna()]
    out = []; t0 = None
    for dt, v in ch.items():
        if v != base: t0 = dt
        elif t0 is not None:
            r0, r1 = R[t0], R[dt]
            gl = (np.log(r1 / r0) if mode == 'plata' else np.log(r0 / r1)) + 4 * np.log(1 - cost)
            out.append((t0.date(), round(r0, 1), dt.date(), round(r1, 1), round((dt - t0).days / 30.4), round(100 * (np.exp(gl) - 1), 1))); t0 = None
    if t0 is not None:
        r0, r1 = R[t0], R.iloc[-1]; gl = (np.log(r1 / r0) if mode == 'plata' else np.log(r0 / r1)) + 2 * np.log(1 - cost)
        out.append((t0.date(), round(r0, 1), 'ABIERTA', round(r1, 1), round((R.index[-1] - t0).days / 30.4), round(100 * (np.exp(gl) - 1), 1)))
    return pd.DataFrame(out, columns=['cambio', 'ratio', 'vuelta', 'ratio_v', 'meses', 'unidades_%']), x, z
for mode in ('plata', 'oro'):
    t, x, z = trades(mode)
    print(f'\n== tengo {mode}: ventana 5 años, entrar en 1,5 desviaciones, volver en la media | total x{np.exp(x.iloc[-1]):.2f} | {len(t)} cambios, {int((t["unidades_%"]>0).sum())} ganan')
    print(t.to_string(index=False))
print('\nz hoy (5 años):', round(z.iloc[-1], 2), 'ratio', round(R.iloc[-1], 1), 'media 5a', round(np.exp(lr.rolling(260).mean().iloc[-1]), 1), 'banda ±1,5:', round(np.exp(lr.rolling(260).mean().iloc[-1] - 1.5 * lr.rolling(260).std().iloc[-1]), 1), round(np.exp(lr.rolling(260).mean().iloc[-1] + 1.5 * lr.rolling(260).std().iloc[-1]), 1))
print(pd.DataFrame({'ratio': R, 'z': z}).iloc[-60::4].round(2).T.to_string())
# sensibilidad a costes y retraso
for cst, lag in ((0.00125, 1), (0.005, 1), (0.01, 1), (0.00125, 2), (0.00125, 4)):
    COST = cst; res = []
    for mode in ('plata', 'oro', 'ambos'):
        x, turn, w, z2 = run(260, 1.5, 0.0, mode, lag=lag); res.append(f'{mode} x{np.exp(x.iloc[-1]):.2f}')
    print(f'coste por lado {100*cst:.3f}% retraso {lag} sem:', ' | '.join(res))
