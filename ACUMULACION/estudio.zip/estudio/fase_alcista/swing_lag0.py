import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from lib import *
import swing as sw
for a in ASSETS:
    res, TR, F = sw.study(a, lag=0, save=False)
    b = res[res.reg == 'bull']
    print(a, 'ejecución en el mismo cierre: pruebas', len(b), '| suma>0', round(100 * (b.suma > 0).mean(), 1), '% | ambas mitades>0', round(100 * ((b.s1 > 0) & (b.s2 > 0)).mean(), 1), '% | media por op', round(100 * b.suma.sum() / b.n.sum(), 2), '%')
