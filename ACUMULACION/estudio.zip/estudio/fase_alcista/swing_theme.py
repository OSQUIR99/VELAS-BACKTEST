import pandas as pd, numpy as np, pickle
pd.set_option('display.width', 250)
from lib import *
# 1) efecto agregado del semáforo de liquidez sobre TODAS las señales (alcista): media por operación
for a in ASSETS:
    r = pd.read_csv(f'res_swing_{a}.csv'); b = r[r.reg == 'bull'].copy()
    b['cond'] = np.where(b.senal.str.endswith('&liqH'), 'H', np.where(b.senal.str.endswith('&liqF'), 'F', '-'))
    b['base_s'] = b.senal.str.replace('&liqH', '').str.replace('&liqF', '')
    g = b.groupby('cond').apply(lambda x: pd.Series({'reglas': len(x), 'ops': x.n.sum(), 'media_op%': 100 * x.suma.sum() / x.n.sum(),
                                                    'm1%': 100 * x.s1.sum() / max(x.n1.sum(), 1), 'm2%': 100 * x.s2.sum() / max(x.n2.sum(), 1),
                                                    'pos%': 100 * (x.suma > 0).mean(), 'ambas%': 100 * ((x.s1 > 0) & (x.s2 > 0)).mean()}))
    print(a); print(g.round(2).to_string())
# 2) por familia de señal (sin condicionante), media por operación
fam = {'sobrecompra': ('rsi', 'bbz', 'z20', 'z50', 'z200', 'kelt', 'd20p', 'd50p', 'd200p', 'roc', 'up>=', 'wup', 'd20wp', 'hi252'),
       'agotamiento': ('rev_', 'out_', 'climax', 'w_rev', 'w_out', 'rsi_x70', 'bb_reentra', 'z50_gira'),
       'pierde_impulso': ('x_e20', 'x_s50', 'lo20', 'lo10', 'chand', 'w_x', 'e10x20', 'e20x50'),
       'divergencias': ('div',), 'externos': ('fng', 'fund', 'mvrv', 'etf', 'exflow', 'delta30p', 'vix', 'cot', 'oi_', 'liq_hostil')}
def famof(s):
    for k, pre in fam.items():
        if s.startswith(pre): return k
    return 'otros'
rows = []
for a in ASSETS:
    r = pd.read_csv(f'res_swing_{a}.csv'); b = r[(r.reg == 'bull') & ~r.senal.str.contains('&liq')].copy()
    b['fam'] = b.senal.map(famof)
    for f, x in b.groupby('fam'):
        rows.append(dict(activo=a, fam=f, reglas=len(x), media_op=100 * x.suma.sum() / x.n.sum(), m1=100 * x.s1.sum() / max(x.n1.sum(), 1), m2=100 * x.s2.sum() / max(x.n2.sum(), 1), pos=100 * (x.suma > 0).mean(), ambas=100 * ((x.s1 > 0) & (x.s2 > 0)).mean()))
print(pd.DataFrame(rows).round(2).to_string(index=False))
print('\n=== por régimen y familia (sin condicionante de liquidez): media por operación % ===')
rows = []
for a in ASSETS:
    r = pd.read_csv(f'res_swing_{a}.csv'); b = r[~r.senal.str.contains('&liq')].copy(); b['fam'] = b.senal.map(famof)
    for (rg, f), x in b.groupby(['reg', 'fam']):
        rows.append(dict(activo=a, reg=rg, fam=f, media_op=100 * x.suma.sum() / x.n.sum(), pos=100 * (x.suma > 0).mean(), ambas=100 * ((x.s1 > 0) & (x.s2 > 0)).mean()))
t = pd.DataFrame(rows)
print(t.pivot_table(index=['activo', 'fam'], columns='reg', values=['media_op', 'pos']).round(2).to_string())
