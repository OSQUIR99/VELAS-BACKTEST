import pandas as pd, numpy as np, itertools, sys
pd.set_option('display.width', 250)
from lib import *
import swing as sw
FF = {a: sw.build(a) for a in ASSETS}
SP = dict(SPLIT); SP['plata'] = '2018-01-01'
print('=== A) CONFLUENCIA: nº de señales de venta distintas en los últimos 10 días (fase alcista) ===')
for a in ASSETS:
    F = FF[a]; S = sw.signals(a, F); c = F['c'].values; idx = F.index; split = idx.searchsorted(pd.Timestamp(SP[a]))
    grp = {'rsi': ['rsi14>=75', 'rsi14w>=75'], 'banda': ['bbz>=2.5', 'kelt>=3'], 'estir': ['z50>=2.5', 'd50p>=97', 'z200>=1.5'], 'sprint': ['roc20p>=97', 'roc60p>=97'],
           'div': ['div_bear_rsi', 'div_bear_macd', 'divw_bear_rsi'], 'vela': ['rev_d20', 'w_rev', 'out_d20', 'climax_rev'], 'ext': ['fng>=75', 'fng>=80', 'fund7>=50', 'cot_idx>=90']}
    cnt = sum((pd.concat([S[k] for k in ks if k in S], axis=1).any(axis=1).rolling(10, min_periods=1).max() > 0).astype(int) for g, ks in grp.items() if any(k in S for k in ks))
    out = []
    for k in (3, 4, 5):
        si = np.flatnonzero((sw.onset(cnt >= k) & F['bull']).values)
        for rn in ('T20', 'e20_60', 's50_120', 'limS_60', 'limB_120', 'rsi40_60'):
            cn, tmax, lim, ch = sw.specs(a)[rn]
            t = sw.run(c, si, sw.rebuy_conds(F).get(cn), tmax, lim, ch, sw.COST[a])
            if len(t) < 4: continue
            ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t]); h1 = ts < split
            out.append(f'k{k}/{rn}: n{len(g)} {g.sum():+.2f} ({g[h1].sum():+.2f},{g[~h1].sum():+.2f})')
    print(a, ' | '.join(out))

print('\n=== B) LADO COMPRADOR en fase alcista: rentabilidad media a 20 barras tras cada tipo de día (%), por mitades ===')
for a in ASSETS:
    F = FF[a]; c = F['c']; idx = F.index; bull = F['bull']
    f20 = 100 * (c.shift(-21) / c.shift(-1) - 1)
    h1 = idx < SP[a]
    lo20 = c <= F['lo20']; dd = c / F['hi252'] - 1
    conds = {'cualquier día alcista': bull, 'RSI14>=70': bull & (F['rsi14'] >= 70), 'RSI14>=80': bull & (F['rsi14'] >= 80), 'sobre banda sup.': bull & (F['bbz'] >= 2),
             'RSI14<=35': bull & (F['rsi14'] <= 35), 'RSI14<=30': bull & (F['rsi14'] <= 30), 'bajo banda inf.': bull & (F['bbz'] <= -2), 'mínimo de 20 d': bull & lo20,
             'toca media 50': bull & (c <= F['s50']) & (c.shift(1) > F['s50'].shift(1)), 'cerca media 200 (<3%)': bull & (c / F['s200'] - 1 < 0.03)}
    row = []
    for k, m in conds.items():
        m = m.fillna(False)
        row.append(f'{k}: {f20[m & h1].mean():+.1f}/{f20[m & ~h1].mean():+.1f} (n {int((m&h1).sum())}/{int((m&~h1).sum())})')
    print(a, ' | '.join(row))

print('\n=== C) CALENDARIO: rentabilidad media diaria (%) por tramo, por mitades ===')
for a in ASSETS:
    c = FF[a]['c']; r = 100 * np.log(c).diff(); idx = c.index; h1 = idx < SP[a]
    # día del mes en orden de sesiones
    ym = idx.to_period('M'); pos = pd.Series(1, index=idx).groupby(ym).cumsum(); rev = pd.Series(1, index=idx)[::-1].groupby(ym[::-1]).cumsum()[::-1]
    tom = (pos <= 3) | (rev <= 1)
    print(a, f'cambio de mes (último+3 primeros): {r[tom & h1].mean():+.3f}/{r[tom & ~h1].mean():+.3f} ; resto del mes: {r[~tom & h1].mean():+.3f}/{r[~tom & ~h1].mean():+.3f}')
    mm = pd.DataFrame({'m1': r[h1].groupby(idx[h1].month).sum() / max(1, len(set(idx[h1].year))), 'm2': r[~h1].groupby(idx[~h1].month).sum() / max(1, len(set(idx[~h1].year)))}).round(1)
    print('   por mes (% medio del mes; 1ª mitad / 2ª mitad):', ' '.join(f'{m}:{mm.m1.get(m, np.nan):+.1f}/{mm.m2.get(m, np.nan):+.1f}' for m in range(1, 13)))
    dw = pd.DataFrame({'d1': r[h1].groupby(idx[h1].dayofweek).mean(), 'd2': r[~h1].groupby(idx[~h1].dayofweek).mean()}).round(3)
    print('   por día de la semana (L=0):', ' '.join(f'{d}:{dw.d1.get(d, np.nan):+.2f}/{dw.d2.get(d, np.nan):+.2f}' for d in dw.index))
