import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from lib import *
import swing as sw
for a in ('sp500', 'nasdaq100', 'plata', 'BTC', 'oro'):
    c = pd.read_parquet(f'px_{a}.parquet')['c']; cost = sw.COST[a]
    if a == 'plata':
        c = load_raw('plata', '1w')['c'].resample('W-FRI').last().dropna()
    m = c.resample('ME').last(); r = np.log(m).diff().dropna()
    out = []
    for mon in (9, 6, 5, 8, 2):
        x = r[r.index.month == mon]; g = -x + 2 * np.log(1 - cost)   # ganancia en unidades por estar fuera ese mes
        yrs = x.index.year
        segs = [(yrs.min(), 1959), (1960, 1989), (1990, 2009), (2010, 2026)] if a == 'sp500' else [(yrs.min(), 1999), (2000, 2012), (2013, 2026)] if a != 'BTC' else [(2011, 2018), (2019, 2026)]
        s = ' '.join(f'{lo}-{hi}: {g[(yrs>=lo)&(yrs<=hi)].sum():+.2f} ({int((x[(yrs>=lo)&(yrs<=hi)]<0).sum())}/{int(((yrs>=lo)&(yrs<=hi)).sum())} meses a la baja)' for lo, hi in segs)
        out.append(f'  mes {mon}: total {g.sum():+.2f} | media del mes {100*x.mean():+.2f}% t={x.mean()/x.std()*np.sqrt(len(x)):.2f} | {s}')
    print(a, c.index[0].date()); print('\n'.join(out))
# Septiembre condicionado a fase alcista a fin de agosto (S&P, Nasdaq)
for a in ('sp500', 'nasdaq100'):
    F = sw.build(a); c = F['c']; m = c.resample('ME').last(); r = np.log(m).diff()
    bull = F['bull'].resample('ME').last()
    x = r[r.index.month == 9]; b = bull.shift(1).reindex(x.index).fillna(False).astype(bool)
    print(a, f'septiembre con fase alcista a fin de agosto: media {100*x[b].mean():+.2f}% (n {b.sum()}, a la baja {int((x[b]<0).sum())}); sin fase alcista: {100*x[~b].mean():+.2f}% (n {(~b).sum()}, a la baja {int((x[~b]<0).sum())})')
    # segunda quincena de septiembre
    d = np.log(c).diff(); s2 = d[(d.index.month == 9) & (d.index.day >= 16)].groupby(d[(d.index.month == 9) & (d.index.day >= 16)].index.year).sum()
    print('   segunda quincena de septiembre: media', round(100 * s2.mean(), 2), '% ; desde 2000:', round(100 * s2[s2.index >= 2000].mean(), 2), '% ; a la baja', int((s2 < 0).sum()), 'de', len(s2))
