import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from lib import *
import swing as sw
SP = dict(SPLIT); SP['plata'] = '2018-01-01'
tot = 0; pos = 0; amb = 0; best = []
for a in ASSETS:
    F = sw.build(a); p = pd.read_parquet(f'{W}/px_{a}.parquet'); c = F['c']; r = np.log(c).diff(); bpy = BPY[a]
    rv10 = r.rolling(10).std(); rv60 = r.rolling(60).std(); rv250 = r.rolling(250).std()
    sd = r.ewm(span=bpy, min_periods=bpy // 2).std().shift(1)
    big = r < -2 * sd
    calm = (~big).astype(int); 
    since_big = sw.streak(~big.fillna(False))
    v = p.v; dist = ((c < c.shift(1)) & (v > v.shift(1))).rolling(25).sum()
    near_hi = c >= 0.97 * F['hi252']
    S = {'vol10/60>=1.5': sw.onset(rv10 / rv60 >= 1.5), 'vol10/250>=1.5 cerca de máx': sw.onset((rv10 / rv250 >= 1.5) & near_hi),
         '1er día -2σ tras 60 en calma': big & (since_big.shift(1) >= 60), '1er día -2σ tras 120 en calma': big & (since_big.shift(1) >= 120),
         'día -3σ en alcista': r < -3 * sd, '2 días -2σ en 10': sw.onset(big.rolling(10).sum() >= 2),
         'distribución>=6': sw.onset(dist >= 6), 'distribución>=8': sw.onset(dist >= 8)}
    if 'vix' in F and a in ('sp500', 'nasdaq100'):
        S['VIX +30% en 5d cerca de máx'] = sw.onset((F['vix'] / F['vix'].shift(5) - 1 >= 0.3) & near_hi)
        S['VIX>=20 desde <15'] = sw.onset(F['vix'] >= 20) & (F['vix'].rolling(20).min() < 15)
    cv = c.values; idx = F.index; split = idx.searchsorted(pd.Timestamp(SP[a])); RB = sw.rebuy_conds(F)
    for sn, s in S.items():
        si = np.flatnonzero((s.fillna(False) & F['bull']).values)
        for rn, (cn, tmax, lim, ch) in sw.specs(a).items():
            t = sw.run(cv, si, RB.get(cn), tmax, lim, ch, sw.COST[a])
            if len(t) < 6: continue
            ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t]); h1 = ts < split
            tot += 1; pos += g.sum() > 0; ok = (g[h1].sum() > 0) and (g[~h1].sum() > 0); amb += ok
            if ok: best.append((a, sn, rn, len(g), round(g.sum(), 2), round(g[h1].sum(), 2), round(g[~h1].sum(), 2)))
print('pruebas', tot, 'suma>0', pos, 'ambas mitades>0', amb)
for b in sorted(best, key=lambda x: -x[4])[:15]: print(b)
