# -*- coding: utf-8 -*-
"""Banco de pruebas: vender y recomprar DENTRO de una fase alcista de fondo.
Cada operación: señal al cierre t -> venta al cierre t+1; recompra decidida al cierre d -> ejecutada al cierre d+1.
Ganancia en unidades de la operación = ln(P_venta / P_recompra) - costes. Suma > 0 = más unidades que no hacer nada."""
import warnings; warnings.filterwarnings('ignore')
import numpy as np, pandas as pd, pickle, sys, time
from lib import *

COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
CHASE = {'BTC': 0.15, 'sp500': 0.05, 'nasdaq100': 0.06, 'oro': 0.05, 'plata': 0.08}
LIMS = {'BTC': 0.08, 'sp500': 0.03, 'nasdaq100': 0.04, 'oro': 0.03, 'plata': 0.05}
LIMB = {'BTC': 0.20, 'sp500': 0.07, 'nasdaq100': 0.10, 'oro': 0.07, 'plata': 0.12}


def onset(b, rearm=1):
    b = b.fillna(False).astype(bool)
    prev = b.shift(1).fillna(False)
    if rearm > 1:
        prev = b.shift(1).rolling(rearm, min_periods=1).max().fillna(0).astype(bool)
    return b & ~prev


def streak(cond):
    cond = cond.fillna(False).astype(int)
    g = (cond == 0).cumsum()
    return cond.groupby(g).cumsum()


def build(a, px=None, f3=None):
    p = px if px is not None else pd.read_parquet(f'{W}/px_{a}.parquet')
    f3 = f3 if f3 is not None else pd.read_parquet(f'{W}/feat3_{a}.parquet')
    f3 = f3.reindex(p.index)
    c, h, l, o, v = p.c, p.h, p.l, p.o, p.v
    bpy = BPY[a]
    F = pd.DataFrame(index=p.index); F['c'] = c
    for n in (10, 20, 50): F[f'e{n}'] = ema(c, n)
    for n in (5, 10, 20, 50, 100, 200): F[f's{n}'] = sma(c, n)
    F['rsi14'] = rsi(c, 14); F['rsi7'] = rsi(c, 7); F['rsi2'] = rsi(c, 2)
    c1 = c.shift(1)
    tr = pd.concat([h - l, (h - c1).abs(), (l - c1).abs()], axis=1).max(axis=1)
    F['atr20'] = tr.rolling(20, min_periods=20).mean()
    r = np.log(c).diff(); sd = r.ewm(span=bpy, min_periods=bpy // 2).std()
    for n in (20, 50, 200): F[f'z{n}'] = np.log(c / F[f's{n}']) / (sd * np.sqrt(n))
    F['kelt'] = (c - F['e20']) / F['atr20'].replace(0, np.nan)
    sd20 = c.rolling(20, min_periods=20).std(ddof=0)
    F['bbz'] = (c - F['s20']) / sd20.replace(0, np.nan)
    win = 3 * bpy
    for n in (20, 50, 200): F[f'd{n}p'] = pct_rolling(c / F[f's{n}'] - 1, win, bpy)
    for n in (5, 10, 20, 60): F[f'roc{n}p'] = pct_rolling(c / c.shift(n) - 1, win, bpy)
    F['up'] = streak(c > c1)
    F['hi20'] = c.rolling(20, min_periods=20).max(); F['lo20'] = c.rolling(20, min_periods=20).min()
    F['lo10'] = c.rolling(10, min_periods=10).min()
    F['hh20'] = h.rolling(20, min_periods=20).max(); F['hh252'] = h.rolling(bpy, min_periods=bpy // 2).max()
    F['hi252'] = c.rolling(bpy, min_periods=bpy // 2).max()
    rng = (h - l).replace(0, np.nan)
    F['clv'] = (c - l) / rng
    F['vr'] = v / v.rolling(50, min_periods=30).mean()
    F['o'] = o; F['h'] = h; F['l'] = l
    # semanal (evento el último día de la semana, ejecutable al cierre siguiente)
    w = to_weekly(p, a)
    wk = pd.DataFrame(index=w.index)
    wk['rsi14w'] = rsi(w.c, 14)
    wk['d10w'] = w.c / sma(w.c, 10) - 1; wk['d20w'] = w.c / sma(w.c, 20) - 1
    wk['wup'] = streak(w.c > w.c.shift(1))
    wr = (w.h - w.l).replace(0, np.nan)
    hh26 = w.h.rolling(26, min_periods=26).max()
    wk['w_rev'] = ((w.h >= hh26) & (w.c < w.o) & ((w.c - w.l) / wr < 0.3)).astype(float)
    wk['w_out'] = ((w.h >= hh26) & (w.h > w.h.shift(1)) & (w.c < w.l.shift(1))).astype(float)
    wk['w_x10'] = ((w.c < sma(w.c, 10)) & (w.c.shift(1) >= sma(w.c, 10).shift(1))).astype(float)
    wk['w_x20'] = ((w.c < sma(w.c, 20)) & (w.c.shift(1) >= sma(w.c, 20).shift(1))).astype(float)
    wk['d20wp'] = pct_rolling(wk['d20w'], 156, 52)
    # mapear cada semana a su último día con dato
    pos = p.index.searchsorted(w.index, side='right') - 1
    wk.index = p.index[pos]
    wk = wk[~wk.index.duplicated(keep='last')]
    for k in wk.columns:
        if k in ('w_rev', 'w_out', 'w_x10', 'w_x20'):
            F[k] = wk[k].reindex(F.index).fillna(0)
        else:
            F[k] = wk[k].reindex(F.index).ffill()
            F[k + '_e'] = wk[k].reindex(F.index)   # solo el día de cierre semanal
    ext_cols = [k for k in f3.columns if k.startswith(('div', 'fng', 'fund', 'mvrv', 'etf', 'exflow', 'oi_', 'cot_', 'tff_', 'delta', 'liq', 'vix', 'cmf', 'stable'))]
    for k in ext_cols: F[k] = f3[k]
    F['bull'] = (c > F['s200']) & (F['s200'] > F['s200'].shift(20))
    F['bear'] = (~F['bull']) & F['s200'].shift(20).notna()
    F['bull2'] = (F['s50'] > F['s200']) & (c > F['s200'])
    return F


def signals(a, F):
    S = {}
    c = F['c']
    def lev(name, s, ths, ge=True, rearm=1):
        for t in ths:
            S[f'{name}{">=" if ge else "<="}{t}'] = onset(s >= t if ge else s <= t, rearm)
    # --- sobrecompra / estiramiento ---
    lev('rsi14', F['rsi14'], (70, 75, 80, 85)); lev('rsi7', F['rsi7'], (85, 90)); lev('rsi2', F['rsi2'], (98, 99.5))
    for t in (70, 75, 80, 85):
        S[f'rsi14w>={t}'] = onset((F['rsi14w_e'] >= t).where(F['rsi14w_e'].notna()).ffill().fillna(False)) & F['rsi14w_e'].notna()
    lev('bbz', F['bbz'], (2, 2.5, 3)); lev('z20', F['z20'], (2, 2.5, 3)); lev('z50', F['z50'], (2, 2.5, 3, 3.5))
    lev('z200', F['z200'], (1.2, 1.5, 1.7, 2)); lev('kelt', F['kelt'], (2.5, 3, 4))
    lev('d20p', F['d20p'], (97, 99)); lev('d50p', F['d50p'], (97, 99)); lev('d200p', F['d200p'], (95, 99))
    lev('roc5p', F['roc5p'], (99,)); lev('roc10p', F['roc10p'], (99,)); lev('roc20p', F['roc20p'], (97, 99)); lev('roc60p', F['roc60p'], (97, 99))
    lev('up', F['up'], (6, 8))
    for t in (6, 8): S[f'wup>={t}'] = onset((F['wup_e'] >= t).where(F['wup_e'].notna()).ffill().fillna(False)) & F['wup_e'].notna()
    for t in (95, 99): S[f'd20wp>={t}'] = onset((F['d20wp_e'] >= t).where(F['d20wp_e'].notna()).ffill().fillna(False)) & F['d20wp_e'].notna()
    S['hi252_new'] = onset(c >= F['hi252'], 20)
    # --- agotamiento ---
    S['rev_d20'] = (F['h'] >= F['hh20']) & (c < F['o']) & (F['clv'] < 0.3)
    S['rev_d252'] = (F['h'] >= F['hh252']) & (c < F['o']) & (F['clv'] < 0.3)
    S['out_d20'] = (F['h'] >= F['hh20']) & (F['h'] > F['h'].shift(1)) & (c < F['l'].shift(1))
    S['climax_up'] = (F['vr'] >= 2.5) & (c >= F['hi20'])
    S['climax_rev'] = (F['vr'] >= 2.0) & (F['h'] >= F['hh20']) & (c < F['o'])
    S['w_rev'] = F['w_rev'] > 0; S['w_out'] = F['w_out'] > 0
    was80 = F['rsi14'].rolling(10, min_periods=1).max() >= 80
    was75 = F['rsi14'].rolling(10, min_periods=1).max() >= 75
    S['rsi_x70_de80'] = onset(F['rsi14'] < 70) & was80
    S['rsi_x70_de75'] = onset(F['rsi14'] < 70) & was75
    S['bb_reentra'] = onset(F['bbz'] < 2) & (F['bbz'].rolling(5, min_periods=1).max() >= 2.5)
    S['z50_gira'] = onset(F['z50'] < 2) & (F['z50'].rolling(10, min_periods=1).max() >= 2.5)
    # --- pérdida de impulso ---
    ab20 = streak(c > F['e20']); ab50 = streak(c > F['s50'])
    S['x_e20'] = (c < F['e20']) & (ab20.shift(1) >= 15)
    S['x_s50'] = (c < F['s50']) & (ab50.shift(1) >= 30)
    S['lo20'] = onset(c <= F['lo20']); S['lo10'] = onset(c <= F['lo10'])
    S['chand3'] = onset(c < c.rolling(22).max() - 3 * F['atr20'])
    S['w_x10'] = F['w_x10'] > 0; S['w_x20'] = F['w_x20'] > 0
    S['e10x20'] = onset(F['e10'] < F['e20']); S['e20x50'] = onset(F['e20'] < F['e50'])
    # --- divergencias ---
    for k in ('div_bear_rsi', 'div_bear_macd', 'div_bear_cmf', 'div_bear_delta', 'divw_bear_rsi', 'divw_bear_macd'):
        if k in F: S[k] = F[k].fillna(False).astype(bool)
    # --- externos ---
    if a == 'BTC':
        lev('fng', F['fng_crypto'], (75, 80, 90)); lev('fund7', F['fund_7d'], (30, 50, 80)); lev('fund30', F['fund_30d'], (30, 50))
        lev('mvrv', F['mvrv'], (2.5, 3, 3.5))
        lev('etf20p', pct_rolling(F['etf_20d'], 365, 120), (90,)); lev('exflowp', pct_rolling(F['exflow_30d'], 730, 365), (90,))
        lev('delta30p', F['delta30_p'], (90,)); lev('delta30p', F['delta30_p'], (10,), ge=False)
    else:
        if 'fng_cnn' in F: lev('fng', F['fng_cnn'], (75, 85))
        if a in ('sp500', 'nasdaq100'): lev('vix', F['vix'], (12, 11), ge=False)
    for k in (f'cot_idx_{a}', f'oi_pct3y_{a}'):
        if k in F: lev(k.split('_' + a)[0], F[k], (90, 97))
    if f'cot_idx_{a}' in F and a in ('sp500', 'nasdaq100'): lev('cot_idx', F[f'cot_idx_{a}'], (10,), ge=False)
    if 'liq' in F: S['liq_hostil'] = onset(F['liq'] <= 33)
    return {k: s.fillna(False).astype(bool) for k, s in S.items()}


def specs(a):
    """nombre -> (condición de recompra, tope de barras, límite por debajo, persecución por encima)"""
    R = {f'T{n}': (None, n, None, None) for n in (5, 10, 20, 40, 60)}
    R['e20_60'] = ('pb_e20', 60, None, None); R['e20_60c'] = ('pb_e20', 60, None, CHASE[a])
    R['s50_120'] = ('pb_s50', 120, None, None); R['s50_120c'] = ('pb_s50', 120, None, 2 * CHASE[a])
    R['rsi50_60'] = ('rsi50', 60, None, None); R['rsi40_60'] = ('rsi40', 60, None, None)
    R['limS_60'] = (None, 60, LIMS[a], None); R['limB_120'] = (None, 120, LIMB[a], None)
    R['limS_60c'] = (None, 60, LIMS[a], CHASE[a])
    R['r_e20_60'] = ('r_e20', 60, None, None); R['r_hi20_60'] = ('r_hi20', 60, None, None); R['r_s50_120'] = ('r_s50', 120, None, None)
    return R


def rebuy_conds(F):
    c = F['c']
    C = {'pb_e20': c <= F['e20'], 'pb_s50': c <= F['s50'], 'rsi50': F['rsi14'] <= 50, 'rsi40': F['rsi14'] <= 40,
         'r_e20': c > F['e20'], 'r_hi20': c >= F['hi20'], 'r_s50': c > F['s50']}
    return {k: np.flatnonzero(v.fillna(False).values) for k, v in C.items()}


def one(c, ts, rb, tmax, lim, chase, lag, n):
    dmax = min(ts + tmax, n - 1 - lag)
    if dmax <= ts: return -1
    d = dmax
    if rb is not None:
        j = np.searchsorted(rb, ts + 1)
        if j < len(rb) and rb[j] < d: d = rb[j]
    if lim is not None or chase is not None:
        seg = c[ts + 1:d + 1]; ps = c[ts]
        if lim is not None:
            w = np.flatnonzero(seg <= ps * (1 - lim))
            if len(w): d = min(d, ts + 1 + w[0])
        if chase is not None:
            w = np.flatnonzero(seg >= ps * (1 + chase))
            if len(w): d = min(d, ts + 1 + w[0])
    return d + lag


def run(c, sig_idx, rb, tmax, lim, chase, cost, lag=1):
    n = len(c); out = []; free = 0; k2 = 2 * np.log(1 - cost)
    for s in sig_idx:
        ts = s + lag
        if ts < free: continue
        if ts >= n - 1: break
        tr = one(c, ts, rb, tmax, lim, chase, lag, n)
        if tr < 0: break
        out.append((ts, tr, np.log(c[ts] / c[tr]) + k2)); free = tr
    return out


def baseline(c, days, rb, tmax, lim, chase, cost, lag=1, step=2):
    n = len(c); k2 = 2 * np.log(1 - cost); g = []
    for s in days[::step]:
        ts = s + lag
        if ts >= n - 1: break
        tr = one(c, ts, rb, tmax, lim, chase, lag, n)
        if tr < 0: break
        g.append(np.log(c[ts] / c[tr]) + k2)
    g = np.array(g)
    return (g.mean(), g.std()) if len(g) > 30 else (np.nan, np.nan)


def study(a, lag=1, save=True, F=None, tag=''):
    F = F if F is not None else build(a)
    S = signals(a, F); R = specs(a); RB = rebuy_conds(F)
    c = F['c'].values; idx = F.index; cost = COST[a]
    split = idx.searchsorted(pd.Timestamp(SPLIT[a]))
    regs = {'bull': F['bull'].values, 'todo': np.ones(len(c), bool), 'bear': F['bear'].values}
    conds = {'': np.ones(len(c), bool)}
    if 'liq' in F:
        conds['&liqH'] = (F['liq'] <= 33).fillna(False).values
        conds['&liqF'] = (F['liq'] >= 50).fillna(False).values
    rows = []; TR = {}
    base = {}
    for rg, m in regs.items():
        days = np.flatnonzero(m & F['s200'].notna().values)
        for rn, (cn, tmax, lim, chase) in R.items():
            base[(rg, rn)] = baseline(c, days, RB.get(cn), tmax, lim, chase, cost, lag)
    for sn, s in S.items():
        sv = s.values
        for cn_, cm in conds.items():
            for rg, m in regs.items():
                if cn_ and rg != 'bull': continue
                si = np.flatnonzero(sv & m & cm)
                if len(si) < 6: continue
                for rn, (cn, tmax, lim, chase) in R.items():
                    t = run(c, si, RB.get(cn), tmax, lim, chase, cost, lag)
                    if len(t) < 6: continue
                    ts = np.array([x[0] for x in t]); g = np.array([x[2] for x in t])
                    h1 = ts < split; bm, bs = base[(rg, rn)]
                    rows.append(dict(activo=a, reg=rg, senal=sn + cn_, rec=rn, n=len(g), gana=round((g > 0).mean(), 3),
                                     suma=g.sum(), s1=g[h1].sum(), s2=g[~h1].sum(), n1=int(h1.sum()), n2=int((~h1).sum()),
                                     media=g.mean(), med=np.median(g), base=bm, z=(g.mean() - bm) / (bs / np.sqrt(len(g))) if bs and bs > 0 else np.nan,
                                     dias=float(np.mean([x[1] - x[0] for x in t]))))
                    if rg == 'bull': TR[(sn + cn_, rn)] = (idx[ts].values, idx[[x[1] for x in t]].values, g)
    res = pd.DataFrame(rows)
    if save:
        res.to_csv(f'{W}/res_swing_{a}{tag}.csv', index=False)
        pickle.dump(TR, open(f'{W}/swing_tr_{a}{tag}.pkl', 'wb'))
    return res, TR, F


if __name__ == '__main__':
    for a in (sys.argv[1:] or ASSETS):
        t0 = time.time(); res, TR, F = study(a)
        b = res[res.reg == 'bull']
        print(a, 'pruebas', len(res), 'en alcista', len(b), '| suma>0:', round((b.suma > 0).mean(), 3), '| ambas mitades>0:', round(((b.s1 > 0) & (b.s2 > 0)).mean(), 3),
              '| dias alcistas %', round(100 * F['bull'].mean(), 1), '| seg', round(time.time() - t0, 1))
