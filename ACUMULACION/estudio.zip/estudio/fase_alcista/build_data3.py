# -*- coding: utf-8 -*-
"""Datos para el apartado 'dentro de la fase alcista' y el cambio oro<->plata del informe."""
import pandas as pd, numpy as np, json, math, warnings, sys; warnings.filterwarnings('ignore')
from lib import *
import swing_wf
sys.path.insert(0, f'{W}/tool'); import termometro as T
simple = lambda x: round(100 * (math.exp(x) - 1), 1)
out = {}
# ---- 1) banco de pruebas en fase alcista
sw = {}; tot_bull = 0; tot_all = 0
for a in ASSETS:
    r = pd.read_csv(f'res_swing_{a}.csv'); b = r[r.reg == 'bull']; tot_bull += len(b); tot_all += len(r)
    wf, _ = swing_wf.wf(a, K=(1, 5), crit='t')
    sw[a] = dict(reglas=int(len(b)), ganan=round(100 * (b.suma > 0).mean(), 1), ambas=(None if a == 'plata' else round(100 * ((b.s1 > 0) & (b.s2 > 0)).mean(), 1)),
                 media_op=simple(b.suma.sum() / b.n.sum()), azar=simple((b.base * b.n).sum() / b.n.sum()), ops=int(b.n.sum()),
                 wf5=round(math.exp(sum(x[1] for x in wf[5])), 2), wf1=round(math.exp(sum(x[1] for x in wf[1])), 2), wf_desde=int(wf[1][0][0]), dias_alcista=None)
    f = pd.read_parquet(f'{W}/feat3_{a}.parquet')
out['swing'] = sw
extra = 960 * 4 + 918 + 132 * 4 + 129 + 723 + 90 + 70 + 72 + 56
out['n_alcista'] = int(tot_bull); out['n_total'] = int(tot_all + extra)
# ---- 2) lado comprador (20 barras)
import swing as S
SP = dict(SPLIT); SP['plata'] = '2018-01-01'
buy = {}
for a in ASSETS:
    F = S.build(a); c = F['c']; idx = F.index; bull = F['bull']; f20 = 100 * (c.shift(-21) / c.shift(-1) - 1); h1 = pd.Series(idx < SP[a], index=idx)
    conds = {'base': bull, 'rsi70': bull & (F['rsi14'] >= 70), 'banda_inf': bull & (F['bbz'] <= -2), 'min20': bull & (c <= F['lo20'])}
    buy[a] = {k: [None if (m & h1).sum() < 20 else round(float(f20[m & h1].mean()), 1), None if (m & ~h1).sum() < 20 else round(float(f20[m & ~h1].mean()), 1), int((m & h1).sum()), int((m & ~h1).sum())] for k, m in conds.items()}
    buy[a]['corte'] = SP[a][:4]
out['compra_alcista'] = buy
# ---- 3) oro/plata
g = load_raw('oro', '1d')['c']; s_w = load_raw('plata', '1w')['c'].resample('W-FRI').last().dropna(); s_d = load_raw('plata', '1d')['c']
P = T.leer_precios()
gw = pd.concat([g, P['oro'][P['oro'].index > g.index[-1]]]).resample('W-FRI').last().dropna()
sd_ = pd.concat([s_d, P['plata'][P['plata'].index > s_d.index[-1]]]).resample('W-FRI').last().dropna()
sw_ = pd.concat([s_w[s_w.index < sd_.index[0]], sd_])
d = pd.concat([gw, sw_], axis=1, keys=['g', 's'], sort=True).dropna()
d = d[d.index <= P['oro'].index[-1]]
R = d.g / d.s; lr = np.log(R); mu = lr.rolling(260, min_periods=130).mean(); sdv = lr.rolling(260, min_periods=130).std(); z = (lr - mu) / sdv
rg = d.g.pct_change().fillna(0); rs = d.s.pct_change().fillna(0); COST = 0.00125
def estado(zin, modo):
    st = pd.Series(np.nan, index=d.index)
    if modo == 'plata': st[z < -zin] = 1.0; st[z >= 0] = 0.0; base = 0.0
    else: st[z > zin] = 0.0; st[z <= 0] = 1.0; base = 1.0
    return st.ffill().fillna(base).shift(1).fillna(base), base       # peso en oro, ejecutado al cierre de la semana siguiente
def curva(w, base, modo):
    turn = (w - w.shift(1)).abs().fillna(0); port = w.shift(1).fillna(base) * rg + (1 - w.shift(1).fillna(base)) * rs
    lv = np.log1p(port - turn * 2 * COST).cumsum(); bench = np.log((1 + (rs if modo == 'plata' else rg)).cumprod())
    return lv - bench
def ops(modo, zin=1.5):
    w, base = estado(zin, modo); ch = w[(w != w.shift(1)) & w.shift(1).notna()]; res = []; t0 = None
    def fila(t0, t1, abierta):
        seg = R[t0:t1]; sign = 1 if modo == 'plata' else -1
        gl = sign * np.log(R[t1] / R[t0]) + (2 if abierta else 4) * np.log(1 - COST)
        peor = sign * np.log((seg.min() if modo == 'plata' else seg.max()) / R[t0])
        return dict(ini=str(t0.date()), r0=round(float(R[t0]), 1), fin=(None if abierta else str(t1.date())), r1=round(float(R[t1]), 1), meses=int(round((t1 - t0).days / 30.4)), res=simple(gl), peor=simple(peor))
    for dt, v in ch.items():
        if v != base: t0 = dt
        elif t0 is not None: res.append(fila(t0, dt, False)); t0 = None
    if t0 is not None: res.append(fila(t0, R.index[-1], True))
    return res
gs = {'ops_plata': ops('plata'), 'ops_oro': ops('oro')}
cuts = ['1990-01-01', '2000-01-01', '2010-01-01', '2020-01-01']
for modo in ('plata', 'oro'):
    w = (estado(1.5, modo)[0] + estado(2.0, modo)[0]) / 2; base = estado(1.5, modo)[1]; x = curva(w, base, modo)
    seg = [x[:cuts[0]].iloc[-1]] + [x[:cuts[i + 1]].iloc[-1] - x[:cuts[i]].iloc[-1] for i in range(3)] + [x.iloc[-1] - x[:cuts[3]].iloc[-1]]
    gs[f'tramos_{modo}'] = dict(total=round(math.exp(x.iloc[-1]), 2), periodos=[round(math.exp(v), 2) for v in seg], peor=simple((x - x.cummax()).min()), tiempo=round(100 * float((w != base).mean())),
                                desde={y: round(math.exp(x.iloc[-1] - x[:f'{y}-01-01'].iloc[-1]), 2) for y in (1985, 2000, 2010)})
gr = pd.read_csv('res_gsr.csv')
for modo in ('plata', 'oro'):
    x = gr[gr.modo == modo]; gs[f'vecinos_{modo}'] = dict(n=int(len(x)), pos=int((x.total > 0).sum()), mediana=round(math.exp(x.total.median()), 2), minimo=round(math.exp(x.total.min()), 2), maximo=round(math.exp(x.total.max()), 2))
ii = np.flatnonzero(d.index >= '1977-07-01'); ii = sorted(set(ii[::2].tolist() + [int(ii[-1])]))
gs['serie'] = dict(t=[str(x.date()) for x in d.index[ii]], r=[round(float(v), 1) for v in R.iloc[ii]], m=[round(float(v), 1) for v in np.exp(mu.iloc[ii])],
                   lo=[round(float(v), 1) for v in np.exp(mu - 1.5 * sdv).iloc[ii]], hi=[round(float(v), 1) for v in np.exp(mu + 1.5 * sdv).iloc[ii]])
gs['hoy'] = json.load(open(f'{W}/tool/lectura_actual.json'))['metales']
out['gsr'] = gs
json.dump(out, open('report_data3.json', 'w'), ensure_ascii=False)
print(json.dumps({k: out[k] for k in ('swing', 'n_alcista', 'n_total', 'compra_alcista')}, ensure_ascii=False))
print(json.dumps({k: v for k, v in gs.items() if k != 'serie'}, ensure_ascii=False))
print(len(gs['serie']['t']), 'z último', round(float(z.iloc[-1]), 2), d.index[-1].date())
# --- detalles del cambio abierto y del mínimo del ratio
w2 = estado(2.0, 'plata')[0]; ch2 = w2[(w2 != w2.shift(1)) & w2.shift(1).notna()]
t2 = ch2.index[-1]; t1 = pd.Timestamp(gs['ops_plata'][-1]['ini'])
rmin = R['2025-12-01':].min(); tmin = R['2025-12-01':].idxmin(); prev = R[:'2025-11-30'][R[:'2025-11-30'] <= rmin]
gs['abierta'] = dict(t1=str(t1.date()), r1=round(float(R[t1]), 1), t2=str(t2.date()), r2=round(float(R[t2]), 1), res1=simple(np.log(R.iloc[-1] / R[t1])), res2=simple(np.log(R.iloc[-1] / R[t2])),
                     rmin=round(float(rmin), 1), tmin=str(tmin.date()), antes=(str(prev.index[-1].date()) if len(prev) else None), peor1=simple(np.log(rmin / R[t1])), peor2=simple(np.log(rmin / R[t2])))
x = curva((estado(1.5, 'plata')[0] + estado(2.0, 'plata')[0]) / 2, 0.0, 'plata')
gs['abierta']['res_tramos'] = simple(x.iloc[-1] - x[:t1 - pd.Timedelta(days=7)].iloc[-1])
json.dump(out, open('report_data3.json', 'w'), ensure_ascii=False)
print(gs['abierta'], 'duraciones', sorted(o['meses'] for o in gs['ops_plata'][:-1]))
