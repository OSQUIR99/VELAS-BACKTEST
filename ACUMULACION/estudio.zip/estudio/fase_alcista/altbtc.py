import pandas as pd, numpy as np, itertools, warnings; warnings.filterwarnings('ignore')
pd.set_option('display.width', 250)
from lib import *
def ld(sym):
    df = pd.read_parquet(f'{BASE}/CRIPTO/{sym}/1d.parquet'); df['date'] = (df['fecha'] + pd.Timedelta(hours=4)).dt.floor('D')
    s = df.set_index('date')['cierre'].astype(float); return s[~s.index.duplicated(keep='last')].sort_index()
btc = ld('BTC'); cost = 0.0015; rows = []
for alt in ('ETH', 'SOL', 'BNB', 'XRP', 'LTC', 'ADA', 'LINK'):
    d = pd.concat([btc, ld(alt)], axis=1, keys=['b', 'a'], sort=True).dropna(); lr = np.log(d.a / d.b)   # alt en BTC
    rb = d.b.pct_change().fillna(0); ra = d.a.pct_change().fillna(0); mid = d.index[len(d) // 2]
    def ev(inalt):   # inalt: objetivo decidido al cierre t
        w = inalt.shift(1).fillna(0.0); we = w.shift(1).fillna(0.0)
        port = we * ra + (1 - we) * rb; turn = (we - we.shift(1)).abs().fillna(0)
        x = np.log1p(port - turn * 2 * cost).cumsum() - np.log((1 + rb).cumprod())
        return x.iloc[-1], x[mid], x.iloc[-1] - x[mid], turn.sum()
    for n in (20, 50, 100, 200):
        t, h1, h2, k = ev((lr > lr.rolling(n).mean()).astype(float)); rows.append(dict(alt=alt, regla=f'impulso {n}d', total=t, h1=h1, h2=h2, cambios=k))
    for win, zt in itertools.product((365, 730), (1.5, 2.0)):
        z = (lr - lr.rolling(win, min_periods=win // 2).mean()) / lr.rolling(win, min_periods=win // 2).std()
        st = pd.Series(np.nan, index=d.index); st[z < -zt] = 1.0; st[z >= 0] = 0.0
        t, h1, h2, k = ev(st.ffill().fillna(0.0)); rows.append(dict(alt=alt, regla=f'barata z{zt} ({win}d)', total=t, h1=h1, h2=h2, cambios=k))
r = pd.DataFrame(rows)
print(r.pivot_table(index='regla', columns='alt', values='total').round(2).to_string())
print('ambas mitades >0:', r[(r.h1 > 0) & (r.h2 > 0)].groupby('regla').size().to_dict(), 'de 7 monedas')
print(r.groupby('regla')[['h1', 'h2']].median().round(2).T.to_string())
