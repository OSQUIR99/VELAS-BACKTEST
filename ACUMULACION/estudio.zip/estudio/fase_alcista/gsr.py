"""Ratio oro/plata con velas semanales desde 1975: cambiar entre metales cuando uno está caro frente al otro."""
import pandas as pd, numpy as np, itertools, warnings; warnings.filterwarnings('ignore')
pd.set_option('display.width', 250)
from lib import *
g = load_raw('oro', '1w')['c']; s = load_raw('plata', '1w')['c']
gd = load_raw('oro', '1d')['c']
print('oro 1w', g.index[0].date(), g.index[-1].date(), len(g), '| plata 1w', s.index[0].date(), s.index[-1].date(), len(s), '| oro 1d', gd.index[0].date())
gw = pd.concat([g, gd.resample('W-FRI').last()]).sort_index(); 
g = g.resample('W-FRI').last().dropna(); s = s.resample('W-FRI').last().dropna()
d = pd.concat([g, s], axis=1, keys=['g', 's'], sort=True).dropna()
print('común', d.index[0].date(), '->', d.index[-1].date(), len(d), 'semanas; ratio min/mediana/max', (d.g / d.s).min().round(1), (d.g / d.s).median().round(1), (d.g / d.s).max().round(1))
rg = d.g.pct_change().fillna(0); rs = d.s.pct_change().fillna(0); lr = np.log(d.g / d.s)
COST = 0.00125
def run(win, zin, zout, mode, lag=1):
    """mode 'ambos': 50/50 de base, todo al barato en extremos. 'plata': tengo plata; paso a oro si plata cara (z<-zin) y vuelvo en z>=-zout.
    'oro': tengo oro; paso a plata si plata barata (z>zin), vuelvo en z<=zout. Devuelve log-ventaja sobre no tocar."""
    z = (lr - lr.rolling(win, min_periods=win // 2).mean()) / lr.rolling(win, min_periods=win // 2).std()
    st = pd.Series(np.nan, index=d.index)
    if mode == 'ambos':
        st[z > zin] = 0.0; st[z < -zin] = 1.0; st[z.abs() <= zout] = 0.5; base = 0.5
    elif mode == 'plata':
        st[z < -zin] = 1.0; st[z >= -zout] = 0.0; base = 0.0
    else:
        st[z > zin] = 0.0; st[z <= zout] = 1.0; base = 1.0
    wg = st.ffill().fillna(base)
    w = wg.shift(lag).fillna(base)           # ejecutado al cierre de la semana siguiente
    turn = (w - w.shift(1)).abs().fillna(0)
    port = w.shift(1).fillna(base) * rg + (1 - w.shift(1).fillna(base)) * rs
    lv = np.log1p(port - turn * 2 * COST).cumsum()
    if mode == 'ambos': bench = np.log(0.5 * (1 + rg).cumprod() + 0.5 * (1 + rs).cumprod())
    elif mode == 'plata': bench = np.log((1 + rs).cumprod())
    else: bench = np.log((1 + rg).cumprod())
    return lv - bench, turn, w, z
rows = []
cuts = ['1990-01-01', '2000-01-01', '2010-01-01', '2020-01-01']
for mode, win, zin, zout in itertools.product(('ambos', 'plata', 'oro'), (104, 156, 260, 520), (1.0, 1.5, 2.0), (0.0, 0.5)):
    if zout >= zin: continue
    x, turn, w, z = run(win, zin, zout, mode)
    seg = [x[:cuts[0]].iloc[-1]] + [x[:cuts[i + 1]].iloc[-1] - x[:cuts[i]].iloc[-1] for i in range(3)] + [x.iloc[-1] - x[:cuts[3]].iloc[-1]]
    rows.append(dict(modo=mode, win=win, zin=zin, zout=zout, total=x.iloc[-1], **{f'p{i}': v for i, v in enumerate(seg)}, cambios=int((turn > 0).sum())))
r = pd.DataFrame(rows)
r.to_csv('res_gsr.csv', index=False)
for mode, x in r.groupby('modo'):
    seg = x[[f'p{i}' for i in range(5)]]
    print(f'\n{mode}: variantes {len(x)}; total>0 {100*(x.total>0).mean():.0f}%; mediana total {x.total.median():+.2f}; periodos positivos por variante (de 5): mediana {int((seg>0).sum(axis=1).median())}; por periodo, % variantes >0:', (100 * (seg > 0).mean()).round(0).tolist(), 'medianas', seg.median().round(2).tolist())
    print(x.sort_values('total', ascending=False).head(4).round(2).to_string(index=False)); print(x.sort_values('total').head(3).round(2).to_string(index=False))
