# -*- coding: utf-8 -*-
"""Añade a los indicadores: divergencias (diarias y semanales), delta de volumen (real en BTC, aproximado en el resto),
extensión en volatilidades (z200), semáforos de liquidez y de miedo. Todo causal."""
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *
from ext import dec

def divergences(price, osc, k, L, minsep, kind, level=None, eps=0.0):
    """Divergencia confirmada: devuelve serie booleana, True en la barra en que queda CONFIRMADA (k barras después del pivote).
    kind='bear': precio hace máximo más alto y el oscilador uno más bajo (primer pico del oscilador >= level).
    kind='bull': precio hace mínimo más bajo y el oscilador uno más alto (primer valle <= level)."""
    p = price.values; o = osc.values; n = len(p); out = np.zeros(n, bool)
    if kind == 'bear':
        piv = (price == price.rolling(2 * k + 1, center=True, min_periods=2 * k + 1).max()).values
    else:
        piv = (price == price.rolling(2 * k + 1, center=True, min_periods=2 * k + 1).min()).values
    idxs = np.where(piv)[0]
    for j in range(1, len(idxs)):
        i2 = idxs[j]
        if i2 + k >= n or np.isnan(o[i2]): continue
        for jj in range(j - 1, -1, -1):
            i1 = idxs[jj]
            if i2 - i1 > L: break
            if i2 - i1 < minsep or np.isnan(o[i1]): continue
            if kind == 'bear':
                if p[i2] > p[i1] * (1 + eps) and o[i2] < o[i1] and (level is None or o[i1] >= level): out[i2 + k] = True
            else:
                if p[i2] < p[i1] * (1 - eps) and o[i2] > o[i1] and (level is None or o[i1] <= level): out[i2 + k] = True
            break
    return pd.Series(out, index=price.index)

E = pd.read_parquet(f'{W}/ext_daily.parquet')
E['stable_13w'] = E['stable_13w'].replace([np.inf, -np.inf], np.nan)
for a in ASSETS:
    f = pd.read_parquet(f'{W}/feat2_{a}.parquet'); df = pd.read_parquet(f'{W}/px_{a}.parquet')
    c, h, l, v = df['c'], df['h'], df['l'], df['v']; bpy = BPY[a]
    # extensión en volatilidades
    r = np.log(c).diff(); sd = r.ewm(span=bpy, min_periods=bpy // 2).std()
    f['z200'] = np.log(c / sma(c, 200)) / (sd * np.sqrt(200))
    f['z50'] = np.log(c / sma(c, 50)) / (sd * np.sqrt(50))
    # --- delta de volumen aproximado (posición del cierre en el rango x volumen) ---
    rng = (h - l).replace(0, np.nan)
    clv = (((c - l) - (h - c)) / rng).fillna(0)
    dp = clv * v
    f['cmf20'] = dp.rolling(20, min_periods=15).sum() / v.rolling(20, min_periods=15).sum()
    f['cmf60'] = dp.rolling(60, min_periods=45).sum() / v.rolling(60, min_periods=45).sum()
    obv = (np.sign(r).fillna(0) * v).fillna(0).cumsum().where(v.notna())
    f['obv_20'] = (obv - obv.shift(20)) / v.rolling(20).sum()
    if a == 'BTC':
        tk, _ = dec('btc_taker'); tb = (tk[0] / 1000).reindex(f.index)
        dl = (2 * tb - 1) * v
        f['delta7'] = dl.rolling(7, min_periods=5).sum() / v.rolling(7, min_periods=5).sum()
        f['delta30'] = dl.rolling(30, min_periods=20).sum() / v.rolling(30, min_periods=20).sum()
        f['delta90'] = dl.rolling(90, min_periods=60).sum() / v.rolling(90, min_periods=60).sum()
        f['delta30_p'] = pct_rolling(f['delta30'], 730, 365)
        f['cvd'] = dl.fillna(0).cumsum().where(tb.notna())
        f['cvd_30'] = (f['cvd'] - f['cvd'].shift(30)) / v.rolling(30).sum()
        deltaosc = f['delta30']
    else:
        deltaosc = f['cmf20']
    # --- divergencias diarias ---
    k, L, ms = 5, 60, 8
    f['div_bear_rsi'] = divergences(c, f['rsi14'], k, L, ms, 'bear', level=65)
    f['div_bull_rsi'] = divergences(c, f['rsi14'], k, L, ms, 'bull', level=35)
    f['div_bear_macd'] = divergences(c, f['macdh'], k, L, ms, 'bear', level=0)
    f['div_bull_macd'] = divergences(c, f['macdh'], k, L, ms, 'bull', level=0)
    f['div_bear_delta'] = divergences(c, deltaosc, k, L, ms, 'bear')
    f['div_bull_delta'] = divergences(c, deltaosc, k, L, ms, 'bull')
    f['div_bear_cmf'] = divergences(c, f['cmf20'], k, L, ms, 'bear')
    f['div_bull_cmf'] = divergences(c, f['cmf20'], k, L, ms, 'bull')
    # --- divergencias semanales ---
    w = to_weekly(df, a); wc = w['c']
    wr = rsi(wc, 14); wm = macd_hist(wc)
    for nm, osc, lvb, lvl in (('rsi', wr, 65, 40), ('macd', wm, 0, 0)):
        f[f'divw_bear_{nm}'] = lag_to_daily(divergences(wc, osc, 2, 40, 4, 'bear', level=lvb).astype(float), f.index).fillna(0).astype(bool)
        f[f'divw_bull_{nm}'] = lag_to_daily(divergences(wc, osc, 2, 40, 4, 'bull', level=lvl).astype(float), f.index).fillna(0).astype(bool)
    # --- semáforos de liquidez (verde = 1) ---
    X = E.reindex(f.index)
    lights = pd.DataFrame(index=f.index)
    lights['dolar'] = (X['dxy_13w'] < 0).where(X['dxy_13w'].notna())
    lights['condfin'] = (X['nfci_13w'] < 0).where(X['nfci_13w'].notna())
    lights['tipos'] = (X['t10_13w'] < 0).where(X['t10_13w'].notna())
    lights['credito'] = (X['baa_13w'] < 0).where(X['baa_13w'].notna())
    lights['bancos_c'] = (X['gcb_13w'] > 0).where(X['gcb_13w'].notna())
    lights['liq_neta'] = (X['netliq_13w'] > 0).where(X['netliq_13w'].notna())
    if a == 'BTC': lights['estables'] = (X['stable_13w'] > 2).where(X['stable_13w'].notna())
    lights = lights.astype(float)
    f['liq'] = 100 * lights.mean(axis=1, skipna=True)
    f['liq3'] = 100 * lights[['dolar', 'condfin', 'tipos']].mean(axis=1, skipna=True)   # los tres con historia desde 1971
    f['liq_n'] = lights.notna().sum(axis=1)
    for col in lights: f['L_' + col] = lights[col]
    for col in ('dxy_13w', 'nfci_13w', 't10_13w', 'baa_13w', 'gcb_13w', 'netliq_13w', 'stable_13w', 'ry10_13w', 'vix', 'fng_cnn', 'fng_crypto', 'mvrv', 'fund_7d', 'fund_30d', 'etf_20d'):
        if col in X and col not in f: f[col] = X[col]
    f.to_parquet(f'{W}/feat3_{a}.parquet')
    dv = [x for x in f.columns if x.startswith('div')]
    print(a, 'nº divergencias:', {x: int(f[x].sum()) for x in dv})
    print('   liq hoy', round(f['liq'].iloc[-1]), 'luces', {col: f['L_' + col].iloc[-1] for col in lights}, '| cmf20', round(f['cmf20'].iloc[-1], 3), '| z200', round(f['z200'].iloc[-1], 2))
