import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from strat import sim, perf, COST; from ext import fred, lagged
idx = pd.date_range('1947-01-01', '2026-10-02', freq='D')
ur = fred('UNRATE'); rec_ur = (ur > ur.rolling(12).mean()).astype(float)
ur_flag = lagged(rec_ur, 38, idx)                      # paro por encima de su media de 12 meses (publicado ~día 5-8 del mes siguiente)
sahm = lagged((fred('SAHMREALTIME') >= 0.5).astype(float), 38, idx)
ic = fred('ICSA'); ic4 = ic.rolling(4).mean(); ic_flag = lagged((ic4 > ic4.rolling(52).min() * 1.2).astype(float), 6, idx)   # peticiones de paro +20% sobre su mínimo de 52 semanas
baa = fred('BAA10Y'); baa_flag = lagged((baa > baa.rolling(252).mean() + 0.3).astype(float), 1, idx)
curve = fred('T10Y3M'); inv = lagged((curve.rolling(378).min() < 0).astype(float), 1, idx)   # curva invertida en algún momento de los últimos 18 meses
ip = fred('INDPRO'); ip_flag = lagged((ip < ip.shift(6)).astype(float), 48, idx)
FLAGS = {'paro>media12m': ur_flag, 'Sahm>=0.5': sahm, 'peticiones paro +20%': ic_flag, 'crédito BAA +0.3 s/media': baa_flag, 'prod. industrial 6m<0': ip_flag}
rows = []
for a in ('sp500', 'nasdaq100', 'BTC', 'oro', 'plata'):
    df = pd.read_parquet(f'{W}/px_{a}.parquet'); c = df['c']
    m = to_monthly(df)['c']; t10 = lag_to_daily((m > sma(m, 10)).astype(float).where(sma(m, 10).notna(), 1.0), c.index).fillna(1.0)
    s200 = sma(c, 200); t200 = (c > s200).astype(float).where(s200.notna(), 1.0)
    sp = pd.Timestamp(SPLIT[a]); start = max(c.index[0] + pd.Timedelta(days=400), pd.Timestamp('1949-01-01'))
    for fn, fl in FLAGS.items():
        flg = fl.reindex(c.index).ffill()
        for tn, tr in (('10m', t10), ('sma200', t200)):
            w = (~((flg == 1) & (tr == 0))).astype(float)
            w[flg.isna()] = 1.0
            st = max(start, flg.first_valid_index())
            d = perf(c, w, a, st, sp) if sp > st + pd.Timedelta(days=1500) else None
            v = perf(c, w, a, max(sp, st), None)
            rows.append({'activo': a, 'regla': f'{fn} Y bajo {tn}', 'D': d['mult'] if d else np.nan, 'Dops': d['ops'] if d else np.nan, 'V': v['mult'], 'Vpeor': v['peor'], 'Vops': v['ops'], 'Vfuera%': v['fuera%']})
T = pd.DataFrame(rows); pd.set_option('display.width', 250)
for a in ('sp500', 'nasdaq100', 'BTC', 'oro', 'plata'):
    print('\n', a); print(T[T.activo == a].drop(columns='activo').round(2).to_string(index=False))
