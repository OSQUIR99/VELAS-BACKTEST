import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from strat import COST; from parab import zext, run
def report(name, c, z, s_ma, cost, thr, bpy, pulls):
    print(f"\n== {name}: vender al superar z>={thr}; recomprar al volver a la media larga (tope 2 años) | z hoy {z.iloc[-1]:.2f} ==")
    T = run(c, z >= thr, cost, back=(c <= s_ma), timeout=2 * bpy)
    for r in T.itertuples():
        seg = c[r.venta:r.recompra]
        print(f"  {r.venta.date()} vende {r.p_venta:>9.2f} | subió después hasta {100*(seg.max()/r.p_venta-1):+5.0f}% | recompra {r.recompra.date()} {r.p_recompra:>9.2f} ({r.motivo}) | unidades x{r.unid:.2f} | {r.dias} d")
    if len(T): print(f"  total x{np.prod(T.unid):.2f}  aciertos {int((T.unid>1).sum())}/{len(T)}")
    for pull in pulls:
        T2 = run(c, z >= thr, cost, pull=pull, timeout=bpy)
        if len(T2): print(f"  variante límite -{pull:.0%} (tope 1 año): x{np.prod(T2.unid):.2f} aciertos {int((T2.unid>1).sum())}/{len(T2)} peor {100*(T2.unid.min()-1):+.0f}%")
for a, pulls in (('BTC', (0.25,)), ('nasdaq100', (0.10,)), ('sp500', (0.07,)), ('oro', (0.08,))):
    df = pd.read_parquet(f'{W}/px_{a}.parquet'); c = df['c']; bpy = BPY[a]
    report(a, c, zext(c, 200, bpy=bpy), sma(c, 200), COST[a], 1.7, bpy, pulls)
# plata semanal desde 1970
w = load_raw('plata', '1w')['c']
r = np.log(w).diff(); sd = r.ewm(span=52, min_periods=26).std(); zw = np.log(w / sma(w, 40)) / (sd * np.sqrt(40))
report('plata (semanal desde 1970)', w, zw, sma(w, 40), COST['plata'], 1.7, 52, (0.15,))
g = load_raw('oro', '1w')['c']
r = np.log(g).diff(); sd = r.ewm(span=52, min_periods=26).std(); zg = np.log(g / sma(g, 40)) / (sd * np.sqrt(40))
report('oro (semanal desde 1975, comprobación)', g, zg, sma(g, 40), COST['oro'], 1.7, 52, (0.08,))
