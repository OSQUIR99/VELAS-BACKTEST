# -*- coding: utf-8 -*-
"""Librería común: carga de velas e indicadores (todo causal: en el día t solo se usan datos hasta t)."""
import pandas as pd, numpy as np, os, json

BASE = '/mnt/user-data/uploads/VELAS PARA BACKTEST'
W = '/home/claude/work'
ASSETS = ['BTC', 'sp500', 'nasdaq100', 'oro', 'plata']
# barras por año y horizontes (en barras) por activo
BPY = {'BTC': 365, 'sp500': 252, 'nasdaq100': 252, 'oro': 252, 'plata': 252}
SPLIT = {'BTC': '2020-01-01', 'sp500': '2000-01-01', 'nasdaq100': '2006-01-01', 'oro': '2006-01-01', 'plata': '2006-01-01'}


def load_raw(asset, tf='1d'):
    grp = 'CRIPTO' if asset in ('BTC', 'ETH') else 'TRADICIONAL'
    df = pd.read_parquet(f'{BASE}/{grp}/{asset}/{tf}.parquet')
    df['date'] = (df['fecha'] + pd.Timedelta(hours=4)).dt.floor('D')
    df = df.rename(columns={'apertura': 'o', 'maximo': 'h', 'minimo': 'l', 'cierre': 'c', 'volumen': 'v'})
    df = df.set_index('date')[['o', 'h', 'l', 'c', 'v']].astype(float)
    return df[~df.index.duplicated(keep='last')].sort_index()


def load_daily(asset):
    df = load_raw(asset, '1d')
    if asset == 'BTC':
        cm = pd.read_csv(f'{W}/data/btc_coinmetrics.csv', usecols=['time', 'PriceUSD'], parse_dates=['time']).set_index('time')
        pre = cm['PriceUSD'].dropna()
        pre = pre[pre.index < df.index[0]]
        pre = pd.DataFrame({'o': pre, 'h': pre, 'l': pre, 'c': pre, 'v': np.nan})
        df = pd.concat([pre, df]).sort_index()
        df = df[df.index >= '2010-10-01']  # antes el precio era de céntimos y sin mercado real
    if asset == 'sp500':
        # los primeros años son mensuales: quedarse con el tramo diario
        gap = df.index.to_series().diff().dt.days
        first_daily = gap[(gap.rolling(250).max() <= 6)].index[0] - pd.Timedelta(days=370)
        df = df[df.index >= max(first_daily, pd.Timestamp('1928-01-01'))]
    df.loc[df['v'] <= 0, 'v'] = np.nan
    return df


# ---------- indicadores básicos ----------
def sma(s, n):
    return s.rolling(n, min_periods=n).mean()


def ema(s, n):
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


def rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def bbp(c, n=20, k=2.0):
    m = sma(c, n); sd = c.rolling(n, min_periods=n).std(ddof=0)
    up, lo = m + k * sd, m - k * sd
    return (c - lo) / (up - lo), (up - lo) / m


def stoch(h, l, c, n=14, smooth=3):
    hh = h.rolling(n, min_periods=n).max(); ll = l.rolling(n, min_periods=n).min()
    return (100 * (c - ll) / (hh - ll).replace(0, np.nan)).rolling(smooth).mean()


def macd_hist(c, a=12, b=26, s=9):
    m = ema(c, a) - ema(c, b)
    return (m - m.ewm(span=s, adjust=False, min_periods=s).mean()) / c


def pct_expanding(s, minp=750):
    return s.expanding(min_periods=minp).rank(pct=True) * 100


def pct_rolling(s, win, minp=None):
    return s.rolling(win, min_periods=minp or win // 3).rank(pct=True) * 100


def to_weekly(df, asset):
    rule = 'W-SUN' if asset == 'BTC' else 'W-FRI'
    w = df.resample(rule).agg({'o': 'first', 'h': 'max', 'l': 'min', 'c': 'last', 'v': 'sum'}).dropna(subset=['c'])
    return w


def to_monthly(df):
    return df.resample('ME').agg({'o': 'first', 'h': 'max', 'l': 'min', 'c': 'last', 'v': 'sum'}).dropna(subset=['c'])


def lag_to_daily(wser, daily_index):
    """Valor de la última barra semanal/mensual COMPLETA, conocido a partir del día siguiente a su cierre."""
    s = wser.copy()
    s.index = s.index + pd.Timedelta(days=1)  # disponible al día siguiente del cierre de la barra
    return s.reindex(daily_index.union(s.index)).ffill().reindex(daily_index)


def build_features(asset):
    df = load_daily(asset)
    c, h, l, v = df['c'], df['h'], df['l'], df['v']
    bpy = BPY[asset]
    f = pd.DataFrame(index=df.index)
    f['c'] = c; f['v'] = v
    # osciladores diarios
    f['rsi14'] = rsi(c, 14)
    f['bbp20'], f['bbw20'] = bbp(c, 20, 2)
    f['stoch14'] = stoch(h, l, c, 14, 3)
    f['macdh'] = macd_hist(c)
    # medias diarias y distancia
    for n in (50, 100, 200):
        f[f'd_sma{n}'] = c / sma(c, n) - 1
        f[f'd_ema{n}'] = c / ema(c, n) - 1
    f['sma200_slope'] = sma(c, 200) / sma(c, 200).shift(20) - 1
    f['gc'] = (sma(c, 50) > sma(c, 200)).astype(float).where(sma(c, 200).notna())
    # semanales (barra completa, conocida al día siguiente)
    w = to_weekly(df, asset); wc = w['c']
    f['rsi14w'] = lag_to_daily(rsi(wc, 14), f.index)
    bw, _ = bbp(wc, 20, 2); f['bbp20w'] = lag_to_daily(bw, f.index)
    f['stoch14w'] = lag_to_daily(stoch(w['h'], w['l'], wc, 14, 3), f.index)
    f['macdhw'] = lag_to_daily(macd_hist(wc), f.index)
    for n in (20, 50, 100, 200):
        f[f'd_sma{n}w'] = c / lag_to_daily(sma(wc, n), f.index) - 1
        f[f'd_ema{n}w'] = c / lag_to_daily(ema(wc, n), f.index) - 1
    # mensuales
    m = to_monthly(df)
    f['rsi14m'] = lag_to_daily(rsi(m['c'], 14), f.index)
    f['d_sma10m'] = c / lag_to_daily(sma(m['c'], 10), f.index) - 1
    # rangos / máximos
    f['dd_ath'] = c / c.cummax() - 1
    hi52 = c.rolling(bpy, min_periods=bpy // 2).max(); lo52 = c.rolling(bpy, min_periods=bpy // 2).min()
    f['dd_52w'] = c / hi52 - 1
    f['up_52w'] = c / lo52 - 1
    f['pos52w'] = (c - lo52) / (hi52 - lo52).replace(0, np.nan)
    for nm, n in (('1m', bpy // 12), ('3m', bpy // 4), ('6m', bpy // 2), ('12m', bpy)):
        f[f'roc_{nm}'] = c / c.shift(n) - 1
    # volatilidad
    r = np.log(c).diff()
    f['rv20'] = r.rolling(20).std() * np.sqrt(bpy)
    f['rv60'] = r.rolling(60).std() * np.sqrt(bpy)
    f['ret1'] = c.pct_change()
    # volumen
    f['vr50'] = v / sma(v, 50)
    f['vr20_250'] = sma(v, 20) / sma(v, 250)
    upv = (v * (r > 0)).rolling(20).sum(); dnv = (v * (r < 0)).rolling(20).sum()
    f['upvol20'] = upv / (upv + dnv)
    # resultados futuros (solo para evaluar, nunca como entrada)
    for nm, n in (('1m', bpy // 12), ('3m', bpy // 4), ('6m', bpy // 2), ('12m', bpy)):
        f[f'fr_{nm}'] = c.shift(-n) / c - 1
        fut_min = c[::-1].rolling(n, min_periods=n).min()[::-1].shift(-1)
        fut_max = c[::-1].rolling(n, min_periods=n).max()[::-1].shift(-1)
        f[f'fmin_{nm}'] = fut_min / c - 1
        f[f'fmax_{nm}'] = fut_max / c - 1
    return df, f
