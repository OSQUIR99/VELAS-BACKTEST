import warnings; warnings.filterwarnings('ignore')
import sys; sys.path.insert(0, '/home/claude/work/tool')
import pandas as pd, numpy as np
import termometro as T
from lib import W, SPLIT
COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
P = T.leer_precios(); hasta = max(s.index[-1] for s in P.values()); L, V, info = T.luces_liquidez(hasta)
paro = T.bandera_paro(pd.date_range('1967-01-01', hasta, freq='D'))[0]
def st_simple(sc, lo, hi, frac=1.0): return pd.Series(np.where(sc >= hi, 1.0, np.where(sc <= lo, 1.0 - frac, np.nan)), index=sc.index).ffill().fillna(1.0)
def st_tramos(sc, lo, hi, dias=7):
    st = pd.Series(np.where(sc >= hi, 1.0, np.where(sc <= lo, 0.5, np.nan)), index=sc.index).ffill().fillna(1.0)
    todo = (st < 1).rolling(dias + 1).sum() == dias + 1
    return st.where(~todo, 0.0)
def mult(c, w, a, t0, t1=None):
    m = (c.index >= t0) & ((c.index < t1) if t1 is not None else True); ue, ops = T.simular(c[m], w[m], COST[a]); return float(ue.iloc[-1]), ops, float(ue.min())
def pares(ops):
    out = []; v = None
    for d, p, prev, tw in ops:
        if tw < prev and v is None: v = (d, p)
        elif tw > prev and v is not None: out.append((v[0].date(), round(v[1]), d.date(), round(p), round(v[1] / p, 2))); v = None
    if v is not None: out.append((v[0].date(), round(v[1]), 'abierta', None, None))
    return out
a = 'BTC'; pts, mx, sc = T.puntuacion(a, P, L, V, paro); c = P[a]; t0 = sc.first_valid_index(); sp = pd.Timestamp('2020-01-01')
for nm, w in (('todo de golpe 25/50', st_simple(sc, 25, 50)), ('por tramos 25/50 (mitad + resto a 7 días)', st_tramos(sc, 25, 50)), ('solo mitad 25/50', st_simple(sc, 25, 50, 0.5))):
    r = [mult(c, w, a, t0, sp), mult(c, w, a, sp), mult(c, w, a, pd.Timestamp('2023-01-01')), mult(c, w, a, t0)]
    print(f"BTC {nm}: 2011-2019 x{r[0][0]:.2f} ({len(r[0][1])} ops) | 2020-2026 x{r[1][0]:.2f} ({len(r[1][1])} ops) | desde 2023 x{r[2][0]:.2f} ({len(r[2][1])} ops) | total x{r[3][0]:.2f} peor {r[3][2]:.2f} | fuera {100*(1-w[t0:].shift(1).fillna(1)).mean():.0f}%")
print('BTC ventas (25/50, todo de golpe):'); [print('   ', x) for x in pares(mult(c, st_simple(sc, 25, 50), a, t0)[1])]
print('BTC puntuación en fechas clave:', {d: round(float(sc.loc[:d].iloc[-1])) for d in ('2013-11-29', '2014-06-01', '2015-01-14', '2017-12-16', '2018-06-01', '2018-12-15', '2020-03-16', '2021-04-13', '2021-11-08', '2022-06-18', '2022-11-21', '2024-03-13', '2025-10-06', '2026-03-01', '2026-06-30', '2026-10-01')})
g = sc['2025-06-01':]; print('BTC puntuación mensual reciente:', {str(d.date())[:7]: round(float(v)) for d, v in g.resample('MS').first().items()})
print('BTC rejilla más amplia (vende<=lo, recompra>=hi): % de combinaciones con D>1 y V>1:', end=' ')
ok = n = 0
for lo in range(15, 41, 5):
    for hi in range(40, 71, 10):
        w = st_simple(sc, lo, hi); d = mult(c, w, a, t0, sp)[0]; v = mult(c, w, a, sp)[0]; n += 1; ok += (d > 1 and v > 1)
print(f'{ok} de {n}')
for a, lo, hi in (('nasdaq100', 25, 50), ('nasdaq100', 25, 60), ('sp500', 20, 40)):
    pts, mx, sc = T.puntuacion(a, P, L, V, paro); c = P[a]; t0 = sc.first_valid_index(); w = st_simple(sc, lo, hi); r = mult(c, w, a, t0)
    pr = pares(r[1]); print(f"{a} {lo}/{hi}: total x{r[0]:.2f}, {len(pr)} ventas; ganadoras {sum(1 for x in pr if x[4] and x[4] > 1)}; mayores: {sorted([x for x in pr if x[4]], key=lambda x: -x[4])[:4]} peores: {sorted([x for x in pr if x[4]], key=lambda x: x[4])[:3]}")
# prueba de truncado (no mirar al futuro) de la puntuación
print('prueba de truncado:')
full = {a: T.puntuacion(a, P, L, V, paro)[2] for a in T.ACTIVOS}
orig_p, orig_s = T.leer_precios, T.serie
for cut in ('2015-03-10', '2018-11-20', '2020-03-16', '2022-06-18', '2024-08-05', '2026-03-10'):
    ct = pd.Timestamp(cut)
    P2 = {k: v[v.index <= ct] for k, v in P.items()}
    T.serie = lambda n, _o=orig_s, _c=ct: (lambda s: s[s.index <= _c])(_o(n))
    L2, V2, _ = T.luces_liquidez(ct); paro2 = T.bandera_paro(pd.date_range('1967-01-01', ct, freq='D'))[0]
    diffs = {}
    for a in T.ACTIVOS:
        s2 = T.puntuacion(a, P2, L2, V2, paro2)[2]; j = pd.concat([full[a].reindex(s2.index), s2], axis=1).dropna()
        diffs[a] = float((j.iloc[:, 0] - j.iloc[:, 1]).abs().max()) if len(j) else None
    print('  ', cut, diffs)
T.serie = orig_s
