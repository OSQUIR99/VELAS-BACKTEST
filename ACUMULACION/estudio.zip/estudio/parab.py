# -*- coding: utf-8 -*-
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, sys
from lib import *; from strat import COST

def zext(c, n=200, span=None, bpy=252):
    r = np.log(c).diff(); sd = r.ewm(span=span or bpy, min_periods=(span or bpy) // 2).std()
    return np.log(c / sma(c, n)) / (sd * np.sqrt(n))

def run(c, sell, cost, pull=None, timeout=None, back=None, stop=None, start=None, end=None):
    """Vende al cierre t+1 tras señal. Recompra: (a) orden límite un 'pull' más abajo (se ejecuta al precio límite);
    (b) 'back': serie booleana (p.ej. precio <= SMA200), al cierre siguiente; (c) stop: si sube 'stop' sobre la venta; (d) timeout barras."""
    s = sell.reindex(c.index).fillna(False).values; p = c.values; idx = c.index
    b = back.reindex(c.index).fillna(False).values if back is not None else None
    i0 = 0 if start is None else int(np.searchsorted(idx, pd.Timestamp(start)))
    i1 = len(p) - 1 if end is None else int(np.searchsorted(idx, pd.Timestamp(end))) - 1
    tr = []; pos = True; k = None
    i = i0
    while i < i1:
        if pos:
            if s[i]: pos = False; k = i + 1
        elif i >= k + 1 or i == k:
            if i > k:
                ps = p[k]
                if pull is not None and p[i] <= ps * (1 - pull): tr.append((idx[k], ps, idx[i], ps * (1 - pull), 'límite')); pos = True
                elif b is not None and b[i - 1]: tr.append((idx[k], ps, idx[i], p[i], 'vuelta')); pos = True
                elif stop is not None and p[i] >= ps * (1 + stop): tr.append((idx[k], ps, idx[i], p[i], 'stop')); pos = True
                elif timeout is not None and i - k >= timeout: tr.append((idx[k], ps, idx[i], p[i], 'tiempo')); pos = True
        i += 1
    if not pos and k is not None and k <= i1: tr.append((idx[k], p[k], idx[i1], p[i1], 'abierta'))
    T = pd.DataFrame(tr, columns=['venta', 'p_venta', 'recompra', 'p_recompra', 'motivo'])
    if len(T): T['unid'] = T.p_venta / T.p_recompra * (1 - cost) ** 2; T['dias'] = (T.recompra - T.venta).dt.days
    return T

def stat(T, lo, hi):
    g = T[(T.venta >= lo) & (T.venta < hi)] if len(T) else T
    if not len(g): return 'n=0'
    return f"n={len(g):2d} x{np.prod(g.unid):5.2f} ac={100*(g.unid>1).mean():3.0f}% med={100*(g.unid.median()-1):+5.1f}% peor={100*(g.unid.min()-1):+4.0f}%"

PULLS = {'BTC': (0.2, 0.3), 'sp500': (0.07, 0.10), 'nasdaq100': (0.10, 0.15), 'oro': (0.07, 0.10), 'plata': (0.12, 0.20)}
if __name__ == '__main__':
    for a in (sys.argv[1:] or ASSETS):
        df = pd.read_parquet(f'{W}/px_{a}.parquet'); c = df['c']; bpy = BPY[a]
        z = zext(c, 200, bpy=bpy); s200 = sma(c, 200)
        sp = pd.Timestamp(SPLIT[a]); t0 = c.index[0]; tend = c.index[-1] + pd.Timedelta(days=1)
        print(f"\n===== {a}: z200 = distancia a la media de 200 sesiones en 'volatilidades' | percentiles z: 90%={z.quantile(.9):.2f} 97%={z.quantile(.97):.2f} 99%={z.quantile(.99):.2f} max={z.max():.2f} =====")
        for thr in (1.2, 1.5, 1.7, 2.0, 2.3):
            sell = z >= thr
            for pull in PULLS[a]:
                for to in (bpy // 2, bpy):
                    T = run(c, sell, COST[a], pull=pull, timeout=to)
                    print(f"z>={thr} límite -{pull:.0%} tope {to}b | D {stat(T, t0, sp)} | V {stat(T, sp, tend)}")
            T = run(c, sell, COST[a], back=(c <= s200), timeout=2 * bpy)
            print(f"z>={thr} vuelta a sma200 (tope 2a)    | D {stat(T, t0, sp)} | V {stat(T, sp, tend)}")
