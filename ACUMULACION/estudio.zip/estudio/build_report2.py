import json, re, math
R1 = json.load(open('report_data.json')); R2 = json.load(open('report_data2.json')); V = json.load(open('sell_summary.json'))
simple = lambda x: None if x is None else round(100 * (math.exp(x / 100) - 1), 1)
for a, d in V.items(): d['D_med'] = simple(d['D_med']); d['V_med'] = simple(d['V_med'])
punt = R2['punt']
for a in punt:
    if 'regla' in punt[a] and a != 'BTC': punt[a].pop('regla')
punt['BTC']['regla'].pop('golpe', None)
D = {'lectura': R2['lectura'], 'punt': punt, 'plata_semanal': R2['plata_semanal'], 'ventas': V, 'plata_sem': R1['plata_sem']['pares'], 'compras': R1['compras']}
html = open('report/template2.html').read().replace('__DATA__', json.dumps(D, ensure_ascii=False, separators=(',', ':')))
open('report/termometro-acumulacion.html', 'w').write(html)
open('report/preview.html', 'w').write('<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' + html + '</body></html>')
print('bytes', len(html))
