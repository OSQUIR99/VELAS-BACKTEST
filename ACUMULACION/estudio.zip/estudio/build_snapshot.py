import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, json
from lib import *; from ext import dec, fred, yahoo
T = f'{W}/tool/datos'
rp = json.load(open(f'{W}/data/raw_browser/recent_prices.json'))
cols = {}
for a in ASSETS:
    c = pd.read_parquet(f'{W}/px_{a}.parquet')['c']
    r = pd.DataFrame(rp[a]); r = pd.Series(r[4].astype(float).values, index=pd.to_datetime(r[0]))
    if a == 'BTC':
        r = r[r.index <= '2026-10-01']            # la vela del 2-oct no estaba cerrada
        c.loc[pd.Timestamp('2026-09-21')] = r[pd.Timestamp('2026-09-21')]   # vela parcial en la base original
    if a == 'plata':
        com = c.index.intersection(r.index); r = r * float((c[com] / r[com]).iloc[-5:].mean())
    cols[a] = pd.concat([c, r[r.index > c.index[-1]]])
P = pd.DataFrame(cols).rename_axis('fecha'); P.to_csv(f'{T}/precios_diarios.csv')
print(P.tail(4).round(2).to_string())
def save(name, s):
    s = s[~s.index.duplicated(keep='last')].sort_index().dropna(); s.rename('valor').rename_axis('fecha').to_csv(f'{T}/series/{name}.csv'); print(f'{name:<11} {s.index[0].date()} -> {s.index[-1].date()} n={len(s)} último={s.iloc[-1]:.3f}')
save('DXY', yahoo('DX-Y.NYB'))
vix = pd.concat([fred('VIXCLS'), yahoo('^VIX')]); save('VIX', vix)
for k in ('NFCI', 'DGS10', 'BAA10Y', 'DFII10', 'ICSA', 'DEXUSEU', 'DEXJPUS'): save(k, fred(k))
for k in ('WALCL', 'WTREGEN', 'RRPONTSYD', 'ECBASSETSW', 'JPNASSETS'): save(k, dec('fred_' + k)[0][0])
save('ESTABLES', dec('stablecoins')[0][0] / 10)
save('FNG_CRIPTO', dec('fng_crypto')[0][0])
old = pd.read_csv('https://raw.githubusercontent.com/hackingthemarkets/sentiment-fear-and-greed/master/datasets/fear-greed.csv', parse_dates=['Date']).set_index('Date')['Fear Greed'].dropna()
cn = dec('fng_cnn')[0][0]; cn = cn[cn.index >= '2021-02-10']; save('FNG_CNN', pd.concat([old[old.index < '2020-09-19'], cn]).astype(float))
