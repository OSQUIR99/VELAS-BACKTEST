# -*- coding: utf-8 -*-
"""Reglas de ciclo: vender (todo, para medir) cuando salta 'sell'; recomprar cuando salta 'buy', o por tope de pérdida (stop) o por tiempo.
Señal al cierre t -> se ejecuta al cierre t+1. Devuelve operaciones y múltiplo de unidades."""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from lib import *
from strat import COST


def run_cycle(c, sell, buy, cost, stop=None, timeout=None, start=None, end=None):
    sell = sell.reindex(c.index).fillna(False).values; buy = buy.reindex(c.index).fillna(False).values
    p = c.values; idx = c.index; trades = []; pos = True; k = None
    i0 = 0 if start is None else int(np.searchsorted(idx, pd.Timestamp(start)))
    i1 = len(p) - 1 if end is None else int(np.searchsorted(idx, pd.Timestamp(end))) - 1
    for i in range(i0, i1):
        if pos:
            if sell[i]:
                pos = False; k = i + 1
        else:
            why = None
            if buy[i]: why = 'señal'
            elif stop is not None and p[i] > p[k] * (1 + stop): why = 'stop'
            elif timeout is not None and i - k >= timeout: why = 'tiempo'
            if why:
                trades.append((idx[k], p[k], idx[i + 1], p[i + 1], why)); pos = True
    if not pos:
        trades.append((idx[k], p[k], idx[i1], p[i1], 'abierta'))
    T = pd.DataFrame(trades, columns=['venta', 'p_venta', 'recompra', 'p_recompra', 'motivo'])
    if len(T):
        T['unid'] = T.p_venta / T.p_recompra * (1 - cost) ** 2
        T['dias'] = (T.recompra - T.venta).dt.days
    return T


def summary(T, split):
    out = {}
    for nm, g in (('D', T[T.venta < split]), ('V', T[T.venta >= split])) if len(T) else ():
        out[nm] = (len(g), float(np.prod(g.unid)) if len(g) else 1.0, float((g.unid > 1).mean()) if len(g) else np.nan)
    return out


def show(name, T, split, detail=True):
    s = summary(T, pd.Timestamp(split))
    txt = ' | '.join(f"{k}: n={v[0]} mult={v[1]:.2f} acierto={100*v[2]:.0f}%" for k, v in s.items())
    print(f"## {name}: {txt}")
    if detail and len(T):
        for r in T.itertuples():
            print(f"   {r.venta.date()} {r.p_venta:>10.2f} -> {r.recompra.date()} {r.p_recompra:>10.2f} {r.motivo:<7} x{r.unid:.2f} ({r.dias}d)")
