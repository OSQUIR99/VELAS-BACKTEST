import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from lib import *; from strat import sim, perf, COST
f = pd.read_parquet(f'{W}/feat3_BTC.parquet'); c = f['c']; liq = f['liq']
sp = pd.Timestamp('2020-01-01'); start = pd.Timestamp('2011-11-05')
def engine(c, liq, n=200, out_thr=33, in_thr=50, buf=0.05, persist=0, frac_out=1.0, stage=None):
    s = sma(c, n); dist = c / s - 1
    out = ((liq <= out_thr) & (dist < 0))
    if persist: out = out.rolling(persist + 1).sum() == persist + 1
    back = (liq >= in_thr) | (dist > buf)
    st = pd.Series(np.where(back, 1.0, np.where(out, 1.0 - frac_out, np.nan)), index=c.index).ffill().fillna(1.0)
    if stage:   # segundo tramo: si a los 'stage' días sigue fuera, vender el resto
        full = (st < 1).rolling(stage + 1).sum() == stage + 1
        st = st.where(~full, 0.0)
    return st
print('persistencia (días seguidos con la condición antes de vender):')
for p in (0, 2, 4, 7, 10, 14):
    w = engine(c, liq, persist=p); d = perf(c, w, 'BTC', start, sp); v = perf(c, w, 'BTC', sp, None)
    print(f"  {p:2d} d: D x{d['mult']:.2f} ({d['ops']} ops)  V x{v['mult']:.2f} ({v['ops']} ops)  peor V {v['peor']:.2f}")
print('tramos:')
for nm, kw in (('todo de golpe', {}), ('mitad', {'frac_out': 0.5}), ('mitad y el resto a los 7 d', {'frac_out': 0.5, 'stage': 7}), ('mitad y el resto a los 14 d', {'frac_out': 0.5, 'stage': 14}), ('un tercio', {'frac_out': 1/3})):
    w = engine(c, liq, **kw); d = perf(c, w, 'BTC', start, sp); v = perf(c, w, 'BTC', sp, None)
    print(f"  {nm:<28} D x{d['mult']:.2f} ({d['ops']} ops)  V x{v['mult']:.2f} ({v['ops']} ops)  peor V {v['peor']:.2f}")
# por subperiodos de 3-4 años (regla base)
w = engine(c, liq)
for lo, hi in (('2011-11-05', '2014-01-01'), ('2014-01-01', '2017-01-01'), ('2017-01-01', '2020-01-01'), ('2020-01-01', '2023-01-01'), ('2023-01-01', '2026-10-01')):
    r = perf(c, w, 'BTC', pd.Timestamp(lo), pd.Timestamp(hi)); print(f"  {lo[:4]}-{hi[:4]}: x{r['mult']:.2f} ops {r['ops']} fuera {r['fuera%']:.0f}%")
# otras criptos con la misma regla y las mismas luces (prueba fuera de muestra de activo)
print('otras criptos (misma regla, sin tocar nada):')
L = f['liq']
for sym in ('ETH', 'BNB', 'XRP', 'LTC', 'ADA', 'LINK', 'SOL'):
    try:
        d0 = pd.read_parquet(f'{BASE}/CRIPTO/{sym}/1d.parquet'); cc = pd.Series(d0['cierre'].values, index=pd.to_datetime(d0['fecha']).dt.floor('D'))
        ww = engine(cc, L.reindex(cc.index).ffill()); st = cc.index[0] + pd.Timedelta(days=230)
        ue, ntr = sim(cc[cc.index >= st], ww[ww.index >= st], 0.0015)
        print(f"  {sym}: desde {st.date()} x{ue.iloc[-1]:.2f} ops {ntr} peor {ue.min():.2f}")
    except Exception as e: print(sym, 'error', e)
# y en los tradicionales por si acaso (ya visto: no)
print('estado y niveles hoy: sma200 =', round(sma(c,200).iloc[-1]), '| precio', c.iloc[-1], '| liq', round(liq.iloc[-1]))
