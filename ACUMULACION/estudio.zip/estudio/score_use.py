import warnings; warnings.filterwarnings('ignore')
import sys; sys.path.insert(0, '/home/claude/work/tool')
import pandas as pd, numpy as np
import termometro as T
from lib import W, SPLIT, load_raw, sma, rsi
COST = {'BTC': 0.0015, 'sp500': 0.001, 'nasdaq100': 0.001, 'oro': 0.001, 'plata': 0.0015}
P = T.leer_precios(); hasta = max(s.index[-1] for s in P.values()); L, V, info = T.luces_liquidez(hasta)
paro = T.bandera_paro(pd.date_range('1967-01-01', hasta, freq='D'))[0]
def overlay(c, sc, lo, hi, frac=1.0):
    st = pd.Series(np.where(sc >= hi, 1.0, np.where(sc <= lo, 1.0 - frac, np.nan)), index=c.index).ffill().fillna(1.0)
    return st
def mult(c, w, a, t0, t1=None):
    m = (c.index >= t0) & ((c.index < t1) if t1 is not None else True)
    ue, ops = T.simular(c[m], w[m], COST[a]); return float(ue.iloc[-1]), len(ops), float(ue.min())
def dca(c, sc, fn, t0, t1):
    m = c[(c.index >= t0) & (c.index < t1)]; month = m.index.to_period('M'); first = np.r_[True, month[1:] != month[:-1]]
    u = u0 = res = 0.0; p = m.values; s = sc.reindex(m.index).values
    for i in range(len(p)):
        if first[i]:
            u0 += 1 / p[i]; k = 1.0 if np.isnan(s[i]) else fn(s[i]); bud = 1.0 + res; buy = min(k, bud); u += buy / p[i]; res = bud - buy
    return (u + res / p[-1]) / u0, res
DCA_RULES = {'x2 si >=75, x0.5 si <40': lambda s: 2.0 if s >= 75 else (0.5 if s < 40 else 1.0), 'x1.5 si >=60, x0.5 si <40': lambda s: 1.5 if s >= 60 else (0.5 if s < 40 else 1.0), 'x0 si <25, resto normal, x2 si >=75': lambda s: 0.0 if s < 25 else (2.0 if s >= 75 else 1.0)}
for a in T.ACTIVOS:
    pts, mx, sc = T.puntuacion(a, P, L, V, paro); c = P[a]; sp = pd.Timestamp(SPLIT[a]); t0 = sc.first_valid_index(); tend = c.index[-1] + pd.Timedelta(days=1)
    print(f'\n=== {a} (desde {t0.date()}) ===')
    res = []
    for lo in (20, 25, 30, 35):
        for hi in (40, 50, 60):
            w = overlay(c, sc, lo, hi)
            d = mult(c, w, a, t0, sp) if sp > t0 + pd.Timedelta(days=900) else (np.nan, 0, np.nan); v = mult(c, w, a, max(sp, t0)); res.append((lo, hi, d[0], d[1], v[0], v[1], v[2]))
    G = pd.DataFrame(res, columns=['vende<=', 'recompra>=', 'D', 'Dops', 'V', 'Vops', 'Vpeor'])
    print('  venta por puntuación (unidades frente a mantener):'); print(G.round(2).to_string(index=False))
    for rn, fn in DCA_RULES.items():
        d = dca(c, sc, fn, t0, sp) if sp > t0 + pd.Timedelta(days=1500) else (np.nan, np.nan); v = dca(c, sc, fn, max(sp, t0), tend)
        print(f"  compras según puntuación [{rn}]: D {d[0]:.3f}  V {v[0]:.3f} (reserva final {v[1]:.1f} meses)")
    if a == 'BTC':
        print('  quitar un ingrediente (correlación de rangos con lo de 3 meses después, D / V; y venta 25/50):')
        fr3 = c.shift(-91) / c - 1
        for drop in [None] + list(pts.columns):
            cols = [k for k in pts.columns if k != drop]; s2 = 100 * pts[cols].sum(axis=1, skipna=True) / pts[cols].notna().mul(mx[cols], axis=1).sum(axis=1)
            s2 = s2.where(sc.notna()); S = pd.DataFrame({'s': s2, 'f': fr3}).dropna().iloc[::7]
            icd = S[S.index < sp].corr(method='spearman').iloc[0, 1]; icv = S[S.index >= sp].corr(method='spearman').iloc[0, 1]
            w = overlay(c, s2, 25, 50); print(f"    sin {str(drop)[:40]:<40} IC {icd:+.2f} / {icv:+.2f} | venta: D x{mult(c, w, a, t0, sp)[0]:.2f} V x{mult(c, w, a, sp)[0]:.2f}")
# plata semanal larga: misma receta con velas semanales
S_ = load_raw('plata', '1w')['c']; G_ = load_raw('oro', '1w')['c'].reindex(S_.index).ffill()
m = sma(S_, 40); gm = sma(G_, 40); hi = S_.rolling(52, min_periods=26).max(); r = np.log(S_).diff(); sd = r.ewm(span=52, min_periods=26).std(); z = np.log(S_ / m) / (sd * np.sqrt(40))
rp = (G_ / S_).rolling(520, min_periods=156).rank(pct=True) * 100
pts = pd.DataFrame({'t': 2 * (S_ > m), 's': 1 * (m > m.shift(4)), 'g': (2 * (G_ > gm)).where(gm.notna()), 'd': 2 * (S_ / hi - 1 > -0.10), 'z': 2 * (z < 1.7), 'r': (1 * (rp > 20)).where(rp.notna())}).astype(float).where(m.notna())
mxw = pd.Series({'t': 2, 's': 1, 'g': 2, 'd': 2, 'z': 2, 'r': 1}); scw = 100 * pts.sum(axis=1, skipna=True) / pts.notna().mul(mxw, axis=1).sum(axis=1); scw = scw.where(m.notna())
fr3 = S_.shift(-13) / S_ - 1; fr12 = S_.shift(-52) / S_ - 1; X = pd.DataFrame({'s': scw, 'fr3': fr3, 'fr12': fr12}).dropna(subset=['s'])
X['b'] = pd.cut(X.s, [-1, 25, 40, 60, 75, 101], labels=['0-25', '25-40', '40-60', '60-75', '75-100'])
print('\n=== PLATA semanal desde 1971 (misma receta) ===')
for nm, g in (('1ª mitad (hasta 2005)', X[X.index < '2006']), ('2ª mitad', X[X.index >= '2006'])):
    t = g.groupby('b').agg(n=('s', 'size'), m3=('fr3', 'mean'), p3=('fr3', lambda x: (x > 0).mean()), m12=('fr12', 'mean'), p12=('fr12', lambda x: (x > 0).mean()))
    print(f"  {nm} IC 3m {g[['s','fr3']].corr(method='spearman').iloc[0,1]:+.2f} 12m {g[['s','fr12']].corr(method='spearman').iloc[0,1]:+.2f}: " + ' | '.join(f"{i}: n={int(x.n)} 3m {100*x.m3:+.0f}% ({100*x.p3:.0f}%+) 12m {100*x.m12:+.0f}% ({100*x.p12:.0f}%+)" for i, x in t.iterrows() if x.n > 0))
for lo, hi_ in ((25, 50), (30, 60), (20, 40)):
    st = pd.Series(np.where(scw >= hi_, 1.0, np.where(scw <= lo, 0.0, np.nan)), index=S_.index).ffill().fillna(1.0)
    for nm, a0, a1 in (('1971-2005', '1971-01-01', '2006-01-01'), ('2006-2026', '2006-01-01', '2027-01-01')):
        mm = (S_.index >= a0) & (S_.index < a1); ue, ops = T.simular(S_[mm], st[mm], 0.0015); print(f"  venta<= {lo}, recompra>= {hi_} {nm}: x{ue.iloc[-1]:.2f} ({len(ops)} ops)", end=' |')
    print()
