# -*- coding: utf-8 -*-
"""Ingredientes candidatos de la puntuación, propios de cada activo. Para cada uno: rentabilidad posterior media
cuando está ENCENDIDO menos cuando está APAGADO, a 3 y 12 meses, en las dos mitades (muestreo semanal)."""
import warnings; warnings.filterwarnings('ignore')
import sys; sys.path.insert(0, '/home/claude/work/tool')
import pandas as pd, numpy as np
import termometro as T
from lib import *
E = pd.read_parquet(f'{W}/ext_daily.parquet')
HALV = [pd.Timestamp(x) for x in ('2012-11-28', '2016-07-09', '2020-05-11', '2024-04-20')]
def meses_halving(idx):
    out = pd.Series(np.nan, index=idx)
    for h in HALV: out[idx >= h] = (idx[idx >= h] - h).days / 30.44
    return out
paro, ratio = T.bandera_paro(pd.date_range('1967-01-01', '2026-10-02', freq='D'))

def panel(a):
    f = pd.read_parquet(f'{W}/feat3_{a}.parquet'); X = E.reindex(f.index)
    f['paro'] = paro.reindex(f.index).ffill(); f['paro_ratio'] = ratio.reindex(f.index).ffill()
    f['cot_idx'] = X.get(f'cot_idx_{a}'); f['oi_pct'] = X.get(f'oi_pct3y_{a}')
    if a in ('sp500', 'nasdaq100', 'BTC'): f['tff_am_p'] = pct_rolling(X[f'tff_am_{a}'], 1095, 365)
    f['mh'] = meses_halving(f.index) if a == 'BTC' else np.nan
    f['rvp'] = pct_expanding(f.rv20, 750)
    f['d200w_p'] = pct_rolling(f.d_sma200w, 1460 if a == 'BTC' else 2520, 500)
    f['m_p4'] = pct_rolling(f['mvrv'], 1460, 730) if 'mvrv' in f else np.nan
    f['ry_or_t10'] = f['ry10_13w'].where(f['ry10_13w'].notna(), f['t10_13w']) if 't10_13w' in f else np.nan
    if a in ('oro', 'plata'):
        g = pd.read_parquet(f'{W}/px_oro.parquet')['c']; s = pd.read_parquet(f'{W}/px_plata.parquet')['c']
        r = (g / s.reindex(g.index)).dropna(); f['gsr'] = r.reindex(f.index); f['gsr_p'] = pct_rolling(f['gsr'], 2520, 750)
        f['oro_tend'] = (g > sma(g, 200)).astype(float).reindex(f.index)
    return f

def C(a, f):
    c = {}
    add = lambda name, sign, cond: c.__setitem__(name, (sign, cond))
    add('tendencia: sobre media 200', +1, f.d_sma200 > 0)
    add('media 200 subiendo', +1, f.sma200_slope > 0)
    add('RSI semanal < 35', +1, f.rsi14w < 35)
    add('RSI diario < 30', +1, f.rsi14 < 30)
    add('volatilidad extrema (p>=95)', +1, f.rvp >= 95)
    add('caída >=10% desde máx 52s', +1, f.dd_52w <= -0.10)
    add('caída >=20% desde máx 52s', +1, f.dd_52w <= -0.20)
    add('extensión z200 >= 1.7', -1, f.z200 >= 1.7)
    add('extensión z200 >= 1.2', -1, f.z200 >= 1.2)
    add('muy por encima media 200 sem (p>=90)', -1, f.d200w_p >= 90)
    add('cerca o bajo media 200 sem (<=+10%)', +1, f.d_sma200w <= 0.10)
    add('dólar bajando 13s', +1, f.dxy_13w < 0)
    add('dólar subiendo >3% 13s', -1, f.dxy_13w > 3)
    add('bono 10a bajando 13s', +1, f.t10_13w < 0)
    add('bono 10a subiendo >0.5 13s', -1, f.t10_13w > 0.5)
    add('tipo real bajando 13s', +1, f.ry10_13w < 0)
    add('tipo real bajando >=0.5', +1, f.ry10_13w <= -0.5)
    add('tipo real subiendo >=0.5', -1, f.ry10_13w >= 0.5)
    add('cond. financieras relajándose', +1, f.nfci_13w < 0)
    add('crédito: prima bajando', +1, f.baa_13w < 0)
    add('liquidez >= 50', +1, f.liq >= 50)
    add('liquidez >= 67', +1, f.liq >= 67)
    add('liquidez <= 33', -1, f.liq <= 33)
    add('bancos centrales creciendo', +1, f.gcb_13w > 0)
    if a in ('sp500', 'nasdaq100'):
        add('sin señal de recesión (paro)', +1, f.paro == 0)
        add('recesión + bajo media 200', -1, (f.paro == 1) & (f.d_sma200 < 0))
        add('VIX >= 30', +1, f.vix >= 30); add('VIX >= 40', +1, f.vix >= 40); add('VIX <= 13', -1, f.vix <= 13)
        add('miedo CNN <= 25', +1, f.fng_cnn <= 25); add('codicia CNN >= 75', -1, f.fng_cnn >= 75)
        add('especuladores poco comprados (COT<=20)', +1, f.cot_idx <= 20); add('especuladores muy comprados (COT>=80)', -1, f.cot_idx >= 80)
        add('interés abierto bajo (p<=20)', +1, f.oi_pct <= 20); add('interés abierto alto (p>=90)', -1, f.oi_pct >= 90)
        add('gestores poco comprados (p<=20)', +1, f.tff_am_p <= 20); add('gestores muy comprados (p>=90)', -1, f.tff_am_p >= 90)
    if a == 'BTC':
        add('halving: meses 24-36', +1, (f.mh >= 24) & (f.mh < 36)); add('halving: meses 12-22', -1, (f.mh >= 12) & (f.mh < 22)); add('halving: meses 0-12', +1, (f.mh >= 0) & (f.mh < 12))
        add('MVRV <= 1.2', +1, f.mvrv <= 1.2); add('MVRV percentil 4a >= 90', -1, f.m_p4 >= 90)
        add('caída >=60% desde máximo histórico', +1, f.dd_ath <= -0.60)
        add('miedo cripto <= 20', +1, f.fng_crypto <= 20); add('codicia cripto >= 80', -1, f.fng_crypto >= 80)
        add('monedas estables creciendo >2%', +1, f.stable_13w > 2); add('monedas estables cayendo', -1, f.stable_13w < 0)
        add('financiación 30d >= 30% anual', -1, f.fund_30d >= 30); add('financiación 7d < 0', +1, f.fund_7d < 0)
        add('delta 30d percentil <= 10', -1, f.delta30_p <= 10); add('delta 30d percentil >= 90', +1, f.delta30_p >= 90)
        add('gestores CME poco comprados', +1, f.tff_am_p <= 20)
    if a in ('oro', 'plata'):
        add('cerca de máximos 52s (pos>=0.9)', +1, f.pos52w >= 0.9)
        add('ratio oro/plata alto (p>=80)', +1 if a == 'plata' else -1, f.gsr_p >= 80)
        add('ratio oro/plata bajo (p<=20)', -1 if a == 'plata' else +1, f.gsr_p <= 20)
        add('oro en tendencia alcista', +1, f.oro_tend == 1)
        add('especuladores muy comprados (COT>=80)', -1, f.cot_idx >= 80); add('especuladores poco comprados (COT<=20)', +1, f.cot_idx <= 20)
        add('interés abierto alto (p>=90)', -1, f.oi_pct >= 90)
    return c

if __name__ == '__main__':
    rows = []
    for a in ASSETS:
        f = panel(a); f.to_parquet(f'{W}/panel_{a}.parquet'); step = 7 if a == 'BTC' else 5; sp = pd.Timestamp(SPLIT[a])
        for name, (sign, cond) in C(a, f).items():
            valid = cond.notna() if cond.dtype != bool else pd.Series(True, index=f.index)
            S = pd.DataFrame({'on': cond.fillna(False).astype(bool), 'fr3': f.fr_3m, 'fr12': f.fr_12m, 'fmin': f.fmin_6m})
            # solo el tramo en que el indicador existe
            src = [k for k in ('vix','fng_cnn','fng_crypto','cot_idx','oi_pct','tff_am_p','mvrv','ry10_13w','stable_13w','fund_30d','fund_7d','delta30_p','gsr_p','liq','gcb_13w','nfci_13w','baa_13w','dxy_13w','t10_13w','paro','mh','d200w_p','m_p4','rvp','z200','d_sma200w','rsi14w') if k in f]
            S = S.iloc[::step]; r = {'activo': a, 'ingrediente': name, 'signo': sign}
            for nm, g in (('D', S[S.index < sp]), ('V', S[S.index >= sp])):
                on = g[g.on]; off = g[~g.on]
                r[nm + '_on%'] = 100 * len(on) / max(1, len(g)); r[nm + '_n'] = len(on.dropna(subset=['fr3']))
                r[nm + '_d3'] = 100 * (on.fr3.mean() - off.fr3.mean()) if len(on.dropna(subset=['fr3'])) >= 8 else np.nan
                r[nm + '_d12'] = 100 * (on.fr12.mean() - off.fr12.mean()) if len(on.dropna(subset=['fr12'])) >= 8 else np.nan
            rows.append(r)
    R = pd.DataFrame(rows); R.to_csv(f'{W}/res_comp.csv', index=False)
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 44)
    for a in ASSETS:
        g = R[R.activo == a].drop(columns='activo').round(1)
        print(f'\n=== {a} === (d3/d12 = diferencia de rentabilidad media posterior, encendido menos apagado, en puntos %; signo = lo que se esperaba)')
        print(g.to_string(index=False))
